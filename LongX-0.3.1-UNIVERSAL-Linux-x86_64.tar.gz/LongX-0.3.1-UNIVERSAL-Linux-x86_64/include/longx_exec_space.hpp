
#pragma once
#include "longx_memory_space.hpp"

namespace LongX {
	
	struct Serial {};
	struct Cuda {};
	struct Hip {};
	struct Musa {};
	struct Sycl {};
	struct OpenCL {};
	struct OpenGL {};
	struct MPI {};
	struct Tbb {};
	struct OpenMP {};

	using OPENMP = OpenMP;
	using HygonDCU = Hip;
	
	template<typename ExecSpace>
	struct ExecToMemSpace;
	
	template<>
	struct ExecToMemSpace<Cuda> {
		using type = CudaSpace;
	};
	
	template<>
	struct ExecToMemSpace<Hip> {
		using type = HipSpace;
	};

	template<>
	struct ExecToMemSpace<Musa> {
		using type = MusaSpace;
	};

	template<>
	struct ExecToMemSpace<Sycl> {
		using type = SyclSpace;
	};

	template<>
	struct ExecToMemSpace<OpenCL> {
		using type = HostSpace;
	};

	template<>
	struct ExecToMemSpace<OpenGL> {
		using type = HostSpace;
	};

	template<>
	struct ExecToMemSpace<MPI> {
		using type = HostSpace;
	};

	template<>
	struct ExecToMemSpace<Tbb> {
		using type = HostSpace;
	};
	
	template<>
	struct ExecToMemSpace<OpenMP> {
		using type = HostSpace;
	};
	
	template<>
	struct ExecToMemSpace<Serial> {
		using type = HostSpace;
	};

#if defined(LONGX_ENABLE_CUDA)
	using DefaultExecutionSpace = Cuda;
#elif defined(LONGX_ENABLE_MUSA)
	using DefaultExecutionSpace = Musa;
#elif defined(LONGX_ENABLE_SYCL)
	using DefaultExecutionSpace = Sycl;
#elif defined(LONGX_ENABLE_OPENCL)
	using DefaultExecutionSpace = OpenCL;
#elif defined(LONGX_ENABLE_OPENGL)
	using DefaultExecutionSpace = OpenGL;
#elif defined(LONGX_ENABLE_HIP)
	using DefaultExecutionSpace = Hip;
#elif defined(LONGX_ENABLE_MPI)
	using DefaultExecutionSpace = MPI;
#elif defined(LONGX_ENABLE_TBB)
	using DefaultExecutionSpace = Tbb;
#elif defined(LONGX_ENABLE_OPENMP)
	using DefaultExecutionSpace = OpenMP;
#else
	using DefaultExecutionSpace = Serial;
#endif

	using DefaultMemorySpace = typename ExecToMemSpace<DefaultExecutionSpace>::type;
	
}

