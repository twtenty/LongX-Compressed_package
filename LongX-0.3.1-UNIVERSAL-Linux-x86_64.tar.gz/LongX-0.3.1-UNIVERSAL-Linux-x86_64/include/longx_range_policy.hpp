
#pragma once
#include <cassert>
#include <cstddef>

namespace LongX {

	enum class Schedule {
		Static,
		Dynamic,
		Guided
	};

	struct RangePolicyOptions {
		int block_size = 256;
		Schedule schedule = Schedule::Static;
	};

	struct MDRangePolicyOptions {
		int tile0 = 16;
		int tile1 = 16;
		Schedule schedule = Schedule::Static;
		bool collapse = false;
	};
	
	template<typename ExecSpace>
	class RangePolicy {
	public:
		RangePolicy(size_t begin, size_t end)
		: begin_(begin), end_(end), options_{} {
			assert(begin <= end);
		}

		RangePolicy(size_t begin, size_t end, RangePolicyOptions options)
		: begin_(begin), end_(end), options_(options) {
			assert(begin <= end);
			assert(options_.block_size > 0);
		}
		
		size_t begin() const { return begin_; }
		size_t end()   const { return end_; }
		size_t size() const { return end_ - begin_; }
		int block_size() const { return options_.block_size; }
		Schedule schedule() const { return options_.schedule; }
		const RangePolicyOptions& options() const { return options_; }
		
	private:
		size_t begin_;
		size_t end_;
		RangePolicyOptions options_;
	};

	template<typename ExecSpace, int Rank>
	class MDRangePolicy;

	template<typename ExecSpace>
	class MDRangePolicy<ExecSpace, 2> {
	public:
		MDRangePolicy(size_t begin0, size_t begin1, size_t end0, size_t end1)
		: begin0_(begin0), begin1_(begin1), end0_(end0), end1_(end1), options_{} {
			assert(begin0 <= end0);
			assert(begin1 <= end1);
		}

		MDRangePolicy(size_t begin0, size_t begin1, size_t end0, size_t end1, MDRangePolicyOptions options)
		: begin0_(begin0), begin1_(begin1), end0_(end0), end1_(end1), options_(options) {
			assert(begin0 <= end0);
			assert(begin1 <= end1);
			assert(options_.tile0 > 0);
			assert(options_.tile1 > 0);
		}

		size_t begin0() const { return begin0_; }
		size_t begin1() const { return begin1_; }
		size_t end0() const { return end0_; }
		size_t end1() const { return end1_; }
		size_t extent0() const { return end0_ - begin0_; }
		size_t extent1() const { return end1_ - begin1_; }
		size_t size() const { return extent0() * extent1(); }
		int tile0() const { return options_.tile0; }
		int tile1() const { return options_.tile1; }
		Schedule schedule() const { return options_.schedule; }
		bool collapse() const { return options_.collapse; }
		const MDRangePolicyOptions& options() const { return options_; }

	private:
		size_t begin0_;
		size_t begin1_;
		size_t end0_;
		size_t end1_;
		MDRangePolicyOptions options_;
	};
	
} // namespace LongX
