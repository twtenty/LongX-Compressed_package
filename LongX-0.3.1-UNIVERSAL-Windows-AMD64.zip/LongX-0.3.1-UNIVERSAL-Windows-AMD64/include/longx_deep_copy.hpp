#pragma once

#include <algorithm>
#include <cassert>
#include <cstddef>
#include <type_traits>

#include "longx_error.hpp"
#include "longx_memory_space.hpp"
#include "longx_view.hpp"
#include "longx_view2d.hpp"
#include "longx_view3d.hpp"

#ifdef LONGX_ENABLE_HIP
#include "longx_view_hip.hpp"
#endif

#ifdef LONGX_ENABLE_MUSA
#include "longx_view_musa.hpp"
#endif

#ifdef LONGX_ENABLE_SYCL
#include "longx_view_sycl.hpp"
#endif

namespace LongX {

namespace detail {

template<typename Space>
struct is_host_accessible_space : std::false_type {};

template<>
struct is_host_accessible_space<HostSpace> : std::true_type {};

template<>
struct is_host_accessible_space<OpenMPSpace> : std::true_type {};

template<>
struct is_host_accessible_space<SyclSpace> : std::true_type {};

template<typename>
inline constexpr bool always_false_v = false;

#ifdef LONGX_ENABLE_CUDA
template<typename T>
__global__ void longx_cuda_fill_kernel(T* data, size_t n, T value) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        data[i] = value;
    }
}
#endif

#ifdef LONGX_ENABLE_HIP
template<typename T>
__global__ void longx_hip_fill_kernel(T* data, size_t n, T value) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        data[i] = value;
    }
}
#endif

#ifdef LONGX_ENABLE_MUSA
template<typename T>
__global__ void longx_musa_fill_kernel(T* data, size_t n, T value) {
    size_t i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) {
        data[i] = value;
    }
}
#endif

} // namespace detail

template<typename T, typename DstSpace, typename SrcSpace>
void deep_copy(View<T, DstSpace>& dst, const View<T, SrcSpace>& src) {
    assert(dst.extent() == src.extent());
    size_t bytes = sizeof(T) * dst.extent();

    if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                  detail::is_host_accessible_space<SrcSpace>::value) {
        std::copy(src.data(), src.data() + src.extent(), dst.data());
    }
#ifdef LONGX_ENABLE_CUDA
    else if constexpr (std::is_same_v<DstSpace, CudaSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, CudaSpace>) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, CudaSpace> &&
                         std::is_same_v<SrcSpace, CudaSpace>) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyDeviceToDevice));
    }
#endif
#ifdef LONGX_ENABLE_HIP
    else if constexpr (std::is_same_v<DstSpace, HipSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, HipSpace>) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, HipSpace> &&
                         std::is_same_v<SrcSpace, HipSpace>) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyDeviceToDevice));
    }
#endif
#ifdef LONGX_ENABLE_MUSA
    else if constexpr (std::is_same_v<DstSpace, MusaSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, MusaSpace>) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, MusaSpace> &&
                         std::is_same_v<SrcSpace, MusaSpace>) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyDeviceToDevice));
    }
#endif
    else {
        static_assert(detail::always_false_v<DstSpace>, "Unsupported LongX::deep_copy spaces");
    }
}

template<typename T, typename Space>
void deep_copy(View<T, Space>& dst, const T& value) {
    if constexpr (detail::is_host_accessible_space<Space>::value) {
        std::fill(dst.data(), dst.data() + dst.extent(), value);
    }
#ifdef LONGX_ENABLE_CUDA
    else if constexpr (std::is_same_v<Space, CudaSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        detail::longx_cuda_fill_kernel<<<grid_size, block_size>>>(dst.data(), n, value);
        LONGX_CUDA_CHECK(cudaGetLastError());
        LONGX_CUDA_CHECK(cudaDeviceSynchronize());
    }
#endif
#ifdef LONGX_ENABLE_HIP
    else if constexpr (std::is_same_v<Space, HipSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        hipLaunchKernelGGL(
            detail::longx_hip_fill_kernel<T>,
            dim3(grid_size),
            dim3(block_size),
            0,
            0,
            dst.data(),
            n,
            value
        );
        LONGX_HIP_CHECK(hipGetLastError());
        LONGX_HIP_CHECK(hipDeviceSynchronize());
    }
#endif
#ifdef LONGX_ENABLE_MUSA
    else if constexpr (std::is_same_v<Space, MusaSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        detail::longx_musa_fill_kernel<<<grid_size, block_size>>>(dst.data(), n, value);
        LONGX_MUSA_CHECK(musaGetLastError());
        LONGX_MUSA_CHECK(musaDeviceSynchronize());
    }
#endif
    else {
        static_assert(detail::always_false_v<Space>, "Unsupported LongX::deep_copy fill space");
    }
}

template<typename T, typename Space>
View<T, HostSpace> create_mirror_view(const View<T, Space>& src) {
    return View<T, HostSpace>("mirror", src.extent());
}

template<typename T, typename DstSpace, typename SrcSpace>
void deep_copy(View2D<T, DstSpace>& dst, const View2D<T, SrcSpace>& src) {
    assert(dst.extent0() == src.extent0());
    assert(dst.extent1() == src.extent1());
    size_t bytes = sizeof(T) * dst.extent();

    if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                  detail::is_host_accessible_space<SrcSpace>::value) {
        std::copy(src.data(), src.data() + src.extent(), dst.data());
    }
#ifdef LONGX_ENABLE_CUDA
    else if constexpr (std::is_same_v<DstSpace, CudaSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, CudaSpace>) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, CudaSpace> &&
                         std::is_same_v<SrcSpace, CudaSpace>) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyDeviceToDevice));
    }
#endif
#ifdef LONGX_ENABLE_HIP
    else if constexpr (std::is_same_v<DstSpace, HipSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, HipSpace>) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, HipSpace> &&
                         std::is_same_v<SrcSpace, HipSpace>) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyDeviceToDevice));
    }
#endif
#ifdef LONGX_ENABLE_MUSA
    else if constexpr (std::is_same_v<DstSpace, MusaSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, MusaSpace>) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, MusaSpace> &&
                         std::is_same_v<SrcSpace, MusaSpace>) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyDeviceToDevice));
    }
#endif
    else {
        static_assert(detail::always_false_v<DstSpace>, "Unsupported LongX::deep_copy View2D spaces");
    }
}

template<typename T, typename Space>
void deep_copy(View2D<T, Space>& dst, const T& value) {
    if constexpr (detail::is_host_accessible_space<Space>::value) {
        std::fill(dst.data(), dst.data() + dst.extent(), value);
    }
#ifdef LONGX_ENABLE_CUDA
    else if constexpr (std::is_same_v<Space, CudaSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        detail::longx_cuda_fill_kernel<<<grid_size, block_size>>>(dst.data(), n, value);
        LONGX_CUDA_CHECK(cudaGetLastError());
        LONGX_CUDA_CHECK(cudaDeviceSynchronize());
    }
#endif
#ifdef LONGX_ENABLE_HIP
    else if constexpr (std::is_same_v<Space, HipSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        hipLaunchKernelGGL(
            detail::longx_hip_fill_kernel<T>,
            dim3(grid_size),
            dim3(block_size),
            0,
            0,
            dst.data(),
            n,
            value
        );
        LONGX_HIP_CHECK(hipGetLastError());
        LONGX_HIP_CHECK(hipDeviceSynchronize());
    }
#endif
#ifdef LONGX_ENABLE_MUSA
    else if constexpr (std::is_same_v<Space, MusaSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        detail::longx_musa_fill_kernel<<<grid_size, block_size>>>(dst.data(), n, value);
        LONGX_MUSA_CHECK(musaGetLastError());
        LONGX_MUSA_CHECK(musaDeviceSynchronize());
    }
#endif
    else {
        static_assert(detail::always_false_v<Space>, "Unsupported LongX::deep_copy View2D fill space");
    }
}

template<typename T, typename Space>
View2D<T, HostSpace> create_mirror_view(const View2D<T, Space>& src) {
    return View2D<T, HostSpace>("mirror2d", src.extent0(), src.extent1());
}

template<typename T, typename DstSpace, typename SrcSpace>
void deep_copy(View3D<T, DstSpace>& dst, const View3D<T, SrcSpace>& src) {
    assert(dst.extent0() == src.extent0());
    assert(dst.extent1() == src.extent1());
    assert(dst.extent2() == src.extent2());
    size_t bytes = sizeof(T) * dst.extent();

    if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                  detail::is_host_accessible_space<SrcSpace>::value) {
        std::copy(src.data(), src.data() + src.extent(), dst.data());
    }
#ifdef LONGX_ENABLE_CUDA
    else if constexpr (std::is_same_v<DstSpace, CudaSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, CudaSpace>) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, CudaSpace> &&
                         std::is_same_v<SrcSpace, CudaSpace>) {
        LONGX_CUDA_CHECK(cudaMemcpy(dst.data(), src.data(), bytes, cudaMemcpyDeviceToDevice));
    }
#endif
#ifdef LONGX_ENABLE_HIP
    else if constexpr (std::is_same_v<DstSpace, HipSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, HipSpace>) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, HipSpace> &&
                         std::is_same_v<SrcSpace, HipSpace>) {
        LONGX_HIP_CHECK(hipMemcpy(dst.data(), src.data(), bytes, hipMemcpyDeviceToDevice));
    }
#endif
#ifdef LONGX_ENABLE_MUSA
    else if constexpr (std::is_same_v<DstSpace, MusaSpace> &&
                       detail::is_host_accessible_space<SrcSpace>::value) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyHostToDevice));
    } else if constexpr (detail::is_host_accessible_space<DstSpace>::value &&
                         std::is_same_v<SrcSpace, MusaSpace>) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyDeviceToHost));
    } else if constexpr (std::is_same_v<DstSpace, MusaSpace> &&
                         std::is_same_v<SrcSpace, MusaSpace>) {
        LONGX_MUSA_CHECK(musaMemcpy(dst.data(), src.data(), bytes, musaMemcpyDeviceToDevice));
    }
#endif
    else {
        static_assert(detail::always_false_v<DstSpace>, "Unsupported LongX::deep_copy View3D spaces");
    }
}

template<typename T, typename Space>
void deep_copy(View3D<T, Space>& dst, const T& value) {
    if constexpr (detail::is_host_accessible_space<Space>::value) {
        std::fill(dst.data(), dst.data() + dst.extent(), value);
    }
#ifdef LONGX_ENABLE_CUDA
    else if constexpr (std::is_same_v<Space, CudaSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        detail::longx_cuda_fill_kernel<<<grid_size, block_size>>>(dst.data(), n, value);
        LONGX_CUDA_CHECK(cudaGetLastError());
        LONGX_CUDA_CHECK(cudaDeviceSynchronize());
    }
#endif
#ifdef LONGX_ENABLE_HIP
    else if constexpr (std::is_same_v<Space, HipSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        hipLaunchKernelGGL(
            detail::longx_hip_fill_kernel<T>,
            dim3(grid_size),
            dim3(block_size),
            0,
            0,
            dst.data(),
            n,
            value
        );
        LONGX_HIP_CHECK(hipGetLastError());
        LONGX_HIP_CHECK(hipDeviceSynchronize());
    }
#endif
#ifdef LONGX_ENABLE_MUSA
    else if constexpr (std::is_same_v<Space, MusaSpace>) {
        constexpr int block_size = 256;
        size_t n = dst.extent();
        if (n == 0) {
            return;
        }
        int grid_size = static_cast<int>((n + block_size - 1) / block_size);
        detail::longx_musa_fill_kernel<<<grid_size, block_size>>>(dst.data(), n, value);
        LONGX_MUSA_CHECK(musaGetLastError());
        LONGX_MUSA_CHECK(musaDeviceSynchronize());
    }
#endif
    else {
        static_assert(detail::always_false_v<Space>, "Unsupported LongX::deep_copy View3D fill space");
    }
}

template<typename T, typename Space>
View3D<T, HostSpace> create_mirror_view(const View3D<T, Space>& src) {
    return View3D<T, HostSpace>("mirror3d", src.extent0(), src.extent1(), src.extent2());
}

} // namespace LongX
