#pragma once

#include <cstddef>
#include <type_traits>

#include "longx_exec_space.hpp"
#include "longx_mpi_runtime.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"

namespace LongX {

template<typename Functor>
void parallel_for(const RangePolicy<MPI>& policy, Functor f) {
    const mpi::RangePartition partition =
        mpi::partition_range(policy.begin(), policy.end(), mpi::world_rank(), mpi::world_size());
    for (std::size_t i = partition.begin; i < partition.end; ++i) {
        f(i);
    }
}

template<typename Functor>
void parallel_for(const MDRangePolicy<MPI, 2>& policy, Functor f) {
    const std::size_t total = policy.size();
    if (total == 0) {
        return;
    }

    const mpi::RangePartition partition =
        mpi::partition_range(0, total, mpi::world_rank(), mpi::world_size());
    const std::size_t extent1 = policy.extent1();

    for (std::size_t index = partition.begin; index < partition.end; ++index) {
        const std::size_t i = policy.begin0() + index / extent1;
        const std::size_t j = policy.begin1() + index % extent1;
        f(i, j);
    }
}

template<typename Functor, typename ValueType>
void parallel_reduce(const RangePolicy<MPI>& policy, Functor f, ValueType& result) {
    ValueType local{};
    const mpi::RangePartition partition =
        mpi::partition_range(policy.begin(), policy.end(), mpi::world_rank(), mpi::world_size());
    for (std::size_t i = partition.begin; i < partition.end; ++i) {
        f(i, local);
    }
    result = mpi::allreduce_sum(local);
}

template<typename Functor, typename ValueType, typename Reducer>
void parallel_reduce(const RangePolicy<MPI>& policy, Functor f, ValueType& result, Reducer reducer) {
    ValueType local = reducer.init();
    const mpi::RangePartition partition =
        mpi::partition_range(policy.begin(), policy.end(), mpi::world_rank(), mpi::world_size());
    for (std::size_t i = partition.begin; i < partition.end; ++i) {
        ValueType value = reducer.init();
        f(i, value);
        reducer.join(local, value);
    }

    if constexpr (std::is_same_v<Reducer, Sum<ValueType>>) {
        result = mpi::allreduce_sum(local);
    } else if constexpr (std::is_same_v<Reducer, Min<ValueType>>) {
        result = mpi::allreduce_min(local);
    } else if constexpr (std::is_same_v<Reducer, Max<ValueType>>) {
        result = mpi::allreduce_max(local);
    } else {
        result = local;
    }
}

} // namespace LongX
