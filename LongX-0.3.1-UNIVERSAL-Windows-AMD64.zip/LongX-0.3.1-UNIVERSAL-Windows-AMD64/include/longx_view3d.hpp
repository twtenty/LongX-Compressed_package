#pragma once

#include <cassert>
#include <cstddef>
#include <utility>

#if defined(LONGX_ENABLE_CUDA) || defined(LONGX_ENABLE_HIP)
#include "longx_error.hpp"
#endif

#include "longx_device_view.hpp"
#include "longx_memory_space.hpp"

namespace LongX {

template<typename T, typename MemorySpace>
class View3D;

#ifdef LONGX_ENABLE_CUDA
template<typename T>
class View3D<T, CudaSpace> {
public:
    using value_type = T;
    using memory_space = CudaSpace;

    View3D(const char* label, size_t extent0, size_t extent1, size_t extent2)
    : data_(nullptr), extent0_(extent0), extent1_(extent1), extent2_(extent2), label_(label)
    {
        LONGX_CUDA_CHECK(cudaMalloc(
            reinterpret_cast<void**>(&data_),
            sizeof(T) * extent0_ * extent1_ * extent2_
        ));
    }

    ~View3D() {
        release();
    }

    View3D(const View3D&) = delete;
    View3D& operator=(const View3D&) = delete;

    View3D(View3D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      extent2_(std::exchange(other.extent2_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View3D& operator=(View3D&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            extent2_ = std::exchange(other.extent2_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_ * extent2_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t extent2() const { return extent2_; }
    size_t stride0() const { return extent1_ * extent2_; }
    size_t stride1() const { return extent2_; }
    T* data() const { return data_; }

    T& operator()(size_t, size_t, size_t) = delete;

    DeviceView3D<T> device() const {
        return DeviceView3D<T>{data_, extent0_, extent1_, extent2_, stride0(), stride1()};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_CUDA_CHECK(cudaFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent0_;
    size_t extent1_;
    size_t extent2_;
    const char* label_;
};
#endif

#ifdef LONGX_ENABLE_HIP
template<typename T>
class View3D<T, HipSpace> {
public:
    using value_type = T;
    using memory_space = HipSpace;

    View3D(const char* label, size_t extent0, size_t extent1, size_t extent2)
    : data_(nullptr), extent0_(extent0), extent1_(extent1), extent2_(extent2), label_(label)
    {
        LONGX_HIP_CHECK(hipMalloc(
            reinterpret_cast<void**>(&data_),
            sizeof(T) * extent0_ * extent1_ * extent2_
        ));
    }

    ~View3D() {
        release();
    }

    View3D(const View3D&) = delete;
    View3D& operator=(const View3D&) = delete;

    View3D(View3D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      extent2_(std::exchange(other.extent2_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View3D& operator=(View3D&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            extent2_ = std::exchange(other.extent2_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_ * extent2_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t extent2() const { return extent2_; }
    size_t stride0() const { return extent1_ * extent2_; }
    size_t stride1() const { return extent2_; }
    T* data() const { return data_; }

    T& operator()(size_t, size_t, size_t) = delete;

    DeviceView3D<T> device() const {
        return DeviceView3D<T>{data_, extent0_, extent1_, extent2_, stride0(), stride1()};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_HIP_CHECK(hipFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent0_;
    size_t extent1_;
    size_t extent2_;
    const char* label_;
};
#endif

template<typename T>
class View3D<T, HostSpace> {
public:
    using value_type = T;
    using memory_space = HostSpace;

    View3D(const char* label, size_t extent0, size_t extent1, size_t extent2)
    : data_(new T[extent0 * extent1 * extent2]),
      extent0_(extent0),
      extent1_(extent1),
      extent2_(extent2),
      label_(label)
    {}

    ~View3D() {
        delete[] data_;
    }

    View3D(const View3D&) = delete;
    View3D& operator=(const View3D&) = delete;

    View3D(View3D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      extent2_(std::exchange(other.extent2_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View3D& operator=(View3D&& other) noexcept {
        if (this != &other) {
            delete[] data_;
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            extent2_ = std::exchange(other.extent2_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_ * extent2_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t extent2() const { return extent2_; }
    size_t stride0() const { return extent1_ * extent2_; }
    size_t stride1() const { return extent2_; }
    T* data() const { return data_; }

    T& operator()(size_t i, size_t j, size_t k) {
        assert(i < extent0_);
        assert(j < extent1_);
        assert(k < extent2_);
        return data_[i * stride0() + j * stride1() + k];
    }

    const T& operator()(size_t i, size_t j, size_t k) const {
        assert(i < extent0_);
        assert(j < extent1_);
        assert(k < extent2_);
        return data_[i * stride0() + j * stride1() + k];
    }

    DeviceView3D<T> device() const {
        return DeviceView3D<T>{data_, extent0_, extent1_, extent2_, stride0(), stride1()};
    }

private:
    T* data_;
    size_t extent0_;
    size_t extent1_;
    size_t extent2_;
    const char* label_;
};

template<typename T>
class View3D<T, OpenMPSpace> : public View3D<T, HostSpace> {
public:
    using View3D<T, HostSpace>::View3D;
    using memory_space = OpenMPSpace;
};

} // namespace LongX
