#pragma once

#include "longx_macros.hpp"

namespace LongX {

struct Vec3 {
    float x;
    float y;
    float z;
};

struct Ray {
    Vec3 origin;
    Vec3 direction;
};

struct Triangle {
    Vec3 v0;
    Vec3 v1;
    Vec3 v2;
};

struct AABB {
    Vec3 min;
    Vec3 max;
};

LONGX_HD
inline Vec3 make_vec3(float x, float y, float z) {
    return Vec3{x, y, z};
}

LONGX_HD
inline Vec3 operator+(Vec3 a, Vec3 b) {
    return Vec3{a.x + b.x, a.y + b.y, a.z + b.z};
}

LONGX_HD
inline Vec3 operator-(Vec3 a, Vec3 b) {
    return Vec3{a.x - b.x, a.y - b.y, a.z - b.z};
}

LONGX_HD
inline Vec3 operator*(Vec3 a, float s) {
    return Vec3{a.x * s, a.y * s, a.z * s};
}

LONGX_HD
inline float dot(Vec3 a, Vec3 b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

LONGX_HD
inline Vec3 cross(Vec3 a, Vec3 b) {
    return Vec3{
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    };
}

LONGX_HD
inline float absf(float x) {
    return x < 0.0f ? -x : x;
}

LONGX_HD
inline float minf(float a, float b) {
    return a < b ? a : b;
}

LONGX_HD
inline float maxf(float a, float b) {
    return a > b ? a : b;
}

LONGX_HD
inline bool intersect_triangle(const Ray& ray, const Triangle& triangle, float& t) {
    const float eps = 1.0e-6f;
    Vec3 edge1 = triangle.v1 - triangle.v0;
    Vec3 edge2 = triangle.v2 - triangle.v0;
    Vec3 pvec = cross(ray.direction, edge2);
    float det = dot(edge1, pvec);

    if (absf(det) < eps) {
        return false;
    }

    float inv_det = 1.0f / det;
    Vec3 tvec = ray.origin - triangle.v0;
    float u = dot(tvec, pvec) * inv_det;
    if (u < 0.0f || u > 1.0f) {
        return false;
    }

    Vec3 qvec = cross(tvec, edge1);
    float v = dot(ray.direction, qvec) * inv_det;
    if (v < 0.0f || u + v > 1.0f) {
        return false;
    }

    float candidate_t = dot(edge2, qvec) * inv_det;
    if (candidate_t <= eps) {
        return false;
    }

    t = candidate_t;
    return true;
}

LONGX_HD
inline bool intersect_aabb(const Ray& ray, const AABB& box, float& tmin_out, float& tmax_out) {
    float tmin = 0.0f;
    float tmax = 1.0e30f;

    float origins[3] = {ray.origin.x, ray.origin.y, ray.origin.z};
    float dirs[3] = {ray.direction.x, ray.direction.y, ray.direction.z};
    float mins[3] = {box.min.x, box.min.y, box.min.z};
    float maxs[3] = {box.max.x, box.max.y, box.max.z};

    for (int axis = 0; axis < 3; ++axis) {
        float dir = dirs[axis];
        float origin = origins[axis];
        if (absf(dir) < 1.0e-8f) {
            if (origin < mins[axis] || origin > maxs[axis]) {
                return false;
            }
            continue;
        }

        float inv_dir = 1.0f / dir;
        float t0 = (mins[axis] - origin) * inv_dir;
        float t1 = (maxs[axis] - origin) * inv_dir;
        if (inv_dir < 0.0f) {
            float tmp = t0;
            t0 = t1;
            t1 = tmp;
        }

        tmin = maxf(tmin, t0);
        tmax = minf(tmax, t1);
        if (tmax < tmin) {
            return false;
        }
    }

    tmin_out = tmin;
    tmax_out = tmax;
    return true;
}

LONGX_HD
inline AABB triangle_bounds(const Triangle& triangle) {
    return AABB{
        Vec3{
            minf(triangle.v0.x, minf(triangle.v1.x, triangle.v2.x)),
            minf(triangle.v0.y, minf(triangle.v1.y, triangle.v2.y)),
            minf(triangle.v0.z, minf(triangle.v1.z, triangle.v2.z))
        },
        Vec3{
            maxf(triangle.v0.x, maxf(triangle.v1.x, triangle.v2.x)),
            maxf(triangle.v0.y, maxf(triangle.v1.y, triangle.v2.y)),
            maxf(triangle.v0.z, maxf(triangle.v1.z, triangle.v2.z))
        }
    };
}

} // namespace LongX
