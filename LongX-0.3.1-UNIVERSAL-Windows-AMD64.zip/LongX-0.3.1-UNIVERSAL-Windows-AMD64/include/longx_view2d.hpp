#pragma once

#include <cassert>
#include <cstddef>
#include <utility>

#if defined(LONGX_ENABLE_CUDA) || defined(LONGX_ENABLE_HIP)
#include "longx_error.hpp"
#endif

#include "longx_device_view.hpp"
#include "longx_memory_space.hpp"

namespace LongX {

template<typename T, typename MemorySpace>
class View2D;

#ifdef LONGX_ENABLE_CUDA
template<typename T>
class View2D<T, CudaSpace> {
public:
    using value_type = T;
    using memory_space = CudaSpace;

    View2D(const char* label, size_t extent0, size_t extent1)
    : data_(nullptr), extent0_(extent0), extent1_(extent1), label_(label)
    {
        LONGX_CUDA_CHECK(cudaMalloc(
            reinterpret_cast<void**>(&data_),
            sizeof(T) * extent0_ * extent1_
        ));
    }

    ~View2D() {
        release();
    }

    View2D(const View2D&) = delete;
    View2D& operator=(const View2D&) = delete;

    View2D(View2D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View2D& operator=(View2D&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t stride0() const { return extent1_; }
    T* data() const { return data_; }

    T& operator()(size_t, size_t) = delete;

    DeviceView2D<T> device() const {
        return DeviceView2D<T>{data_, extent0_, extent1_, stride0()};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_CUDA_CHECK(cudaFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent0_;
    size_t extent1_;
    const char* label_;
};
#endif

#ifdef LONGX_ENABLE_HIP
template<typename T>
class View2D<T, HipSpace> {
public:
    using value_type = T;
    using memory_space = HipSpace;

    View2D(const char* label, size_t extent0, size_t extent1)
    : data_(nullptr), extent0_(extent0), extent1_(extent1), label_(label)
    {
        LONGX_HIP_CHECK(hipMalloc(
            reinterpret_cast<void**>(&data_),
            sizeof(T) * extent0_ * extent1_
        ));
    }

    ~View2D() {
        release();
    }

    View2D(const View2D&) = delete;
    View2D& operator=(const View2D&) = delete;

    View2D(View2D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View2D& operator=(View2D&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t stride0() const { return extent1_; }
    T* data() const { return data_; }

    T& operator()(size_t, size_t) = delete;

    DeviceView2D<T> device() const {
        return DeviceView2D<T>{data_, extent0_, extent1_, stride0()};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_HIP_CHECK(hipFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent0_;
    size_t extent1_;
    const char* label_;
};
#endif

template<typename T>
class View2D<T, HostSpace> {
public:
    using value_type = T;
    using memory_space = HostSpace;

    View2D(const char* label, size_t extent0, size_t extent1)
    : data_(new T[extent0 * extent1]), extent0_(extent0), extent1_(extent1), label_(label)
    {}

    ~View2D() {
        delete[] data_;
    }

    View2D(const View2D&) = delete;
    View2D& operator=(const View2D&) = delete;

    View2D(View2D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View2D& operator=(View2D&& other) noexcept {
        if (this != &other) {
            delete[] data_;
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t stride0() const { return extent1_; }
    T* data() const { return data_; }

    T& operator()(size_t row, size_t col) {
        assert(row < extent0_);
        assert(col < extent1_);
        return data_[row * stride0() + col];
    }

    const T& operator()(size_t row, size_t col) const {
        assert(row < extent0_);
        assert(col < extent1_);
        return data_[row * stride0() + col];
    }

    DeviceView2D<T> device() const {
        return DeviceView2D<T>{data_, extent0_, extent1_, stride0()};
    }

private:
    T* data_;
    size_t extent0_;
    size_t extent1_;
    const char* label_;
};

template<typename T>
class View2D<T, OpenMPSpace> : public View2D<T, HostSpace> {
public:
    using View2D<T, HostSpace>::View2D;
    using memory_space = OpenMPSpace;
};

} // namespace LongX
