#pragma once

#include <cstddef>
#include <utility>

#include "longx_device_view.hpp"
#include "longx_error.hpp"
#include "longx_memory_space.hpp"

namespace LongX {

template<typename T, typename MemorySpace>
class View;

template<typename T>
class View<T, HipSpace> {
public:
    using value_type = T;
    using memory_space = HipSpace;

    View(const char* label, size_t n)
    : data_(nullptr), extent_(n), label_(label)
    {
        LONGX_HIP_CHECK(hipMalloc(reinterpret_cast<void**>(&data_), sizeof(T) * n));
    }

    ~View() {
        release();
    }

    View(const View&) = delete;
    View& operator=(const View&) = delete;

    View(View&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent_(std::exchange(other.extent_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View& operator=(View&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent_ = std::exchange(other.extent_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent_; }
    T* data() const { return data_; }

    T& operator()(size_t) = delete;

    DeviceView<T> device() const {
        return DeviceView<T>{data_, extent_};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_HIP_CHECK(hipFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent_;
    const char* label_;
};

} // namespace LongX
