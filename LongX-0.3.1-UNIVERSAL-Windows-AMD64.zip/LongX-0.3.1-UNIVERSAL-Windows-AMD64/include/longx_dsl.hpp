#pragma once

#include <cstddef>
#include <cctype>
#include <algorithm>
#include <functional>
#include <iomanip>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace LongX {
namespace dsl {

enum class OperationKind {
    Kernel,
    Fill,
    Copy,
    Transform,
    Reduce,
    BlasCopy,
    BlasScal,
    BlasAxpy,
    BlasDot,
    BlasNrm2,
    Custom
};

enum class AccessMode {
    Read,
    Write,
    ReadWrite
};

enum class DiagnosticSeverity {
    Warning,
    Error
};

enum class CodegenTarget {
    Default,
    Serial,
    OpenMP,
    Cuda,
    Hip,
    Musa,
    Sycl,
    MPI
};

struct RangeDescriptor {
    std::vector<size_t> begin;
    std::vector<size_t> end;

    size_t rank() const {
        return begin.size();
    }

    bool empty() const {
        if (begin.size() != end.size()) {
            return true;
        }
        for (size_t i = 0; i < begin.size(); ++i) {
            if (begin[i] >= end[i]) {
                return true;
            }
        }
        return false;
    }
};

struct KernelMetadata {
    std::string name;
    std::string backend_hint;
    std::string source_location;
    RangeDescriptor range;
    std::vector<std::string> tags;
};

struct ViewAccess {
    std::string view;
    AccessMode mode = AccessMode::Read;
};

struct Attribute {
    std::string key;
    std::string value;
};

struct GraphDiagnostic {
    DiagnosticSeverity severity = DiagnosticSeverity::Warning;
    size_t node_id = 0;
    std::string message;
};

struct GraphAnalysis {
    std::vector<GraphDiagnostic> diagnostics;
    std::vector<size_t> topological_order;
    size_t executable_nodes = 0;

    bool has_errors() const {
        for (const auto& diagnostic : diagnostics) {
            if (diagnostic.severity == DiagnosticSeverity::Error) {
                return true;
            }
        }
        return false;
    }
};

struct OperationNode {
    size_t id = 0;
    OperationKind kind = OperationKind::Custom;
    KernelMetadata kernel;
    std::vector<ViewAccess> accesses;
    std::vector<size_t> dependencies;
    std::vector<Attribute> attributes;
    std::function<void()> action;

    bool executable() const {
        return static_cast<bool>(action);
    }
};

inline const char* to_string(OperationKind kind) {
    switch (kind) {
    case OperationKind::Kernel: return "kernel";
    case OperationKind::Fill: return "fill";
    case OperationKind::Copy: return "copy";
    case OperationKind::Transform: return "transform";
    case OperationKind::Reduce: return "reduce";
    case OperationKind::BlasCopy: return "blas.copy";
    case OperationKind::BlasScal: return "blas.scal";
    case OperationKind::BlasAxpy: return "blas.axpy";
    case OperationKind::BlasDot: return "blas.dot";
    case OperationKind::BlasNrm2: return "blas.nrm2";
    case OperationKind::Custom: return "custom";
    }
    return "unknown";
}

inline const char* to_string(AccessMode mode) {
    switch (mode) {
    case AccessMode::Read: return "read";
    case AccessMode::Write: return "write";
    case AccessMode::ReadWrite: return "read_write";
    }
    return "unknown";
}

inline const char* to_string(DiagnosticSeverity severity) {
    switch (severity) {
    case DiagnosticSeverity::Warning: return "warning";
    case DiagnosticSeverity::Error: return "error";
    }
    return "unknown";
}

inline const char* to_string(CodegenTarget target) {
    switch (target) {
    case CodegenTarget::Default: return "default";
    case CodegenTarget::Serial: return "serial";
    case CodegenTarget::OpenMP: return "openmp";
    case CodegenTarget::Cuda: return "cuda";
    case CodegenTarget::Hip: return "hip";
    case CodegenTarget::Musa: return "musa";
    case CodegenTarget::Sycl: return "sycl";
    case CodegenTarget::MPI: return "mpi";
    }
    return "unknown";
}

inline RangeDescriptor range(size_t begin, size_t end) {
    return RangeDescriptor{{begin}, {end}};
}

inline RangeDescriptor md_range(size_t begin0, size_t begin1, size_t end0, size_t end1) {
    return RangeDescriptor{{begin0, begin1}, {end0, end1}};
}

class OperationBuilder {
public:
    OperationBuilder(std::string name, OperationKind kind)
    : node_{} {
        node_.kernel.name = std::move(name);
        node_.kind = kind;
    }

    OperationBuilder& range(size_t begin, size_t end) {
        node_.kernel.range = dsl::range(begin, end);
        return *this;
    }

    OperationBuilder& md_range(size_t begin0, size_t begin1, size_t end0, size_t end1) {
        node_.kernel.range = dsl::md_range(begin0, begin1, end0, end1);
        return *this;
    }

    OperationBuilder& backend_hint(std::string backend) {
        node_.kernel.backend_hint = std::move(backend);
        return *this;
    }

    OperationBuilder& source_location(std::string location) {
        node_.kernel.source_location = std::move(location);
        return *this;
    }

    OperationBuilder& tag(std::string value) {
        node_.kernel.tags.push_back(std::move(value));
        return *this;
    }

    OperationBuilder& read(std::string view) {
        node_.accesses.push_back(ViewAccess{std::move(view), AccessMode::Read});
        return *this;
    }

    OperationBuilder& write(std::string view) {
        node_.accesses.push_back(ViewAccess{std::move(view), AccessMode::Write});
        return *this;
    }

    OperationBuilder& read_write(std::string view) {
        node_.accesses.push_back(ViewAccess{std::move(view), AccessMode::ReadWrite});
        return *this;
    }

    OperationBuilder& depends_on(size_t id) {
        node_.dependencies.push_back(id);
        return *this;
    }

    OperationBuilder& attribute(std::string key, std::string value) {
        node_.attributes.push_back(Attribute{std::move(key), std::move(value)});
        return *this;
    }

    OperationBuilder& action(std::function<void()> fn) {
        node_.action = std::move(fn);
        return *this;
    }

    OperationNode build() const {
        return node_;
    }

private:
    OperationNode node_;
};

inline OperationBuilder operation(std::string name, OperationKind kind = OperationKind::Kernel) {
    return OperationBuilder(std::move(name), kind);
}

inline OperationBuilder kernel(std::string name) {
    return operation(std::move(name), OperationKind::Kernel);
}

class OperationGraph {
public:
    size_t add(OperationNode node) {
        node.id = nodes_.size();
        nodes_.push_back(std::move(node));
        return nodes_.back().id;
    }

    size_t add(const OperationBuilder& builder) {
        return add(builder.build());
    }

    size_t add_fill(std::string name, std::string dst, size_t count) {
        return add(operation(std::move(name), OperationKind::Fill)
            .range(0, count)
            .write(std::move(dst)));
    }

    size_t add_copy(std::string name, std::string src, std::string dst, size_t count) {
        return add(operation(std::move(name), OperationKind::Copy)
            .range(0, count)
            .read(std::move(src))
            .write(std::move(dst)));
    }

    size_t add_transform(std::string name, std::string src, std::string dst, size_t count) {
        return add(operation(std::move(name), OperationKind::Transform)
            .range(0, count)
            .read(std::move(src))
            .write(std::move(dst)));
    }

    size_t add_reduce(std::string name, std::string src, std::string result, size_t count) {
        return add(operation(std::move(name), OperationKind::Reduce)
            .range(0, count)
            .read(std::move(src))
            .write(std::move(result)));
    }

    void add_dependency(size_t before, size_t after) {
        if (before >= nodes_.size() || after >= nodes_.size()) {
            throw std::out_of_range("LongX::dsl::OperationGraph dependency id is out of range");
        }
        if (before == after) {
            throw std::invalid_argument("LongX::dsl::OperationGraph dependency cannot target itself");
        }
        if (has_direct_dependency(before, after)) {
            return;
        }
        nodes_[after].dependencies.push_back(before);
    }

    const OperationNode& node(size_t id) const {
        if (id >= nodes_.size()) {
            throw std::out_of_range("LongX::dsl::OperationGraph node id is out of range");
        }
        return nodes_[id];
    }

    size_t size() const {
        return nodes_.size();
    }

    bool empty() const {
        return nodes_.empty();
    }

    const std::vector<OperationNode>& nodes() const {
        return nodes_;
    }

    std::vector<GraphDiagnostic> validate() const {
        std::vector<GraphDiagnostic> diagnostics;
        for (size_t i = 0; i < nodes_.size(); ++i) {
            const auto& current = nodes_[i];
            if (current.id != i) {
                diagnostics.push_back(error(i, "node id does not match graph position"));
            }
            if (current.kernel.name.empty()) {
                diagnostics.push_back(error(i, "operation name is empty"));
            }
            if (current.kernel.range.begin.size() != current.kernel.range.end.size()) {
                diagnostics.push_back(error(i, "range begin/end rank mismatch"));
            } else if (current.kernel.range.rank() != 0 && current.kernel.range.empty()) {
                diagnostics.push_back(warning(i, "range is empty"));
            }
            for (const auto& access : current.accesses) {
                if (access.view.empty()) {
                    diagnostics.push_back(error(i, "view access name is empty"));
                }
            }
            for (size_t dep_index = 0; dep_index < current.dependencies.size(); ++dep_index) {
                const size_t dependency = current.dependencies[dep_index];
                if (dependency >= nodes_.size()) {
                    diagnostics.push_back(error(i, "dependency id is out of range"));
                } else if (dependency == i) {
                    diagnostics.push_back(error(i, "operation depends on itself"));
                }
                for (size_t previous = 0; previous < dep_index; ++previous) {
                    if (current.dependencies[previous] == dependency) {
                        diagnostics.push_back(warning(i, "duplicate dependency id"));
                        break;
                    }
                }
            }
        }
        if (contains_cycle()) {
            diagnostics.push_back(error(nodes_.size(), "dependency graph contains a cycle"));
        }
        return diagnostics;
    }

    std::vector<size_t> topological_order() const {
        for (const auto& diagnostic : validate()) {
            if (diagnostic.severity == DiagnosticSeverity::Error) {
                throw std::runtime_error("LongX::dsl::OperationGraph is not valid");
            }
        }
        return topological_order_unchecked();
    }

    GraphAnalysis analyze() const {
        GraphAnalysis analysis;
        analysis.diagnostics = validate();
        for (const auto& node : nodes_) {
            if (node.executable()) {
                ++analysis.executable_nodes;
            }
        }
        if (!analysis.has_errors()) {
            analysis.topological_order = topological_order_unchecked();
        }
        return analysis;
    }

    bool has_dependency_path(size_t before, size_t after) const {
        if (before >= nodes_.size() || after >= nodes_.size()) {
            throw std::out_of_range("LongX::dsl::OperationGraph dependency id is out of range");
        }
        std::vector<bool> visited(nodes_.size(), false);
        return has_dependency_path_impl(before, after, visited);
    }

    size_t infer_data_dependencies() {
        size_t added = 0;
        for (size_t before = 0; before < nodes_.size(); ++before) {
            for (size_t after = before + 1; after < nodes_.size(); ++after) {
                if (accesses_conflict(nodes_[before], nodes_[after]) &&
                    !has_dependency_path(before, after)) {
                    add_dependency(before, after);
                    ++added;
                }
            }
        }
        return added;
    }

    size_t execute() const {
        size_t executed = 0;
        for (size_t id : topological_order()) {
            const auto& current = nodes_[id];
            if (current.action) {
                current.action();
                ++executed;
            }
        }
        return executed;
    }

    std::string to_text() const {
        std::ostringstream out;
        out << "LongX DSL operation graph\n";
        out << "nodes=" << nodes_.size() << "\n";
        for (const auto& node : nodes_) {
            out << "[" << node.id << "] " << to_string(node.kind)
                << " name=" << node.kernel.name;
            if (!node.kernel.backend_hint.empty()) {
                out << " backend=" << node.kernel.backend_hint;
            }
            if (node.kernel.range.rank() != 0) {
                out << " range=";
                append_range(out, node.kernel.range);
            }
            out << "\n";

            if (!node.accesses.empty()) {
                out << "  accesses:";
                for (const auto& access : node.accesses) {
                    out << " " << to_string(access.mode) << "(" << access.view << ")";
                }
                out << "\n";
            }

            if (!node.dependencies.empty()) {
                out << "  depends_on:";
                for (size_t dependency : node.dependencies) {
                    out << " " << dependency;
                }
                out << "\n";
            }

            if (!node.attributes.empty()) {
                out << "  attributes:";
                for (const auto& attribute : node.attributes) {
                    out << " " << attribute.key << "=" << attribute.value;
                }
                out << "\n";
            }

            if (node.executable()) {
                out << "  action: executable\n";
            }
        }
        return out.str();
    }

    std::string to_json() const {
        const GraphAnalysis analysis = analyze();
        std::ostringstream out;
        out << "{\n";
        out << "  \"format\": \"longx.dsl.operation_graph\",\n";
        out << "  \"version\": 1,\n";
        out << "  \"node_count\": " << nodes_.size() << ",\n";
        out << "  \"executable_nodes\": " << analysis.executable_nodes << ",\n";
        out << "  \"nodes\": [\n";
        for (size_t node_index = 0; node_index < nodes_.size(); ++node_index) {
            const auto& node = nodes_[node_index];
            out << "    {\n";
            out << "      \"id\": " << node.id << ",\n";
            out << "      \"kind\": ";
            append_json_string(out, to_string(node.kind));
            out << ",\n";
            out << "      \"name\": ";
            append_json_string(out, node.kernel.name);
            out << ",\n";
            out << "      \"backend_hint\": ";
            append_json_string(out, node.kernel.backend_hint);
            out << ",\n";
            out << "      \"source_location\": ";
            append_json_string(out, node.kernel.source_location);
            out << ",\n";
            out << "      \"range\": {\n";
            out << "        \"rank\": " << node.kernel.range.rank() << ",\n";
            out << "        \"begin\": ";
            append_json_size_array(out, node.kernel.range.begin);
            out << ",\n";
            out << "        \"end\": ";
            append_json_size_array(out, node.kernel.range.end);
            out << "\n";
            out << "      },\n";
            out << "      \"tags\": ";
            append_json_string_array(out, node.kernel.tags);
            out << ",\n";
            out << "      \"accesses\": [";
            for (size_t access_index = 0; access_index < node.accesses.size(); ++access_index) {
                const auto& access = node.accesses[access_index];
                if (access_index != 0) {
                    out << ", ";
                }
                out << "{\"view\": ";
                append_json_string(out, access.view);
                out << ", \"mode\": ";
                append_json_string(out, to_string(access.mode));
                out << "}";
            }
            out << "],\n";
            out << "      \"dependencies\": ";
            append_json_size_array(out, node.dependencies);
            out << ",\n";
            out << "      \"attributes\": [";
            for (size_t attribute_index = 0; attribute_index < node.attributes.size(); ++attribute_index) {
                const auto& attribute = node.attributes[attribute_index];
                if (attribute_index != 0) {
                    out << ", ";
                }
                out << "{\"key\": ";
                append_json_string(out, attribute.key);
                out << ", \"value\": ";
                append_json_string(out, attribute.value);
                out << "}";
            }
            out << "],\n";
            out << "      \"executable\": " << (node.executable() ? "true" : "false") << "\n";
            out << "    }";
            if (node_index + 1 != nodes_.size()) {
                out << ",";
            }
            out << "\n";
        }
        out << "  ],\n";
        out << "  \"analysis\": {\n";
        out << "    \"has_errors\": " << (analysis.has_errors() ? "true" : "false") << ",\n";
        out << "    \"topological_order\": ";
        append_json_size_array(out, analysis.topological_order);
        out << ",\n";
        out << "    \"diagnostics\": [";
        for (size_t diagnostic_index = 0; diagnostic_index < analysis.diagnostics.size(); ++diagnostic_index) {
            const auto& diagnostic = analysis.diagnostics[diagnostic_index];
            if (diagnostic_index != 0) {
                out << ", ";
            }
            out << "{\"severity\": ";
            append_json_string(out, to_string(diagnostic.severity));
            out << ", \"node_id\": " << diagnostic.node_id << ", \"message\": ";
            append_json_string(out, diagnostic.message);
            out << "}";
        }
        out << "]\n";
        out << "  }\n";
        out << "}\n";
        return out.str();
    }

    std::string to_mermaid() const {
        std::ostringstream out;
        out << "flowchart TD\n";
        for (const auto& node : nodes_) {
            out << "  n" << node.id << "[\"";
            append_mermaid_label(out, node);
            out << "\"]\n";
        }
        for (const auto& node : nodes_) {
            for (size_t dependency : node.dependencies) {
                if (dependency < nodes_.size()) {
                    out << "  n" << dependency << " --> n" << node.id << "\n";
                }
            }
        }
        return out.str();
    }

    std::string to_html(std::string title = "LongX DSL Operation Graph") const {
        const GraphAnalysis analysis = analyze();
        const size_t dependency_edges = edge_count();
        const std::vector<std::string> views = accessed_views();
        const size_t warnings = diagnostic_count(analysis, DiagnosticSeverity::Warning);
        const size_t errors = diagnostic_count(analysis, DiagnosticSeverity::Error);
        std::ostringstream out;
        out << "<!doctype html>\n";
        out << "<html lang=\"en\">\n";
        out << "<head>\n";
        out << "  <meta charset=\"utf-8\">\n";
        out << "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n";
        out << "  <title>";
        append_html_escaped(out, title);
        out << "</title>\n";
        out << "  <style>body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#1f2937;background:#ffffff;} ";
        out << "h1{font-size:24px;margin:0 0 6px;} h2{font-size:18px;margin:24px 0 10px;} ";
        out << ".meta{color:#4b5563;margin-bottom:16px;} ";
        out << ".summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(132px,1fr));gap:10px;margin:16px 0;} ";
        out << ".metric{border:1px solid #d1d5db;border-radius:6px;padding:10px;background:#f9fafb;} ";
        out << ".metric b{display:block;font-size:20px;color:#111827;} .metric span{font-size:12px;color:#4b5563;} ";
        out << ".status-ok{color:#047857;} .status-error{color:#b91c1c;} ";
        out << ".mermaid{border:1px solid #d1d5db;padding:16px;border-radius:6px;overflow:auto;background:#ffffff;} ";
        out << "table{border-collapse:collapse;width:100%;font-size:13px;} th,td{border:1px solid #e5e7eb;padding:7px;text-align:left;vertical-align:top;} ";
        out << "th{background:#f3f4f6;} code{font-family:Consolas,monospace;} ";
        out << "pre{background:#f9fafb;border:1px solid #e5e7eb;padding:12px;border-radius:6px;overflow:auto;}</style>\n";
        out << "  <script type=\"module\">import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs'; mermaid.initialize({startOnLoad:true});</script>\n";
        out << "</head>\n";
        out << "<body>\n";
        out << "  <h1>";
        append_html_escaped(out, title);
        out << "</h1>\n";
        out << "  <div class=\"meta\">LongX OperationGraph visualization report</div>\n";
        out << "  <section class=\"summary\">\n";
        append_html_metric(out, "Nodes", nodes_.size());
        append_html_metric(out, "Edges", dependency_edges);
        append_html_metric(out, "Views", views.size());
        append_html_metric(out, "Executable", analysis.executable_nodes);
        append_html_metric(out, "Warnings", warnings);
        append_html_metric(out, "Errors", errors);
        out << "  </section>\n";
        out << "  <div class=\"mermaid\">\n";
        append_html_escaped(out, to_mermaid());
        out << "  </div>\n";
        out << "  <h2>Operation Table</h2>\n";
        out << "  <table><thead><tr><th>ID</th><th>Name</th><th>Kind</th><th>Range</th><th>Accesses</th><th>Depends On</th></tr></thead><tbody>\n";
        for (const auto& node : nodes_) {
            out << "    <tr><td>" << node.id << "</td><td>";
            append_html_escaped(out, node.kernel.name);
            out << "</td><td><code>";
            append_html_escaped(out, to_string(node.kind));
            out << "</code></td><td>";
            append_html_range(out, node.kernel.range);
            out << "</td><td>";
            append_html_accesses(out, node.accesses);
            out << "</td><td>";
            append_html_dependencies(out, node.dependencies);
            out << "</td></tr>\n";
        }
        out << "  </tbody></table>\n";
        out << "  <h2>Analysis</h2>\n";
        out << "  <div class=\"meta\">";
        out << "<span class=\"" << (analysis.has_errors() ? "status-error" : "status-ok") << "\">";
        out << (analysis.has_errors() ? "invalid graph" : "valid graph") << "</span>";
        out << "; topological_order=";
        append_html_size_list(out, analysis.topological_order);
        out << "</div>\n";
        if (!analysis.diagnostics.empty()) {
            out << "  <table><thead><tr><th>Severity</th><th>Node</th><th>Message</th></tr></thead><tbody>\n";
            for (const auto& diagnostic : analysis.diagnostics) {
                out << "    <tr><td><code>";
                append_html_escaped(out, to_string(diagnostic.severity));
                out << "</code></td><td>" << diagnostic.node_id << "</td><td>";
                append_html_escaped(out, diagnostic.message);
                out << "</td></tr>\n";
            }
            out << "  </tbody></table>\n";
        }
        out << "  <h2>Graph JSON</h2>\n";
        out << "  <pre>";
        append_html_escaped(out, to_json());
        out << "</pre>\n";
        out << "</body>\n";
        out << "</html>\n";
        return out.str();
    }

    std::string to_markdown_report(std::string title = "LongX DSL Operation Graph") const {
        const GraphAnalysis analysis = analyze();
        const std::vector<std::string> views = accessed_views();
        std::ostringstream out;
        out << "# " << title << "\n\n";
        out << "Format: `longx.dsl.operation_graph`\n\n";
        out << "## Summary\n\n";
        out << "| Metric | Value |\n";
        out << "|---|---:|\n";
        out << "| Nodes | " << nodes_.size() << " |\n";
        out << "| Dependency edges | " << edge_count() << " |\n";
        out << "| Accessed views | " << views.size() << " |\n";
        out << "| Executable nodes | " << analysis.executable_nodes << " |\n";
        out << "| Warnings | " << diagnostic_count(analysis, DiagnosticSeverity::Warning) << " |\n";
        out << "| Errors | " << diagnostic_count(analysis, DiagnosticSeverity::Error) << " |\n\n";

        out << "## Operations\n\n";
        out << "| ID | Name | Kind | Range | Accesses | Depends On |\n";
        out << "|---:|---|---|---|---|---|\n";
        for (const auto& node : nodes_) {
            out << "| " << node.id << " | ";
            append_markdown_cell(out, node.kernel.name);
            out << " | `" << to_string(node.kind) << "` | ";
            append_markdown_range(out, node.kernel.range);
            out << " | ";
            append_markdown_accesses(out, node.accesses);
            out << " | ";
            append_markdown_dependencies(out, node.dependencies);
            out << " |\n";
        }

        out << "\n## Topological Order\n\n";
        if (analysis.topological_order.empty()) {
            out << "Unavailable because the graph has validation errors.\n";
        } else {
            out << "`";
            append_markdown_size_list(out, analysis.topological_order);
            out << "`\n";
        }

        out << "\n## Mermaid\n\n";
        out << "```mermaid\n";
        out << to_mermaid();
        out << "```\n";

        if (!analysis.diagnostics.empty()) {
            out << "\n## Diagnostics\n\n";
            out << "| Severity | Node | Message |\n";
            out << "|---|---:|---|\n";
            for (const auto& diagnostic : analysis.diagnostics) {
                out << "| `" << to_string(diagnostic.severity) << "` | "
                    << diagnostic.node_id << " | ";
                append_markdown_cell(out, diagnostic.message);
                out << " |\n";
            }
        }
        return out.str();
    }

private:
    static GraphDiagnostic warning(size_t node_id, std::string message) {
        return GraphDiagnostic{DiagnosticSeverity::Warning, node_id, std::move(message)};
    }

    static GraphDiagnostic error(size_t node_id, std::string message) {
        return GraphDiagnostic{DiagnosticSeverity::Error, node_id, std::move(message)};
    }

    static void append_range(std::ostringstream& out, const RangeDescriptor& range) {
        out << "[";
        for (size_t i = 0; i < range.rank(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << range.begin[i] << ".." << range.end[i];
        }
        out << "]";
    }

    static void append_json_string(std::ostringstream& out, const std::string& value) {
        out << std::quoted(value);
    }

    static void append_json_size_array(std::ostringstream& out, const std::vector<size_t>& values) {
        out << "[";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << values[i];
        }
        out << "]";
    }

    static void append_json_string_array(std::ostringstream& out, const std::vector<std::string>& values) {
        out << "[";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            append_json_string(out, values[i]);
        }
        out << "]";
    }

    static void append_mermaid_escaped(std::ostringstream& out, const std::string& value) {
        for (char ch : value) {
            switch (ch) {
            case '"': out << '\''; break;
            case '\n': out << ' '; break;
            case '\r': break;
            case '<': out << "&lt;"; break;
            case '>': out << "&gt;"; break;
            case '&': out << "&amp;"; break;
            default: out << ch; break;
            }
        }
    }

    static void append_mermaid_label(std::ostringstream& out, const OperationNode& node) {
        out << node.id << ": ";
        append_mermaid_escaped(out, node.kernel.name);
        out << "<br/>";
        append_mermaid_escaped(out, to_string(node.kind));
        if (node.kernel.range.rank() != 0) {
            out << "<br/>";
            for (size_t i = 0; i < node.kernel.range.rank(); ++i) {
                if (i != 0) {
                    out << ", ";
                }
                out << node.kernel.range.begin[i] << ".." << node.kernel.range.end[i];
            }
        }
    }

    static void append_html_escaped(std::ostringstream& out, const std::string& value) {
        for (char ch : value) {
            switch (ch) {
            case '&': out << "&amp;"; break;
            case '<': out << "&lt;"; break;
            case '>': out << "&gt;"; break;
            case '"': out << "&quot;"; break;
            case '\'': out << "&#39;"; break;
            default: out << ch; break;
            }
        }
    }

    static void append_html_metric(std::ostringstream& out, const char* label, size_t value) {
        out << "    <div class=\"metric\"><b>" << value << "</b><span>";
        append_html_escaped(out, label);
        out << "</span></div>\n";
    }

    static void append_html_range(std::ostringstream& out, const RangeDescriptor& range) {
        if (range.rank() == 0) {
            out << "-";
            return;
        }
        out << "<code>";
        for (size_t i = 0; i < range.rank(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << range.begin[i] << ".." << range.end[i];
        }
        out << "</code>";
    }

    static void append_html_accesses(std::ostringstream& out, const std::vector<ViewAccess>& accesses) {
        if (accesses.empty()) {
            out << "-";
            return;
        }
        for (size_t i = 0; i < accesses.size(); ++i) {
            if (i != 0) {
                out << "<br>";
            }
            out << "<code>";
            append_html_escaped(out, to_string(accesses[i].mode));
            out << "(";
            append_html_escaped(out, accesses[i].view);
            out << ")</code>";
        }
    }

    static void append_html_dependencies(std::ostringstream& out, const std::vector<size_t>& dependencies) {
        if (dependencies.empty()) {
            out << "-";
            return;
        }
        append_html_size_list(out, dependencies);
    }

    static void append_html_size_list(std::ostringstream& out, const std::vector<size_t>& values) {
        out << "[";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << values[i];
        }
        out << "]";
    }

    static void append_markdown_cell(std::ostringstream& out, const std::string& value) {
        for (char ch : value) {
            switch (ch) {
            case '|': out << "\\|"; break;
            case '\n': out << "<br>"; break;
            case '\r': break;
            default: out << ch; break;
            }
        }
    }

    static void append_markdown_range(std::ostringstream& out, const RangeDescriptor& range) {
        if (range.rank() == 0) {
            out << "-";
            return;
        }
        out << "`";
        for (size_t i = 0; i < range.rank(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << range.begin[i] << ".." << range.end[i];
        }
        out << "`";
    }

    static void append_markdown_accesses(std::ostringstream& out, const std::vector<ViewAccess>& accesses) {
        if (accesses.empty()) {
            out << "-";
            return;
        }
        for (size_t i = 0; i < accesses.size(); ++i) {
            if (i != 0) {
                out << "<br>";
            }
            out << "`" << to_string(accesses[i].mode) << "(";
            append_markdown_cell(out, accesses[i].view);
            out << ")`";
        }
    }

    static void append_markdown_dependencies(std::ostringstream& out, const std::vector<size_t>& dependencies) {
        if (dependencies.empty()) {
            out << "-";
            return;
        }
        append_markdown_size_list(out, dependencies);
    }

    static void append_markdown_size_list(std::ostringstream& out, const std::vector<size_t>& values) {
        out << "[";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << values[i];
        }
        out << "]";
    }

    size_t edge_count() const {
        size_t count = 0;
        for (const auto& node : nodes_) {
            count += node.dependencies.size();
        }
        return count;
    }

    std::vector<std::string> accessed_views() const {
        std::vector<std::string> views;
        for (const auto& node : nodes_) {
            for (const auto& access : node.accesses) {
                if (access.view.empty()) {
                    continue;
                }
                bool found = false;
                for (const auto& view : views) {
                    if (view == access.view) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    views.push_back(access.view);
                }
            }
        }
        return views;
    }

    static size_t diagnostic_count(const GraphAnalysis& analysis, DiagnosticSeverity severity) {
        size_t count = 0;
        for (const auto& diagnostic : analysis.diagnostics) {
            if (diagnostic.severity == severity) {
                ++count;
            }
        }
        return count;
    }

    static bool is_write_access(AccessMode mode) {
        return mode == AccessMode::Write || mode == AccessMode::ReadWrite;
    }

    static bool access_conflicts(const ViewAccess& a, const ViewAccess& b) {
        return !a.view.empty() &&
               a.view == b.view &&
               (is_write_access(a.mode) || is_write_access(b.mode));
    }

    static bool accesses_conflict(const OperationNode& a, const OperationNode& b) {
        for (const auto& left : a.accesses) {
            for (const auto& right : b.accesses) {
                if (access_conflicts(left, right)) {
                    return true;
                }
            }
        }
        return false;
    }

    bool has_direct_dependency(size_t before, size_t after) const {
        for (size_t dependency : nodes_[after].dependencies) {
            if (dependency == before) {
                return true;
            }
        }
        return false;
    }

    bool has_dependency_path_impl(size_t before, size_t after, std::vector<bool>& visited) const {
        if (visited[after]) {
            return false;
        }
        visited[after] = true;
        for (size_t dependency : nodes_[after].dependencies) {
            if (dependency == before) {
                return true;
            }
            if (dependency < nodes_.size() && has_dependency_path_impl(before, dependency, visited)) {
                return true;
            }
        }
        return false;
    }

    bool contains_cycle() const {
        return topological_order_unchecked().size() != nodes_.size();
    }

    std::vector<size_t> topological_order_unchecked() const {
        std::vector<size_t> indegree(nodes_.size(), 0);
        std::vector<std::vector<size_t>> outgoing(nodes_.size());
        for (size_t node_id = 0; node_id < nodes_.size(); ++node_id) {
            for (size_t dependency : nodes_[node_id].dependencies) {
                if (dependency < nodes_.size()) {
                    outgoing[dependency].push_back(node_id);
                    ++indegree[node_id];
                }
            }
        }

        std::vector<size_t> order;
        std::vector<bool> used(nodes_.size(), false);
        order.reserve(nodes_.size());
        for (size_t step = 0; step < nodes_.size(); ++step) {
            bool found = false;
            for (size_t candidate = 0; candidate < nodes_.size(); ++candidate) {
                if (!used[candidate] && indegree[candidate] == 0) {
                    used[candidate] = true;
                    order.push_back(candidate);
                    for (size_t dependent : outgoing[candidate]) {
                        --indegree[dependent];
                    }
                    found = true;
                    break;
                }
            }
            if (!found) {
                break;
            }
        }
        return order;
    }

    std::vector<OperationNode> nodes_;
};

struct FrontendDiagnostic {
    DiagnosticSeverity severity = DiagnosticSeverity::Warning;
    size_t line = 0;
    std::string message;
};

struct FrontendResult {
    OperationGraph graph;
    std::vector<FrontendDiagnostic> diagnostics;

    bool ok() const {
        for (const auto& diagnostic : diagnostics) {
            if (diagnostic.severity == DiagnosticSeverity::Error) {
                return false;
            }
        }
        return true;
    }
};

struct KernelIRNode {
    size_t id = 0;
    std::vector<size_t> source_node_ids;
    OperationKind kind = OperationKind::Custom;
    std::string name;
    std::string parallel_pattern;
    std::string backend_hint;
    std::string source_location;
    RangeDescriptor range;
    std::vector<std::string> reads;
    std::vector<std::string> writes;
    std::vector<std::string> read_writes;
    std::vector<size_t> dependencies;
    std::vector<std::string> tags;
    std::vector<Attribute> attributes;
};

struct KernelIROptions {
    bool drop_dead_nodes = false;
    bool fuse_adjacent_maps = false;
};

struct KernelIRModule {
    int version = 1;
    std::vector<KernelIRNode> nodes;
    std::vector<GraphDiagnostic> diagnostics;

    bool ok() const {
        for (const auto& diagnostic : diagnostics) {
            if (diagnostic.severity == DiagnosticSeverity::Error) {
                return false;
            }
        }
        return true;
    }

    std::string to_text() const {
        std::ostringstream out;
        out << "LongX DSL kernel IR\n";
        out << "version=" << version << "\n";
        out << "nodes=" << nodes.size() << "\n";
        for (const auto& node : nodes) {
            out << "[" << node.id << "] " << node.parallel_pattern
                << " name=" << node.name
                << " kind=" << to_string(node.kind);
            if (node.range.rank() != 0) {
                out << " range=";
                append_ir_range(out, node.range);
            }
            if (!node.dependencies.empty()) {
                out << " depends_on=";
                append_ir_size_list(out, node.dependencies);
            }
            out << "\n";
        }
        return out.str();
    }

    std::string to_json() const {
        std::ostringstream out;
        out << "{\n";
        out << "  \"format\": \"longx.dsl.kernel_ir\",\n";
        out << "  \"version\": " << version << ",\n";
        out << "  \"node_count\": " << nodes.size() << ",\n";
        out << "  \"nodes\": [\n";
        for (size_t node_index = 0; node_index < nodes.size(); ++node_index) {
            const auto& node = nodes[node_index];
            out << "    {\n";
            out << "      \"id\": " << node.id << ",\n";
            out << "      \"source_node_ids\": ";
            append_ir_size_array(out, node.source_node_ids);
            out << ",\n";
            out << "      \"kind\": ";
            append_ir_json_string(out, to_string(node.kind));
            out << ",\n";
            out << "      \"name\": ";
            append_ir_json_string(out, node.name);
            out << ",\n";
            out << "      \"parallel_pattern\": ";
            append_ir_json_string(out, node.parallel_pattern);
            out << ",\n";
            out << "      \"backend_hint\": ";
            append_ir_json_string(out, node.backend_hint);
            out << ",\n";
            out << "      \"source_location\": ";
            append_ir_json_string(out, node.source_location);
            out << ",\n";
            out << "      \"range\": {\"rank\": " << node.range.rank() << ", \"begin\": ";
            append_ir_size_array(out, node.range.begin);
            out << ", \"end\": ";
            append_ir_size_array(out, node.range.end);
            out << "},\n";
            out << "      \"reads\": ";
            append_ir_string_array(out, node.reads);
            out << ",\n";
            out << "      \"writes\": ";
            append_ir_string_array(out, node.writes);
            out << ",\n";
            out << "      \"read_writes\": ";
            append_ir_string_array(out, node.read_writes);
            out << ",\n";
            out << "      \"dependencies\": ";
            append_ir_size_array(out, node.dependencies);
            out << ",\n";
            out << "      \"tags\": ";
            append_ir_string_array(out, node.tags);
            out << ",\n";
            out << "      \"attributes\": [";
            for (size_t attr_index = 0; attr_index < node.attributes.size(); ++attr_index) {
                if (attr_index != 0) {
                    out << ", ";
                }
                out << "{\"key\": ";
                append_ir_json_string(out, node.attributes[attr_index].key);
                out << ", \"value\": ";
                append_ir_json_string(out, node.attributes[attr_index].value);
                out << "}";
            }
            out << "]\n";
            out << "    }";
            if (node_index + 1 != nodes.size()) {
                out << ",";
            }
            out << "\n";
        }
        out << "  ],\n";
        out << "  \"diagnostics\": [";
        for (size_t diag_index = 0; diag_index < diagnostics.size(); ++diag_index) {
            if (diag_index != 0) {
                out << ", ";
            }
            out << "{\"severity\": ";
            append_ir_json_string(out, to_string(diagnostics[diag_index].severity));
            out << ", \"node_id\": " << diagnostics[diag_index].node_id << ", \"message\": ";
            append_ir_json_string(out, diagnostics[diag_index].message);
            out << "}";
        }
        out << "]\n";
        out << "}\n";
        return out.str();
    }

private:
    static void append_ir_json_string(std::ostringstream& out, const std::string& value) {
        out << std::quoted(value);
    }

    static void append_ir_size_array(std::ostringstream& out, const std::vector<size_t>& values) {
        out << "[";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << values[i];
        }
        out << "]";
    }

    static void append_ir_string_array(std::ostringstream& out, const std::vector<std::string>& values) {
        out << "[";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            append_ir_json_string(out, values[i]);
        }
        out << "]";
    }

    static void append_ir_size_list(std::ostringstream& out, const std::vector<size_t>& values) {
        out << "[";
        for (size_t i = 0; i < values.size(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << values[i];
        }
        out << "]";
    }

    static void append_ir_range(std::ostringstream& out, const RangeDescriptor& range) {
        out << "[";
        for (size_t i = 0; i < range.rank(); ++i) {
            if (i != 0) {
                out << ", ";
            }
            out << range.begin[i] << ".." << range.end[i];
        }
        out << "]";
    }
};

inline std::string trim(std::string value) {
    size_t first = 0;
    while (first < value.size() && std::isspace(static_cast<unsigned char>(value[first]))) {
        ++first;
    }
    size_t last = value.size();
    while (last > first && std::isspace(static_cast<unsigned char>(value[last - 1]))) {
        --last;
    }
    return value.substr(first, last - first);
}

inline bool starts_with(const std::string& value, const std::string& prefix) {
    return value.size() >= prefix.size() && value.compare(0, prefix.size(), prefix) == 0;
}

inline bool parse_size_value(const std::string& text, size_t& value) {
    if (text.empty()) {
        return false;
    }
    size_t parsed = 0;
    for (char ch : text) {
        if (!std::isdigit(static_cast<unsigned char>(ch))) {
            return false;
        }
        parsed = parsed * 10 + static_cast<size_t>(ch - '0');
    }
    value = parsed;
    return true;
}

inline bool is_supported_backend_name(const std::string& backend) {
    return backend.empty() ||
           backend == "DEFAULT" ||
           backend == "SERIAL" ||
           backend == "OPENMP" ||
           backend == "CUDA" ||
           backend == "HIP" ||
           backend == "HYGON_DCU" ||
           backend == "MUSA" ||
           backend == "SYCL" ||
           backend == "OPENCL" ||
           backend == "OPENGL" ||
           backend == "MPI";
}

inline std::vector<std::string> split_csv(const std::string& value) {
    std::vector<std::string> parts;
    std::stringstream in(value);
    std::string item;
    while (std::getline(in, item, ',')) {
        item = trim(item);
        if (!item.empty()) {
            parts.push_back(item);
        }
    }
    return parts;
}

inline bool parse_range_token(const std::string& token, size_t& begin, size_t& end) {
    if (!starts_with(token, "range=")) {
        return false;
    }
    const std::string range_text = token.substr(6);
    const size_t dots = range_text.find("..");
    if (dots == std::string::npos) {
        return false;
    }
    return parse_size_value(range_text.substr(0, dots), begin) &&
           parse_size_value(range_text.substr(dots + 2), end);
}

inline OperationKind parse_frontend_kind(const std::string& token) {
    if (token == "map") {
        return OperationKind::Transform;
    }
    if (token == "reduce") {
        return OperationKind::Reduce;
    }
    if (token == "stencil1d" || token == "stencil") {
        return OperationKind::Kernel;
    }
    if (token == "copy") {
        return OperationKind::Copy;
    }
    if (token == "fill") {
        return OperationKind::Fill;
    }
    if (token == "blas.copy") {
        return OperationKind::BlasCopy;
    }
    if (token == "blas.scal") {
        return OperationKind::BlasScal;
    }
    if (token == "blas.axpy") {
        return OperationKind::BlasAxpy;
    }
    if (token == "blas.dot") {
        return OperationKind::BlasDot;
    }
    if (token == "blas.nrm2") {
        return OperationKind::BlasNrm2;
    }
    return OperationKind::Custom;
}

inline void append_frontend_error(
    FrontendResult& result,
    size_t line,
    std::string message) {
    result.diagnostics.push_back(
        FrontendDiagnostic{DiagnosticSeverity::Error, line, std::move(message)});
}

inline void append_frontend_warning(
    FrontendResult& result,
    size_t line,
    std::string message) {
    result.diagnostics.push_back(
        FrontendDiagnostic{DiagnosticSeverity::Warning, line, std::move(message)});
}

inline size_t frontend_access_count(
    const OperationNode& node,
    AccessMode mode) {
    size_t count = 0;
    for (const auto& access : node.accesses) {
        if (access.mode == mode) {
            ++count;
        }
    }
    return count;
}

inline bool frontend_has_attribute(
    const OperationNode& node,
    const std::string& key) {
    for (const auto& attribute : node.attributes) {
        if (attribute.key == key) {
            return true;
        }
    }
    return false;
}

inline std::string frontend_attribute_value(
    const OperationNode& node,
    const std::string& key) {
    for (const auto& attribute : node.attributes) {
        if (attribute.key == key) {
            return attribute.value;
        }
    }
    return "";
}

inline void validate_frontend_node(
    FrontendResult& result,
    size_t line,
    const std::string& kind_token,
    const OperationNode& node) {
    for (size_t i = 0; i < node.accesses.size(); ++i) {
        for (size_t j = i + 1; j < node.accesses.size(); ++j) {
            if (node.accesses[i].view == node.accesses[j].view) {
                append_frontend_warning(result, line, "view appears in multiple access lists: " + node.accesses[i].view);
            }
        }
    }
    if (!is_supported_backend_name(node.kernel.backend_hint)) {
        append_frontend_warning(result, line, "unknown backend hint: " + node.kernel.backend_hint);
    }
    if (node.kernel.range.empty()) {
        append_frontend_warning(result, line, "range is empty");
    }
    if (node.kind == OperationKind::Fill && frontend_access_count(node, AccessMode::Write) == 0) {
        append_frontend_error(result, line, "fill requires write=<view>");
    } else if (node.kind == OperationKind::Copy &&
               (frontend_access_count(node, AccessMode::Read) == 0 ||
                frontend_access_count(node, AccessMode::Write) == 0)) {
        append_frontend_error(result, line, "copy requires read=<src> and write=<dst>");
    } else if (node.kind == OperationKind::Transform &&
               frontend_access_count(node, AccessMode::Write) == 0 &&
               frontend_access_count(node, AccessMode::ReadWrite) == 0) {
        append_frontend_warning(result, line, "map has no write or read_write access");
    } else if (node.kind == OperationKind::Reduce &&
               (frontend_access_count(node, AccessMode::Read) == 0 ||
                frontend_access_count(node, AccessMode::Write) == 0)) {
        append_frontend_error(result, line, "reduce requires read=<src> and write=<result>");
    } else if ((kind_token == "stencil" || kind_token == "stencil1d") &&
               !frontend_has_attribute(node, "radius")) {
        append_frontend_warning(result, line, "stencil1d has no radius=<n> attribute");
    } else if (node.kind == OperationKind::BlasScal &&
               (frontend_access_count(node, AccessMode::ReadWrite) == 0 ||
                !frontend_has_attribute(node, "alpha"))) {
        append_frontend_error(result, line, "blas.scal requires read_write=<x> and alpha=<value>");
    } else if (node.kind == OperationKind::BlasAxpy &&
               (frontend_access_count(node, AccessMode::Read) == 0 ||
                frontend_access_count(node, AccessMode::ReadWrite) == 0 ||
                !frontend_has_attribute(node, "alpha"))) {
        append_frontend_error(result, line, "blas.axpy requires read=<x>, read_write=<y>, and alpha=<value>");
    } else if (node.kind == OperationKind::BlasDot &&
               (frontend_access_count(node, AccessMode::Read) < 2 ||
                frontend_access_count(node, AccessMode::Write) == 0)) {
        append_frontend_error(result, line, "blas.dot requires read=<x,y> and write=<result>");
    } else if (node.kind == OperationKind::BlasNrm2 &&
               (frontend_access_count(node, AccessMode::Read) == 0 ||
                frontend_access_count(node, AccessMode::Write) == 0)) {
        append_frontend_error(result, line, "blas.nrm2 requires read=<x> and write=<result>");
    } else if (node.kind == OperationKind::BlasCopy &&
               (frontend_access_count(node, AccessMode::Read) == 0 ||
                frontend_access_count(node, AccessMode::Write) == 0)) {
        append_frontend_error(result, line, "blas.copy requires read=<src> and write=<dst>");
    }
}

inline FrontendResult parse_frontend(const std::string& source) {
    FrontendResult result;
    std::stringstream lines(source);
    std::string raw_line;
    size_t line_number = 0;
    std::map<std::string, size_t> name_to_id;

    while (std::getline(lines, raw_line)) {
        ++line_number;
        const size_t comment = raw_line.find('#');
        std::string line = trim(raw_line.substr(0, comment));
        if (line.empty()) {
            continue;
        }

        std::stringstream tokens(line);
        std::string kind_token;
        std::string name;
        tokens >> kind_token >> name;
        const OperationKind kind = parse_frontend_kind(kind_token);
        if (kind == OperationKind::Custom || name.empty()) {
            append_frontend_error(result, line_number, "expected '<map|reduce|stencil1d|stencil|copy|fill|blas.*> name ...'");
            continue;
        }

        size_t begin = 0;
        size_t end = 0;
        bool has_range = false;
        std::vector<std::string> explicit_dependencies;
        OperationBuilder builder = operation(name, kind).tag("frontend");
        if (kind_token == "stencil1d" || kind_token == "stencil") {
            builder.tag("stencil1d");
        }
        if (name_to_id.find(name) != name_to_id.end()) {
            append_frontend_error(result, line_number, "operation name is duplicated: " + name);
            continue;
        }

        std::string token;
        while (tokens >> token) {
            if (parse_range_token(token, begin, end)) {
                has_range = true;
            } else if (starts_with(token, "read=")) {
                for (const auto& view : split_csv(token.substr(5))) {
                    builder.read(view);
                }
            } else if (starts_with(token, "write=")) {
                for (const auto& view : split_csv(token.substr(6))) {
                    builder.write(view);
                }
            } else if (starts_with(token, "read_write=")) {
                for (const auto& view : split_csv(token.substr(11))) {
                    builder.read_write(view);
                }
            } else if (starts_with(token, "backend=")) {
                builder.backend_hint(token.substr(8));
            } else if (starts_with(token, "depends=")) {
                explicit_dependencies = split_csv(token.substr(8));
            } else if (starts_with(token, "expr=")) {
                std::string expression = token.substr(5);
                std::string rest;
                std::getline(tokens, rest);
                expression += rest;
                builder.attribute("expression", trim(expression));
                break;
            } else if (starts_with(token, "radius=")) {
                builder.attribute("radius", token.substr(7));
            } else if (starts_with(token, "tile=")) {
                size_t parsed_tile = 0;
                if (!parse_size_value(token.substr(5), parsed_tile)) {
                    append_frontend_error(result, line_number, "tile= expects a non-negative integer");
                }
                builder.attribute("tile", token.substr(5));
            } else if (starts_with(token, "value=")) {
                builder.attribute("value", token.substr(6));
            } else if (starts_with(token, "alpha=")) {
                builder.attribute("alpha", token.substr(6));
            } else {
                append_frontend_warning(result, line_number, "ignored token: " + token);
            }
        }

        if (!has_range) {
            append_frontend_error(result, line_number, "operation requires range=<begin>..<end>");
            continue;
        }
        builder.range(begin, end).source_location("dsl:" + std::to_string(line_number));
        const OperationNode parsed_node = builder.build();
        if ((kind_token == "stencil" || kind_token == "stencil1d") &&
            frontend_has_attribute(parsed_node, "radius")) {
            size_t parsed_radius = 0;
            const std::string radius_value = frontend_attribute_value(parsed_node, "radius");
            if (!parse_size_value(radius_value, parsed_radius)) {
                append_frontend_error(result, line_number, "radius= expects a non-negative integer");
            }
        }
        validate_frontend_node(result, line_number, kind_token, parsed_node);
        const size_t node_id = result.graph.add(parsed_node);
        name_to_id[name] = node_id;
        for (const auto& dependency_name : explicit_dependencies) {
            const auto dependency = name_to_id.find(dependency_name);
            if (dependency == name_to_id.end()) {
                append_frontend_error(
                    result,
                    line_number,
                    "depends= references an unknown previous operation: " + dependency_name);
                continue;
            }
            result.graph.add_dependency(dependency->second, node_id);
        }
    }

    if (result.ok()) {
        result.graph.infer_data_dependencies();
    }
    return result;
}

inline bool ir_has_string(const std::vector<std::string>& values, const std::string& value) {
    for (const auto& current : values) {
        if (current == value) {
            return true;
        }
    }
    return false;
}

inline void ir_add_unique(std::vector<std::string>& values, const std::string& value) {
    if (!value.empty() && !ir_has_string(values, value)) {
        values.push_back(value);
    }
}

inline bool ir_has_tag(const OperationNode& node, const std::string& tag) {
    return ir_has_string(node.kernel.tags, tag);
}

inline bool ir_same_range(const RangeDescriptor& lhs, const RangeDescriptor& rhs) {
    return lhs.begin == rhs.begin && lhs.end == rhs.end;
}

inline bool ir_attribute_equals(const OperationNode& node, const std::string& key, const std::string& value) {
    for (const auto& attribute : node.attributes) {
        if (attribute.key == key && attribute.value == value) {
            return true;
        }
    }
    return false;
}

inline std::string ir_attribute_value(const std::vector<Attribute>& attributes, const std::string& key) {
    for (const auto& attribute : attributes) {
        if (attribute.key == key) {
            return attribute.value;
        }
    }
    return "";
}

inline std::string ir_pattern_for(const OperationNode& node) {
    if (node.kind == OperationKind::Transform) {
        return "map";
    }
    if (node.kind == OperationKind::Reduce) {
        return "reduce";
    }
    if (node.kind == OperationKind::Copy) {
        return "copy";
    }
    if (node.kind == OperationKind::Fill) {
        return "fill";
    }
    if (ir_has_tag(node, "stencil1d")) {
        return "stencil1d";
    }
    return to_string(node.kind);
}

inline bool ir_is_dead_node(const OperationNode& node) {
    if (ir_attribute_equals(node, "dead", "true")) {
        return true;
    }
    return node.accesses.empty() && node.dependencies.empty() && !node.executable();
}

inline bool ir_can_fuse_adjacent_maps(const OperationNode& first, const OperationNode& second) {
    return first.kind == OperationKind::Transform &&
           second.kind == OperationKind::Transform &&
           ir_same_range(first.kernel.range, second.kernel.range) &&
           second.dependencies.size() == 1 &&
           second.dependencies[0] == first.id;
}

inline KernelIRNode ir_node_from_group(
    size_t id,
    const OperationGraph& graph,
    const std::vector<size_t>& source_node_ids,
    const std::map<size_t, size_t>& original_to_ir) {
    const OperationNode& first = graph.node(source_node_ids.front());
    KernelIRNode ir;
    ir.id = id;
    ir.source_node_ids = source_node_ids;
    ir.kind = first.kind;
    ir.name = first.kernel.name;
    ir.parallel_pattern = ir_pattern_for(first);
    ir.backend_hint = first.kernel.backend_hint;
    ir.source_location = first.kernel.source_location;
    ir.range = first.kernel.range;
    ir.tags = first.kernel.tags;
    ir.attributes = first.attributes;

    for (size_t group_index = 0; group_index < source_node_ids.size(); ++group_index) {
        const OperationNode& node = graph.node(source_node_ids[group_index]);
        if (group_index != 0) {
            ir.name += "_fused_" + node.kernel.name;
            ir.attributes.push_back(Attribute{"fused_expression", ir_attribute_value(node.attributes, "expression")});
            for (const auto& tag : node.kernel.tags) {
                ir_add_unique(ir.tags, tag);
            }
        }
        for (const auto& access : node.accesses) {
            if (access.mode == AccessMode::Read) {
                ir_add_unique(ir.reads, access.view);
            } else if (access.mode == AccessMode::Write) {
                ir_add_unique(ir.writes, access.view);
            } else {
                ir_add_unique(ir.read_writes, access.view);
            }
        }
        for (const auto& dependency : node.dependencies) {
            bool internal_dependency = false;
            for (const auto& source_id : source_node_ids) {
                if (dependency == source_id) {
                    internal_dependency = true;
                    break;
                }
            }
            if (!internal_dependency) {
                const auto mapped = original_to_ir.find(dependency);
                if (mapped != original_to_ir.end()) {
                    bool exists = false;
                    for (size_t current : ir.dependencies) {
                        if (current == mapped->second) {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        ir.dependencies.push_back(mapped->second);
                    }
                }
            }
        }
    }
    if (source_node_ids.size() > 1) {
        ir.parallel_pattern = "fused_map";
        ir.attributes.push_back(Attribute{"fusion", "adjacent_map"});
    }
    return ir;
}

inline KernelIRModule build_kernel_ir(
    const OperationGraph& graph,
    KernelIROptions options = KernelIROptions{}) {
    KernelIRModule module;
    const GraphAnalysis analysis = graph.analyze();
    module.diagnostics = analysis.diagnostics;
    if (analysis.has_errors()) {
        return module;
    }

    std::vector<std::vector<size_t>> groups;
    for (size_t order_index = 0; order_index < analysis.topological_order.size(); ++order_index) {
        const size_t node_id = analysis.topological_order[order_index];
        const OperationNode& node = graph.node(node_id);
        if (options.drop_dead_nodes && ir_is_dead_node(node)) {
            module.diagnostics.push_back(
                GraphDiagnostic{DiagnosticSeverity::Warning, node_id, "dropped dead IR node"});
            continue;
        }
        if (options.fuse_adjacent_maps && order_index + 1 < analysis.topological_order.size()) {
            const size_t next_id = analysis.topological_order[order_index + 1];
            const OperationNode& next = graph.node(next_id);
            if (!(options.drop_dead_nodes && ir_is_dead_node(next)) &&
                ir_can_fuse_adjacent_maps(node, next)) {
                groups.push_back(std::vector<size_t>{node_id, next_id});
                ++order_index;
                module.diagnostics.push_back(
                    GraphDiagnostic{DiagnosticSeverity::Warning, node_id, "fused adjacent map nodes"});
                continue;
            }
        }
        groups.push_back(std::vector<size_t>{node_id});
    }

    std::map<size_t, size_t> original_to_ir;
    for (size_t group_id = 0; group_id < groups.size(); ++group_id) {
        for (size_t source_id : groups[group_id]) {
            original_to_ir[source_id] = group_id;
        }
    }
    for (size_t group_id = 0; group_id < groups.size(); ++group_id) {
        module.nodes.push_back(ir_node_from_group(group_id, graph, groups[group_id], original_to_ir));
    }
    return module;
}

inline bool kernel_ir_has_lowering_error(const std::vector<GraphDiagnostic>& diagnostics) {
    for (const auto& diagnostic : diagnostics) {
        if (diagnostic.severity == DiagnosticSeverity::Error) {
            return true;
        }
    }
    return false;
}

inline bool kernel_ir_pattern_is_supported(const std::string& pattern) {
    return pattern == "fill" ||
           pattern == "copy" ||
           pattern == "map" ||
           pattern == "fused_map" ||
           pattern == "reduce" ||
           pattern == "stencil1d" ||
           pattern == "blas.copy" ||
           pattern == "blas.scal" ||
           pattern == "blas.axpy" ||
           pattern == "blas.dot" ||
           pattern == "blas.nrm2";
}

inline void append_kernel_ir_lowering_diagnostic(
    std::vector<GraphDiagnostic>& diagnostics,
    DiagnosticSeverity severity,
    size_t node_id,
    std::string message) {
    diagnostics.push_back(GraphDiagnostic{severity, node_id, std::move(message)});
}

inline std::vector<GraphDiagnostic> diagnose_kernel_ir_lowering(const KernelIRModule& module) {
    std::vector<GraphDiagnostic> diagnostics = module.diagnostics;
    for (const auto& node : module.nodes) {
        if (!kernel_ir_pattern_is_supported(node.parallel_pattern)) {
            append_kernel_ir_lowering_diagnostic(
                diagnostics,
                DiagnosticSeverity::Error,
                node.id,
                "cannot lower unsupported parallel pattern: " + node.parallel_pattern);
            continue;
        }
        if ((node.parallel_pattern == "map" ||
             node.parallel_pattern == "fused_map" ||
             node.parallel_pattern == "reduce" ||
             node.parallel_pattern == "stencil1d") &&
            node.range.rank() != 1) {
            append_kernel_ir_lowering_diagnostic(
                diagnostics,
                DiagnosticSeverity::Error,
                node.id,
                "LongX source lowering currently requires a rank-1 range");
        }
        if (node.parallel_pattern == "fill") {
            if (node.writes.empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "fill lowering requires write=<view>");
            }
            if (ir_attribute_value(node.attributes, "value").empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Warning,
                    node.id,
                    "fill lowering has no value= attribute and will emit a placeholder");
            }
        } else if (node.parallel_pattern == "copy") {
            if (node.reads.empty() || node.writes.empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "copy lowering requires read=<src> and write=<dst>");
            }
        } else if (node.parallel_pattern == "reduce") {
            if (node.writes.empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "reduce lowering requires write=<result>");
            }
            if (ir_attribute_value(node.attributes, "expression").empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Warning,
                    node.id,
                    "reduce lowering has no expr= attribute and will emit a placeholder");
            }
        } else if (node.parallel_pattern == "map" ||
                   node.parallel_pattern == "fused_map" ||
                   node.parallel_pattern == "stencil1d") {
            if (node.writes.empty() && node.read_writes.empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Warning,
                    node.id,
                    "kernel lowering has no write or read_write access");
            }
            if (ir_attribute_value(node.attributes, "expression").empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Warning,
                    node.id,
                    "kernel lowering has no expr= attribute and will emit a placeholder");
            }
        } else if (node.parallel_pattern == "blas.copy") {
            if (node.reads.empty() || node.writes.empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "blas.copy lowering requires read=<src> and write=<dst>");
            }
        } else if (node.parallel_pattern == "blas.scal") {
            if (node.read_writes.empty() || ir_attribute_value(node.attributes, "alpha").empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "blas.scal lowering requires read_write=<x> and alpha=<value>");
            }
        } else if (node.parallel_pattern == "blas.axpy") {
            if (node.reads.empty() || node.read_writes.empty() ||
                ir_attribute_value(node.attributes, "alpha").empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "blas.axpy lowering requires read=<x>, read_write=<y>, and alpha=<value>");
            }
        } else if (node.parallel_pattern == "blas.dot") {
            if (node.reads.size() < 2 || node.writes.empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "blas.dot lowering requires read=<x,y> and write=<result>");
            }
        } else if (node.parallel_pattern == "blas.nrm2") {
            if (node.reads.empty() || node.writes.empty()) {
                append_kernel_ir_lowering_diagnostic(
                    diagnostics,
                    DiagnosticSeverity::Error,
                    node.id,
                    "blas.nrm2 lowering requires read=<x> and write=<result>");
            }
        }
    }
    return diagnostics;
}

inline std::string kernel_ir_lowering_report(const KernelIRModule& module) {
    std::ostringstream out;
    const auto diagnostics = diagnose_kernel_ir_lowering(module);
    out << "LongX DSL kernel IR lowering report\n";
    out << "ok=" << (kernel_ir_has_lowering_error(diagnostics) ? "false" : "true") << "\n";
    out << "nodes=" << module.nodes.size() << "\n";
    if (diagnostics.empty()) {
        out << "diagnostics=0\n";
        return out.str();
    }
    out << "diagnostics:\n";
    for (const auto& diagnostic : diagnostics) {
        out << "- " << to_string(diagnostic.severity)
            << " node=" << diagnostic.node_id
            << " " << diagnostic.message << "\n";
    }
    return out.str();
}

inline CodegenTarget parse_codegen_target(const std::string& target) {
    if (target.empty() || target == "default") {
        return CodegenTarget::Default;
    }
    if (target == "serial") {
        return CodegenTarget::Serial;
    }
    if (target == "openmp") {
        return CodegenTarget::OpenMP;
    }
    if (target == "cuda") {
        return CodegenTarget::Cuda;
    }
    if (target == "hip" || target == "hygon_dcu") {
        return CodegenTarget::Hip;
    }
    if (target == "musa") {
        return CodegenTarget::Musa;
    }
    if (target == "sycl") {
        return CodegenTarget::Sycl;
    }
    if (target == "mpi") {
        return CodegenTarget::MPI;
    }
    throw std::invalid_argument("unknown LongX DSL codegen target: " + target);
}

inline const char* codegen_execution_space(CodegenTarget target) {
    switch (target) {
    case CodegenTarget::Default: return "LongX::DefaultExecutionSpace";
    case CodegenTarget::Serial: return "LongX::Serial";
    case CodegenTarget::OpenMP: return "LongX::OpenMP";
    case CodegenTarget::Cuda: return "LongX::Cuda";
    case CodegenTarget::Hip: return "LongX::Hip";
    case CodegenTarget::Musa: return "LongX::Musa";
    case CodegenTarget::Sycl: return "LongX::Sycl";
    case CodegenTarget::MPI: return "LongX::MPI";
    }
    return "LongX::DefaultExecutionSpace";
}

inline std::string lower_kernel_ir_to_longx(
    const KernelIRModule& module,
    CodegenTarget target = CodegenTarget::Default) {
    if (!module.ok()) {
        throw std::runtime_error("LongX::dsl::lower_kernel_ir_to_longx requires a valid KernelIRModule");
    }
    const auto lowering_diagnostics = diagnose_kernel_ir_lowering(module);
    if (kernel_ir_has_lowering_error(lowering_diagnostics)) {
        throw std::runtime_error("LongX::dsl::lower_kernel_ir_to_longx rejected IR; inspect kernel_ir_lowering_report()");
    }
    std::ostringstream out;
    const char* exec_space = codegen_execution_space(target);
    out << "// Generated from LongX DSL kernel IR v" << module.version
        << " for target=" << to_string(target) << "\n";
    for (const auto& node : module.nodes) {
        const std::string begin = node.range.rank() == 0 ? "0" : std::to_string(node.range.begin[0]);
        const std::string end = node.range.rank() == 0 ? "0" : std::to_string(node.range.end[0]);
        const std::string expression = ir_attribute_value(node.attributes, "expression");
        const std::string value = ir_attribute_value(node.attributes, "value").empty()
            ? "/* value */"
            : ir_attribute_value(node.attributes, "value");
        const std::string alpha = ir_attribute_value(node.attributes, "alpha").empty()
            ? "/* alpha */"
            : ir_attribute_value(node.attributes, "alpha");
        out << "// ir[" << node.id << "] " << node.name
            << " pattern=" << node.parallel_pattern << "\n";
        if (node.parallel_pattern == "fill") {
            const std::string dst = node.writes.empty() ? "/* dst */" : node.writes.front();
            out << "LongX::parallel_fill<" << exec_space << ">(" << dst << ", " << value << ");\n";
        } else if (node.parallel_pattern == "copy") {
            const std::string src = node.reads.empty() ? "/* src */" : node.reads.front();
            const std::string dst = node.writes.empty() ? "/* dst */" : node.writes.front();
            out << "LongX::parallel_copy<" << exec_space << ">(" << src << ", " << dst << ");\n";
        } else if (node.parallel_pattern == "blas.copy") {
            const std::string src = node.reads.empty() ? "/* src */" : node.reads.front();
            const std::string dst = node.writes.empty() ? "/* dst */" : node.writes.front();
            out << "LongX::blas::copy<" << exec_space << ">(" << src << ", " << dst << ");\n";
        } else if (node.parallel_pattern == "blas.scal") {
            const std::string x = node.read_writes.empty() ? "/* x */" : node.read_writes.front();
            out << "LongX::blas::scal<" << exec_space << ">(" << alpha << ", " << x << ");\n";
        } else if (node.parallel_pattern == "blas.axpy") {
            const std::string x = node.reads.empty() ? "/* x */" : node.reads.front();
            const std::string y = node.read_writes.empty() ? "/* y */" : node.read_writes.front();
            out << "LongX::blas::axpy<" << exec_space << ">(" << alpha << ", " << x << ", " << y << ");\n";
        } else if (node.parallel_pattern == "blas.dot") {
            const std::string x = node.reads.empty() ? "/* x */" : node.reads.front();
            const std::string y = node.reads.size() < 2 ? "/* y */" : node.reads[1];
            const std::string result = node.writes.empty() ? "/* result */" : node.writes.front();
            out << result << " = LongX::blas::dot<" << exec_space << ">(" << x << ", " << y << ");\n";
        } else if (node.parallel_pattern == "blas.nrm2") {
            const std::string x = node.reads.empty() ? "/* x */" : node.reads.front();
            const std::string result = node.writes.empty() ? "/* result */" : node.writes.front();
            out << result << " = LongX::blas::nrm2<" << exec_space << ">(" << x << ");\n";
        } else if (node.parallel_pattern == "reduce") {
            const std::string dst = node.writes.empty() ? "/* result */" : node.writes.front();
            out << "LongX::parallel_reduce(\n";
            out << "    LongX::RangePolicy<" << exec_space << ">(" << begin << ", " << end << "),\n";
            out << "    [=] LONGX_DEVICE (size_t i, auto& local) {\n";
            out << "        " << (expression.empty() ? "/* reduce expression */" : expression) << "\n";
            out << "    },\n";
            out << "    " << dst << "\n";
            out << ");\n";
        } else {
            out << "LongX::parallel_for(\n";
            out << "    LongX::RangePolicy<" << exec_space << ">(" << begin << ", " << end << "),\n";
            out << "    [=] LONGX_DEVICE (size_t i) {\n";
            out << "        " << (expression.empty() ? "/* kernel expression */" : expression) << "\n";
            const std::string fused_expression = ir_attribute_value(node.attributes, "fused_expression");
            if (!fused_expression.empty()) {
                out << "        " << fused_expression << "\n";
            }
            out << "    }\n";
            out << ");\n";
        }
    }
    return out.str();
}

inline std::string lower_frontend_to_longx(
    const std::string& source,
    KernelIROptions options = KernelIROptions{},
    CodegenTarget target = CodegenTarget::Default) {
    const FrontendResult frontend = parse_frontend(source);
    if (!frontend.ok()) {
        throw std::runtime_error("LongX::dsl::lower_frontend_to_longx frontend parse failed");
    }
    return lower_kernel_ir_to_longx(build_kernel_ir(frontend.graph, options), target);
}

struct RestrictedLoopAccess {
    std::string view;
    AccessMode mode = AccessMode::Read;
    std::string subscript;
};

struct RestrictedLoopAnalysis {
    bool valid = false;
    bool parallelizable = false;
    bool is_reduction = false;
    bool is_stencil = false;
    std::string index;
    std::string begin;
    std::string end;
    std::string body;
    std::string reduction_variable;
    std::string reduction_operator;
    std::string reduction_expression;
    std::vector<RestrictedLoopAccess> accesses;
    std::vector<std::string> diagnostics;

    bool ok() const {
        return valid && parallelizable && diagnostics.empty();
    }

    std::string to_text() const {
        std::ostringstream out;
        out << "LongX restricted loop analysis\n";
        out << "valid=" << (valid ? "true" : "false") << "\n";
        out << "parallelizable=" << (parallelizable ? "true" : "false") << "\n";
        out << "pattern=" << (is_reduction ? "reduction" : (is_stencil ? "stencil1d" : "map")) << "\n";
        if (!index.empty()) {
            out << "range=" << begin << ".." << end << " index=" << index << "\n";
        }
        if (is_reduction) {
            out << "reduction=" << reduction_variable << " op=" << reduction_operator
                << " expr=" << reduction_expression << "\n";
        }
        if (!accesses.empty()) {
            out << "accesses:";
            for (const auto& access : accesses) {
                out << " " << to_string(access.mode) << "(" << access.view
                    << "[" << access.subscript << "])";
            }
            out << "\n";
        }
        if (!diagnostics.empty()) {
            out << "diagnostics:";
            for (const auto& diagnostic : diagnostics) {
                out << " " << diagnostic << ";";
            }
            out << "\n";
        }
        return out.str();
    }
};

inline bool loop_is_identifier_char(char ch) {
    return std::isalnum(static_cast<unsigned char>(ch)) || ch == '_';
}

inline std::string loop_strip_trailing_semicolon(std::string value) {
    value = trim(std::move(value));
    if (!value.empty() && value.back() == ';') {
        value.pop_back();
    }
    return trim(std::move(value));
}

inline void loop_add_access(
    std::vector<RestrictedLoopAccess>& accesses,
    std::string view,
    AccessMode mode,
    std::string subscript) {
    view = trim(std::move(view));
    subscript = trim(std::move(subscript));
    if (view.empty() || subscript.empty()) {
        return;
    }
    for (auto& access : accesses) {
        if (access.view == view && access.subscript == subscript) {
            if (access.mode != mode) {
                access.mode = AccessMode::ReadWrite;
            }
            return;
        }
    }
    accesses.push_back(RestrictedLoopAccess{std::move(view), mode, std::move(subscript)});
}

inline void loop_collect_indexed_accesses(
    const std::string& expression,
    const std::string& index,
    AccessMode mode,
    std::vector<RestrictedLoopAccess>& accesses,
    std::vector<std::string>& diagnostics) {
    for (size_t pos = 0; pos < expression.size(); ++pos) {
        if (!std::isalpha(static_cast<unsigned char>(expression[pos])) && expression[pos] != '_') {
            continue;
        }
        const size_t name_begin = pos;
        while (pos < expression.size() && loop_is_identifier_char(expression[pos])) {
            ++pos;
        }
        const std::string name = expression.substr(name_begin, pos - name_begin);
        size_t next = pos;
        while (next < expression.size() && std::isspace(static_cast<unsigned char>(expression[next]))) {
            ++next;
        }
        if (next >= expression.size() || (expression[next] != '[' && expression[next] != '(')) {
            continue;
        }
        const char open = expression[next];
        const char close = open == '[' ? ']' : ')';
        const size_t close_pos = expression.find(close, next + 1);
        if (close_pos == std::string::npos) {
            diagnostics.push_back("could not parse indexed access for " + name);
            continue;
        }
        const std::string subscript = trim(expression.substr(next + 1, close_pos - next - 1));
        loop_add_access(accesses, name, mode, subscript);
        if (subscript != index) {
            diagnostics.push_back(
                "loop-carried or indirect dependency candidate: " + name + "[" + subscript + "]");
        }
        pos = close_pos;
    }
}

inline bool loop_lhs_is_indexed_write(
    const std::string& lhs,
    const std::string& index,
    std::string& view) {
    const size_t bracket = lhs.find('[');
    const size_t paren = lhs.find('(');
    const size_t open = bracket == std::string::npos ? paren :
        (paren == std::string::npos ? bracket : std::min(bracket, paren));
    if (open == std::string::npos) {
        return false;
    }
    const char close_char = lhs[open] == '[' ? ']' : ')';
    const size_t close = lhs.find(close_char, open + 1);
    if (close == std::string::npos) {
        return false;
    }
    view = trim(lhs.substr(0, open));
    return trim(lhs.substr(open + 1, close - open - 1)) == index;
}

inline std::string loop_without_spaces(const std::string& value) {
    std::string compact;
    compact.reserve(value.size());
    for (char ch : value) {
        if (!std::isspace(static_cast<unsigned char>(ch))) {
            compact.push_back(ch);
        }
    }
    return compact;
}

inline bool loop_is_decimal_suffix(const std::string& value, size_t pos) {
    if (pos >= value.size()) {
        return false;
    }
    for (size_t i = pos; i < value.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(value[i]))) {
            return false;
        }
    }
    return true;
}

inline bool loop_is_index_or_neighbor(const std::string& subscript, const std::string& index) {
    const std::string compact = loop_without_spaces(subscript);
    if (compact == index) {
        return true;
    }
    if (!starts_with(compact, index) || compact.size() <= index.size() + 1) {
        return false;
    }
    const char op = compact[index.size()];
    return (op == '+' || op == '-') && loop_is_decimal_suffix(compact, index.size() + 1);
}

inline bool loop_promote_stencil_if_safe(RestrictedLoopAnalysis& analysis) {
    std::string written_view;
    size_t writes = 0;
    bool has_neighbor_read = false;
    for (const auto& access : analysis.accesses) {
        if (access.mode == AccessMode::Write || access.mode == AccessMode::ReadWrite) {
            ++writes;
            written_view = access.view;
        }
    }
    if (writes != 1) {
        return false;
    }
    for (const auto& access : analysis.accesses) {
        if (access.mode != AccessMode::Read) {
            continue;
        }
        if (!loop_is_index_or_neighbor(access.subscript, analysis.index)) {
            return false;
        }
        if (access.subscript != analysis.index) {
            has_neighbor_read = true;
        }
        if (access.view == written_view && access.subscript != analysis.index) {
            return false;
        }
    }
    if (!has_neighbor_read) {
        return false;
    }
    analysis.is_stencil = true;
    analysis.diagnostics.clear();
    return true;
}

inline bool loop_parse_reduction_compound(
    const std::string& body,
    RestrictedLoopAnalysis& analysis) {
    const char* ops[] = {"+=", "*=", "-=", "&=", "|="};
    for (const char* op : ops) {
        const size_t pos = body.find(op);
        if (pos == std::string::npos) {
            continue;
        }
        const std::string lhs = trim(body.substr(0, pos));
        if (lhs.empty() || lhs.find('[') != std::string::npos || lhs.find('(') != std::string::npos) {
            return false;
        }
        analysis.is_reduction = true;
        analysis.reduction_variable = lhs;
        analysis.reduction_operator = std::string(1, op[0]);
        analysis.reduction_expression = loop_strip_trailing_semicolon(body.substr(pos + 2));
        loop_collect_indexed_accesses(
            analysis.reduction_expression,
            analysis.index,
            AccessMode::Read,
            analysis.accesses,
            analysis.diagnostics);
        return true;
    }
    return false;
}

inline bool loop_parse_reduction_assignment(
    const std::string& body,
    RestrictedLoopAnalysis& analysis) {
    const size_t equal = body.find('=');
    if (equal == std::string::npos || (equal > 0 && body[equal - 1] == '=') ||
        (equal + 1 < body.size() && body[equal + 1] == '=')) {
        return false;
    }
    const std::string lhs = trim(body.substr(0, equal));
    std::string rhs = loop_strip_trailing_semicolon(body.substr(equal + 1));
    if (lhs.empty() || rhs.empty() || lhs.find('[') != std::string::npos || lhs.find('(') != std::string::npos) {
        return false;
    }
    const std::string prefix_add = lhs + " +";
    const std::string prefix_mul = lhs + " *";
    const std::string suffix_add = "+ " + lhs;
    const std::string suffix_mul = "* " + lhs;
    if (starts_with(rhs, prefix_add)) {
        analysis.reduction_operator = "+";
        rhs = trim(rhs.substr(prefix_add.size()));
    } else if (starts_with(rhs, prefix_mul)) {
        analysis.reduction_operator = "*";
        rhs = trim(rhs.substr(prefix_mul.size()));
    } else if (rhs.size() >= suffix_add.size() &&
               rhs.compare(rhs.size() - suffix_add.size(), suffix_add.size(), suffix_add) == 0) {
        analysis.reduction_operator = "+";
        rhs = trim(rhs.substr(0, rhs.size() - suffix_add.size()));
    } else if (rhs.size() >= suffix_mul.size() &&
               rhs.compare(rhs.size() - suffix_mul.size(), suffix_mul.size(), suffix_mul) == 0) {
        analysis.reduction_operator = "*";
        rhs = trim(rhs.substr(0, rhs.size() - suffix_mul.size()));
    } else {
        return false;
    }
    analysis.is_reduction = true;
    analysis.reduction_variable = lhs;
    analysis.reduction_expression = rhs;
    loop_collect_indexed_accesses(
        analysis.reduction_expression,
        analysis.index,
        AccessMode::Read,
        analysis.accesses,
        analysis.diagnostics);
    return true;
}

inline RestrictedLoopAnalysis analyze_restricted_loop(const std::string& source) {
    RestrictedLoopAnalysis analysis;
    const std::string text = trim(source);
    const size_t for_pos = text.find("for");
    const size_t open_paren = text.find('(', for_pos);
    const size_t close_paren = text.find(')', open_paren);
    const size_t open_brace = text.find('{', close_paren);
    const size_t close_brace = text.rfind('}');
    if (for_pos != 0 || open_paren == std::string::npos || close_paren == std::string::npos ||
        open_brace == std::string::npos || close_brace == std::string::npos ||
        close_brace <= open_brace) {
        analysis.diagnostics.push_back("expected a single counted for loop");
        return analysis;
    }

    const std::string header = text.substr(open_paren + 1, close_paren - open_paren - 1);
    const std::string body = trim(text.substr(open_brace + 1, close_brace - open_brace - 1));
    analysis.body = body;
    const size_t first_semicolon = header.find(';');
    const size_t second_semicolon = header.find(';', first_semicolon + 1);
    if (first_semicolon == std::string::npos || second_semicolon == std::string::npos) {
        analysis.diagnostics.push_back("only supports 'i = begin; i < end; ++i'");
        return analysis;
    }
    const std::string init = trim(header.substr(0, first_semicolon));
    const std::string condition = trim(header.substr(first_semicolon + 1, second_semicolon - first_semicolon - 1));
    const std::string step = trim(header.substr(second_semicolon + 1));
    const size_t equal = init.find('=');
    const size_t less = condition.find('<');
    if (equal == std::string::npos || less == std::string::npos || step.find("++") == std::string::npos) {
        analysis.diagnostics.push_back("only supports 'i = begin; i < end; ++i'");
        return analysis;
    }

    std::string before_equal = trim(init.substr(0, equal));
    const size_t last_space = before_equal.find_last_of(" \t");
    const std::string index = last_space == std::string::npos ? before_equal : trim(before_equal.substr(last_space + 1));
    const std::string condition_index = trim(condition.substr(0, less));
    const std::string begin = trim(init.substr(equal + 1));
    const std::string end = trim(condition.substr(less + 1));
    if (condition_index != index || step.find(index) == std::string::npos) {
        analysis.diagnostics.push_back("requires one loop index variable");
        return analysis;
    }
    if (index.empty() || begin.empty() || end.empty()) {
        analysis.diagnostics.push_back("could not parse loop bounds");
        return analysis;
    }
    analysis.valid = true;
    analysis.index = index;
    analysis.begin = begin;
    analysis.end = end;

    if (body.find(';') != body.rfind(';')) {
        analysis.diagnostics.push_back("only one loop-body statement is supported");
        return analysis;
    }
    if (body.find("break") != std::string::npos || body.find("return") != std::string::npos ||
        body.find("continue") != std::string::npos) {
        analysis.diagnostics.push_back("control-flow exits are not supported");
        return analysis;
    }

    if (loop_parse_reduction_compound(body, analysis) ||
        loop_parse_reduction_assignment(body, analysis)) {
        analysis.parallelizable = analysis.diagnostics.empty();
        return analysis;
    }

    const size_t assign = body.find('=');
    if (assign == std::string::npos || (assign > 0 && body[assign - 1] == '=') ||
        (assign + 1 < body.size() && body[assign + 1] == '=')) {
        analysis.diagnostics.push_back("expected one assignment or recognized reduction");
        return analysis;
    }
    const std::string lhs = trim(body.substr(0, assign));
    const std::string rhs = loop_strip_trailing_semicolon(body.substr(assign + 1));
    std::string written_view;
    if (!loop_lhs_is_indexed_write(lhs, index, written_view)) {
        analysis.diagnostics.push_back("assignment write must target an element indexed by the loop variable");
        return analysis;
    }
    loop_add_access(analysis.accesses, written_view, AccessMode::Write, index);
    loop_collect_indexed_accesses(rhs, index, AccessMode::Read, analysis.accesses, analysis.diagnostics);
    if (!analysis.diagnostics.empty()) {
        loop_promote_stencil_if_safe(analysis);
    }
    analysis.parallelizable = analysis.diagnostics.empty();
    return analysis;
}

inline std::string lower_restricted_loop_to_longx(
    const std::string& source,
    CodegenTarget target = CodegenTarget::Default) {
    const RestrictedLoopAnalysis analysis = analyze_restricted_loop(source);
    if (!analysis.valid) {
        throw std::invalid_argument("LongX::dsl::lower_restricted_loop_to_longx expects a single counted for loop");
    }
    if (!analysis.parallelizable) {
        throw std::invalid_argument(
            "LongX::dsl::lower_restricted_loop_to_longx rejected loop: " +
            (analysis.diagnostics.empty() ? std::string("unknown reason") : analysis.diagnostics.front()));
    }

    std::ostringstream out;
    const char* exec_space = codegen_execution_space(target);
    out << "// Generated from LongX restricted loop analysis for target="
        << to_string(target) << "\n";
    out << "// pattern=" << (analysis.is_reduction ? "reduction" : (analysis.is_stencil ? "stencil1d" : "map")) << "\n";
    if (analysis.is_reduction) {
        out << "LongX::parallel_reduce(\n";
        out << "    LongX::RangePolicy<" << exec_space << ">(" << analysis.begin << ", " << analysis.end << "),\n";
        out << "    [=] LONGX_DEVICE (size_t " << analysis.index << ", auto& local) {\n";
        out << "        local " << analysis.reduction_operator << "= " << analysis.reduction_expression << ";\n";
        out << "    },\n";
        out << "    " << analysis.reduction_variable << "\n";
        out << ");";
    } else {
        out << "LongX::parallel_for(\n";
        out << "    LongX::RangePolicy<" << exec_space << ">(" << analysis.begin << ", " << analysis.end << "),\n";
        out << "    [=] LONGX_DEVICE (size_t " << analysis.index << ") {\n";
        out << "        " << analysis.body << "\n";
        out << "    }\n";
        out << ");";
    }
    return out.str();
}

inline std::string restricted_loop_diagnostic_report(const std::string& source) {
    const RestrictedLoopAnalysis analysis = analyze_restricted_loop(source);
    std::ostringstream out;
    out << analysis.to_text();
    out << "decision=" << (analysis.ok() ? "parallelize" : "reject") << "\n";
    if (analysis.ok()) {
        out << "explanation=loop matches the restricted "
            << (analysis.is_reduction ? "reduction" : (analysis.is_stencil ? "stencil1d" : "map"))
            << " pattern and no unsupported loop-carried dependency was found\n";
        out << "lowering_preview:\n" << lower_restricted_loop_to_longx(source) << "\n";
    } else {
        out << "explanation=loop is outside the accepted LongX restricted auto-parallel subset\n";
        if (analysis.diagnostics.empty()) {
            out << "- error unknown rejection reason\n";
        } else {
            for (const auto& diagnostic : analysis.diagnostics) {
                out << "- error " << diagnostic << "\n";
            }
        }
    }
    return out.str();
}

} // namespace dsl
} // namespace LongX
