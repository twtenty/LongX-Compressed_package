#pragma once

#include <cstddef>
#include <omp.h>

#include "longx_exec_space.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"

namespace LongX {

template<typename Functor>
void parallel_for(const RangePolicy<OpenMP>& policy, Functor f) {
    long long begin = static_cast<long long>(policy.begin());
    long long end = static_cast<long long>(policy.end());

    if (policy.schedule() == Schedule::Dynamic) {
#pragma omp parallel for schedule(dynamic)
        for (long long i = begin; i < end; ++i) {
            f(static_cast<size_t>(i));
        }
        return;
    }

    if (policy.schedule() == Schedule::Guided) {
#pragma omp parallel for schedule(guided)
        for (long long i = begin; i < end; ++i) {
            f(static_cast<size_t>(i));
        }
        return;
    }

#pragma omp parallel for schedule(static)
    for (long long i = begin; i < end; ++i) {
        f(static_cast<size_t>(i));
    }
}

template<typename Functor>
void parallel_for(const MDRangePolicy<OpenMP, 2>& policy, Functor f) {
    long long begin0 = static_cast<long long>(policy.begin0());
    long long begin1 = static_cast<long long>(policy.begin1());
    long long end0 = static_cast<long long>(policy.end0());
    long long end1 = static_cast<long long>(policy.end1());

    if (policy.collapse()) {
        long long total = (end0 - begin0) * (end1 - begin1);
        long long width = end1 - begin1;
        if (policy.schedule() == Schedule::Dynamic) {
#pragma omp parallel for schedule(dynamic)
            for (long long linear = 0; linear < total; ++linear) {
                long long i = begin0 + linear / width;
                long long j = begin1 + linear % width;
                f(static_cast<size_t>(i), static_cast<size_t>(j));
            }
            return;
        }

        if (policy.schedule() == Schedule::Guided) {
#pragma omp parallel for schedule(guided)
            for (long long linear = 0; linear < total; ++linear) {
                long long i = begin0 + linear / width;
                long long j = begin1 + linear % width;
                f(static_cast<size_t>(i), static_cast<size_t>(j));
            }
            return;
        }

#pragma omp parallel for schedule(static)
        for (long long linear = 0; linear < total; ++linear) {
            long long i = begin0 + linear / width;
            long long j = begin1 + linear % width;
            f(static_cast<size_t>(i), static_cast<size_t>(j));
        }
        return;
    }

    if (policy.schedule() == Schedule::Dynamic) {
#pragma omp parallel for schedule(dynamic)
        for (long long i = begin0; i < end0; ++i) {
            for (long long j = begin1; j < end1; ++j) {
                f(static_cast<size_t>(i), static_cast<size_t>(j));
            }
        }
        return;
    }

    if (policy.schedule() == Schedule::Guided) {
#pragma omp parallel for schedule(guided)
        for (long long i = begin0; i < end0; ++i) {
            for (long long j = begin1; j < end1; ++j) {
                f(static_cast<size_t>(i), static_cast<size_t>(j));
            }
        }
        return;
    }

#pragma omp parallel for schedule(static)
    for (long long i = begin0; i < end0; ++i) {
        for (long long j = begin1; j < end1; ++j) {
            f(static_cast<size_t>(i), static_cast<size_t>(j));
        }
    }
}

template<typename Functor, typename ValueType>
void parallel_reduce(const RangePolicy<OpenMP>& policy, Functor f, ValueType& result) {
    ValueType total{};

#pragma omp parallel
    {
        ValueType local{};

        if (policy.schedule() == Schedule::Dynamic) {
#pragma omp for schedule(dynamic)
            for (long long i = static_cast<long long>(policy.begin());
                 i < static_cast<long long>(policy.end());
                 ++i) {
                f(static_cast<size_t>(i), local);
            }
        } else if (policy.schedule() == Schedule::Guided) {
#pragma omp for schedule(guided)
            for (long long i = static_cast<long long>(policy.begin());
                 i < static_cast<long long>(policy.end());
                 ++i) {
                f(static_cast<size_t>(i), local);
            }
        } else {
#pragma omp for schedule(static)
            for (long long i = static_cast<long long>(policy.begin());
                 i < static_cast<long long>(policy.end());
                 ++i) {
                f(static_cast<size_t>(i), local);
            }
        }

#pragma omp critical
        {
            total += local;
        }
    }

    result = total;
}

template<typename Functor, typename ValueType, typename Reducer>
void parallel_reduce(const RangePolicy<OpenMP>& policy, Functor f, ValueType& result, Reducer reducer) {
    ValueType total = reducer.init();

#pragma omp parallel
    {
        ValueType local = reducer.init();

        if (policy.schedule() == Schedule::Dynamic) {
#pragma omp for schedule(dynamic)
            for (long long i = static_cast<long long>(policy.begin());
                 i < static_cast<long long>(policy.end());
                 ++i) {
                ValueType value = reducer.init();
                f(static_cast<size_t>(i), value);
                reducer.join(local, value);
            }
        } else if (policy.schedule() == Schedule::Guided) {
#pragma omp for schedule(guided)
            for (long long i = static_cast<long long>(policy.begin());
                 i < static_cast<long long>(policy.end());
                 ++i) {
                ValueType value = reducer.init();
                f(static_cast<size_t>(i), value);
                reducer.join(local, value);
            }
        } else {
#pragma omp for schedule(static)
            for (long long i = static_cast<long long>(policy.begin());
                 i < static_cast<long long>(policy.end());
                 ++i) {
                ValueType value = reducer.init();
                f(static_cast<size_t>(i), value);
                reducer.join(local, value);
            }
        }

#pragma omp critical
        {
            reducer.join(total, local);
        }
    }

    result = total;
}

} // namespace LongX
