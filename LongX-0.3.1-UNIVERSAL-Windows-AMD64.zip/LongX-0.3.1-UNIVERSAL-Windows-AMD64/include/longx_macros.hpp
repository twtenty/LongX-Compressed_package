#pragma once

#if defined(LONGX_ENABLE_CUDA)

#define LONGX_DEVICE __device__
#define LONGX_HOST   __host__
#define LONGX_HD     __host__ __device__

#elif defined(LONGX_ENABLE_HIP)

#define LONGX_DEVICE __device__
#define LONGX_HOST   __host__
#define LONGX_HD     __host__ __device__

#elif defined(LONGX_ENABLE_MUSA)

#define LONGX_DEVICE __device__
#define LONGX_HOST   __host__
#define LONGX_HD     __host__ __device__

#elif defined(LONGX_ENABLE_SYCL)

#define LONGX_DEVICE
#define LONGX_HOST
#define LONGX_HD

#else

#define LONGX_DEVICE
#define LONGX_HOST
#define LONGX_HD

#endif
