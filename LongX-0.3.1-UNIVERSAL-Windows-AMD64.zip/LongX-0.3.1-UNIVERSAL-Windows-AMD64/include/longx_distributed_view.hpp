#pragma once

#include <cstddef>
#include <vector>

#include "longx_mpi_runtime.hpp"
#include "longx_view.hpp"

namespace LongX {

template<typename T>
class DistributedView {
public:
    using value_type = T;
    using memory_space = HostSpace;

    DistributedView(const char* label, std::size_t global_extent)
    : global_extent_(global_extent),
      partition_(mpi::partition_range(0, global_extent, mpi::world_rank(), mpi::world_size())),
      local_(label, partition_.end - partition_.begin),
      has_left_halo_(false),
      has_right_halo_(false),
      left_halo_{},
      right_halo_{}
    {}

    std::size_t global_extent() const {
        return global_extent_;
    }

    std::size_t local_extent() const {
        return local_.extent();
    }

    std::size_t local_begin() const {
        return partition_.begin;
    }

    std::size_t local_end() const {
        return partition_.end;
    }

    View<T, HostSpace>& local_view() {
        return local_;
    }

    const View<T, HostSpace>& local_view() const {
        return local_;
    }

    T& local(std::size_t i) {
        return local_(i);
    }

    const T& local(std::size_t i) const {
        return local_(i);
    }

    std::size_t global_index(std::size_t local_index) const {
        return partition_.begin + local_index;
    }

    bool has_left_halo() const {
        return has_left_halo_;
    }

    bool has_right_halo() const {
        return has_right_halo_;
    }

    const T& left_halo() const {
        return left_halo_;
    }

    const T& right_halo() const {
        return right_halo_;
    }

    void exchange_halo() {
        if (local_extent() == 0) {
            has_left_halo_ = false;
            has_right_halo_ = false;
            left_halo_ = T{};
            right_halo_ = T{};
            return;
        }

        const mpi::NeighborHalo<T> halo =
            mpi::exchange_neighbor_halo(local(0), local(local_extent() - 1));
        has_left_halo_ = halo.has_left;
        has_right_halo_ = halo.has_right;
        left_halo_ = halo.left;
        right_halo_ = halo.right;
    }

private:
    std::size_t global_extent_;
    mpi::RangePartition partition_;
    View<T, HostSpace> local_;
    bool has_left_halo_;
    bool has_right_halo_;
    T left_halo_;
    T right_halo_;
};

template<typename T>
T distributed_sum(const DistributedView<T>& view) {
    T local{};
    for (std::size_t i = 0; i < view.local_extent(); ++i) {
        local += view.local(i);
    }
    return mpi::allreduce_sum(local);
}

template<typename T>
std::vector<std::size_t> distributed_local_extents(const DistributedView<T>& view) {
    return mpi::allgather_value(view.local_extent());
}

} // namespace LongX
