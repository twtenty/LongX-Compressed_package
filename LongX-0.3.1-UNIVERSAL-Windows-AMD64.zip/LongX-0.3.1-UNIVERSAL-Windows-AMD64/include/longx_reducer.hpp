#pragma once

#include "longx_macros.hpp"

namespace LongX {

template<typename T>
struct Sum {
    using value_type = T;

    LONGX_HD
    T init() const {
        return T{};
    }

    LONGX_HD
    void join(T& dst, const T& src) const {
        dst += src;
    }
};

template<typename T>
struct Min {
    using value_type = T;

    T identity;

    explicit Min(T identity_value) : identity(identity_value) {}

    LONGX_HD
    T init() const {
        return identity;
    }

    LONGX_HD
    void join(T& dst, const T& src) const {
        if (src < dst) {
            dst = src;
        }
    }
};

template<typename T>
struct Max {
    using value_type = T;

    T identity;

    explicit Max(T identity_value) : identity(identity_value) {}

    LONGX_HD
    T init() const {
        return identity;
    }

    LONGX_HD
    void join(T& dst, const T& src) const {
        if (src > dst) {
            dst = src;
        }
    }
};

} // namespace LongX
