#pragma once

#include <cassert>
#include <cstddef>
#include <utility>

#ifdef LONGX_ENABLE_CUDA
#include "longx_error.hpp"
#endif

#include "longx_device_view.hpp"
#include "longx_memory_space.hpp"

namespace LongX {

template<typename T, typename MemorySpace>
class View;

#ifdef LONGX_ENABLE_CUDA
template<typename T>
class View<T, CudaSpace> {
public:
    using value_type = T;
    using memory_space = CudaSpace;

    View(const char* label, size_t n)
    : data_(nullptr), extent_(n), label_(label)
    {
        LONGX_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&data_), sizeof(T) * n));
    }

    ~View() {
        release();
    }

    View(const View&) = delete;
    View& operator=(const View&) = delete;

    View(View&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent_(std::exchange(other.extent_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View& operator=(View&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent_ = std::exchange(other.extent_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent_; }
    T* data() const { return data_; }

    T& operator()(size_t) = delete;

    DeviceView<T> device() const {
        return DeviceView<T>{data_, extent_};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_CUDA_CHECK(cudaFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent_;
    const char* label_;
};
#endif

template<typename T>
class View<T, HostSpace> {
public:
    using value_type = T;
    using memory_space = HostSpace;

    View(const char* label, size_t n)
    : data_(new T[n]), extent_(n), label_(label)
    {}

    ~View() {
        delete[] data_;
    }

    View(const View&) = delete;
    View& operator=(const View&) = delete;

    View(View&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent_(std::exchange(other.extent_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View& operator=(View&& other) noexcept {
        if (this != &other) {
            delete[] data_;
            data_ = std::exchange(other.data_, nullptr);
            extent_ = std::exchange(other.extent_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent_; }
    T* data() const { return data_; }

    T& operator()(size_t i) {
        assert(i < extent_);
        return data_[i];
    }

    const T& operator()(size_t i) const {
        assert(i < extent_);
        return data_[i];
    }

    DeviceView<T> device() const {
        return DeviceView<T>{data_, extent_};
    }

private:
    T* data_;
    size_t extent_;
    const char* label_;
};

template<typename T>
class View<T, OpenMPSpace> : public View<T, HostSpace> {
public:
    using View<T, HostSpace>::View;
    using memory_space = OpenMPSpace;
};

} // namespace LongX
