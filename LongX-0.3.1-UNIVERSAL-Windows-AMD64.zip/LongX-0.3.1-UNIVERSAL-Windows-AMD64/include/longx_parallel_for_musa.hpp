#pragma once

#include <cstddef>
#include <vector>

#include "longx_error.hpp"
#include "longx_exec_space.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"

namespace LongX {

template<typename Functor>
__global__ void longx_musa_kernel(size_t begin, size_t end, Functor f) {
    size_t i = begin + blockIdx.x * blockDim.x + threadIdx.x;
    if (i < end) {
        f(i);
    }
}

template<typename Functor>
__global__ void longx_musa_md2_kernel(
    size_t begin0,
    size_t begin1,
    size_t end0,
    size_t end1,
    Functor f
) {
    size_t i = begin0 + blockIdx.y * blockDim.y + threadIdx.y;
    size_t j = begin1 + blockIdx.x * blockDim.x + threadIdx.x;
    if (i < end0 && j < end1) {
        f(i, j);
    }
}

template<typename Functor, typename ValueType>
__global__ void longx_musa_reduce_kernel(size_t begin, size_t end, Functor f, ValueType* partials) {
    extern __shared__ unsigned char raw_shared[];
    ValueType* shared = reinterpret_cast<ValueType*>(raw_shared);

    size_t tid = threadIdx.x;
    size_t i = begin + blockIdx.x * blockDim.x + tid;
    ValueType local{};
    if (i < end) {
        f(i, local);
    }

    shared[tid] = local;
    __syncthreads();

    for (size_t stride = blockDim.x / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            shared[tid] += shared[tid + stride];
        }
        __syncthreads();
    }

    if (tid == 0) {
        partials[blockIdx.x] = shared[0];
    }
}

template<typename Functor, typename ValueType, typename Reducer>
__global__ void longx_musa_reduce_kernel(
    size_t begin,
    size_t end,
    Functor f,
    ValueType* partials,
    Reducer reducer
) {
    extern __shared__ unsigned char raw_shared[];
    ValueType* shared = reinterpret_cast<ValueType*>(raw_shared);

    size_t tid = threadIdx.x;
    size_t i = begin + blockIdx.x * blockDim.x + tid;
    ValueType local = reducer.init();
    if (i < end) {
        ValueType value = reducer.init();
        f(i, value);
        reducer.join(local, value);
    }

    shared[tid] = local;
    __syncthreads();

    for (size_t stride = blockDim.x / 2; stride > 0; stride >>= 1) {
        if (tid < stride) {
            reducer.join(shared[tid], shared[tid + stride]);
        }
        __syncthreads();
    }

    if (tid == 0) {
        partials[blockIdx.x] = shared[0];
    }
}

template<typename Functor>
void parallel_for(const RangePolicy<Musa>& policy, Functor f) {
    int block_size = policy.block_size();
    size_t n = policy.end() - policy.begin();
    if (n == 0) {
        return;
    }

    int grid_size = static_cast<int>((n + block_size - 1) / block_size);

    longx_musa_kernel<<<grid_size, block_size>>>(policy.begin(), policy.end(), f);
    LONGX_MUSA_CHECK(musaGetLastError());
}

template<typename Functor>
void parallel_for(const MDRangePolicy<Musa, 2>& policy, Functor f) {
    if (policy.size() == 0) {
        return;
    }

    dim3 block_size(
        static_cast<unsigned int>(policy.tile1()),
        static_cast<unsigned int>(policy.tile0())
    );
    dim3 grid_size(
        static_cast<unsigned int>((policy.extent1() + block_size.x - 1) / block_size.x),
        static_cast<unsigned int>((policy.extent0() + block_size.y - 1) / block_size.y)
    );

    longx_musa_md2_kernel<<<grid_size, block_size>>>(
        policy.begin0(),
        policy.begin1(),
        policy.end0(),
        policy.end1(),
        f
    );
    LONGX_MUSA_CHECK(musaGetLastError());
}

template<typename Functor, typename ValueType>
void parallel_reduce(const RangePolicy<Musa>& policy, Functor f, ValueType& result) {
    int block_size = policy.block_size();
    size_t n = policy.end() - policy.begin();
    if (n == 0) {
        result = ValueType{};
        return;
    }

    int grid_size = static_cast<int>((n + block_size - 1) / block_size);
    ValueType* d_partials = nullptr;
    LONGX_MUSA_CHECK(musaMalloc(reinterpret_cast<void**>(&d_partials), sizeof(ValueType) * grid_size));

    longx_musa_reduce_kernel<<<grid_size, block_size, sizeof(ValueType) * block_size>>>(
        policy.begin(),
        policy.end(),
        f,
        d_partials
    );
    LONGX_MUSA_CHECK(musaGetLastError());

    std::vector<ValueType> partials(static_cast<size_t>(grid_size));
    LONGX_MUSA_CHECK(musaMemcpy(
        partials.data(),
        d_partials,
        sizeof(ValueType) * partials.size(),
        musaMemcpyDeviceToHost
    ));
    LONGX_MUSA_CHECK(musaFree(d_partials));

    ValueType total{};
    for (const auto& value : partials) {
        total += value;
    }
    result = total;
}

template<typename Functor, typename ValueType, typename Reducer>
void parallel_reduce(const RangePolicy<Musa>& policy, Functor f, ValueType& result, Reducer reducer) {
    int block_size = policy.block_size();
    size_t n = policy.end() - policy.begin();
    if (n == 0) {
        result = reducer.init();
        return;
    }

    int grid_size = static_cast<int>((n + block_size - 1) / block_size);
    ValueType* d_partials = nullptr;
    LONGX_MUSA_CHECK(musaMalloc(reinterpret_cast<void**>(&d_partials), sizeof(ValueType) * grid_size));

    longx_musa_reduce_kernel<<<grid_size, block_size, sizeof(ValueType) * block_size>>>(
        policy.begin(),
        policy.end(),
        f,
        d_partials,
        reducer
    );
    LONGX_MUSA_CHECK(musaGetLastError());

    std::vector<ValueType> partials(static_cast<size_t>(grid_size));
    LONGX_MUSA_CHECK(musaMemcpy(
        partials.data(),
        d_partials,
        sizeof(ValueType) * partials.size(),
        musaMemcpyDeviceToHost
    ));
    LONGX_MUSA_CHECK(musaFree(d_partials));

    ValueType total = reducer.init();
    for (const auto& value : partials) {
        reducer.join(total, value);
    }
    result = total;
}

} // namespace LongX
