#pragma once

#include <cstddef>
#include <algorithm>

#include "longx_error.hpp"
#include "longx_exec_space.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"

namespace LongX {

template<typename Functor>
__global__ void longx_cuda_kernel(size_t begin, size_t end, Functor f) {
    size_t i = begin + blockIdx.x * blockDim.x + threadIdx.x;
    if (i < end) {
        f(i);
    }
}

template<typename Functor>
__global__ void longx_cuda_md2_kernel(
    size_t begin0,
    size_t begin1,
    size_t end0,
    size_t end1,
    Functor f
) {
    size_t i = begin0 + blockIdx.y * blockDim.y + threadIdx.y;
    size_t j = begin1 + blockIdx.x * blockDim.x + threadIdx.x;
    if (i < end0 && j < end1) {
        f(i, j);
    }
}

template<typename Functor, typename ValueType, typename Reducer>
__global__ void longx_cuda_reduce_grid_stride_kernel(
    size_t begin,
    size_t end,
    Functor f,
    ValueType* partials,
    Reducer reducer
) {
    extern __shared__ unsigned char raw_shared[];
    ValueType* shared = reinterpret_cast<ValueType*>(raw_shared);

    const size_t tid = threadIdx.x;
    const size_t global = static_cast<size_t>(blockIdx.x) * blockDim.x + tid;
    const size_t stride = static_cast<size_t>(blockDim.x) * gridDim.x;

    ValueType local = reducer.init();
    for (size_t i = begin + global; i < end; i += stride) {
        ValueType value = reducer.init();
        f(i, value);
        reducer.join(local, value);
    }

    shared[tid] = local;
    __syncthreads();

    for (size_t reduce_stride = blockDim.x / 2; reduce_stride > 0; reduce_stride >>= 1) {
        if (tid < reduce_stride) {
            reducer.join(shared[tid], shared[tid + reduce_stride]);
        }
        __syncthreads();
    }

    if (tid == 0) {
        partials[blockIdx.x] = shared[0];
    }
}

template<typename ValueType, typename Reducer>
__global__ void longx_cuda_reduce_partials_kernel(
    const ValueType* input,
    size_t count,
    ValueType* output,
    Reducer reducer
) {
    extern __shared__ unsigned char raw_shared[];
    ValueType* shared = reinterpret_cast<ValueType*>(raw_shared);

    const size_t tid = threadIdx.x;
    const size_t global = static_cast<size_t>(blockIdx.x) * blockDim.x + tid;
    const size_t stride = static_cast<size_t>(blockDim.x) * gridDim.x;

    ValueType local = reducer.init();
    for (size_t i = global; i < count; i += stride) {
        reducer.join(local, input[i]);
    }

    shared[tid] = local;
    __syncthreads();

    for (size_t reduce_stride = blockDim.x / 2; reduce_stride > 0; reduce_stride >>= 1) {
        if (tid < reduce_stride) {
            reducer.join(shared[tid], shared[tid + reduce_stride]);
        }
        __syncthreads();
    }

    if (tid == 0) {
        output[blockIdx.x] = shared[0];
    }
}

inline int cuda_reduce_grid_size(size_t count, int block_size) {
    constexpr int max_reduce_blocks = 4096;
    const size_t blocks = (count + static_cast<size_t>(block_size) - 1) /
        static_cast<size_t>(block_size);
    return std::max(1, static_cast<int>(std::min(blocks, static_cast<size_t>(max_reduce_blocks))));
}

template<typename Functor>
void parallel_for(const RangePolicy<Cuda>& policy, Functor f) {
    int block_size = policy.block_size();
    size_t n = policy.end() - policy.begin();
    if (n == 0) {
        return;
    }

    int grid_size = static_cast<int>((n + block_size - 1) / block_size);

    longx_cuda_kernel<<<grid_size, block_size>>>(policy.begin(), policy.end(), f);
    LONGX_CUDA_CHECK(cudaGetLastError());
}

template<typename Functor>
void parallel_for(const MDRangePolicy<Cuda, 2>& policy, Functor f) {
    if (policy.size() == 0) {
        return;
    }

    dim3 block_size(
        static_cast<unsigned int>(policy.tile1()),
        static_cast<unsigned int>(policy.tile0())
    );
    dim3 grid_size(
        static_cast<unsigned int>((policy.extent1() + block_size.x - 1) / block_size.x),
        static_cast<unsigned int>((policy.extent0() + block_size.y - 1) / block_size.y)
    );

    longx_cuda_md2_kernel<<<grid_size, block_size>>>(
        policy.begin0(),
        policy.begin1(),
        policy.end0(),
        policy.end1(),
        f
    );
    LONGX_CUDA_CHECK(cudaGetLastError());
}

template<typename Functor, typename ValueType>
void parallel_reduce(const RangePolicy<Cuda>& policy, Functor f, ValueType& result) {
    parallel_reduce(policy, f, result, Sum<ValueType>{});
}

template<typename Functor, typename ValueType, typename Reducer>
void parallel_reduce(const RangePolicy<Cuda>& policy, Functor f, ValueType& result, Reducer reducer) {
    int block_size = policy.block_size();
    size_t n = policy.end() - policy.begin();
    if (n == 0) {
        result = reducer.init();
        return;
    }

    int grid_size = cuda_reduce_grid_size(n, block_size);
    ValueType* d_partials = nullptr;
    LONGX_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&d_partials), sizeof(ValueType) * grid_size));

    longx_cuda_reduce_grid_stride_kernel<<<grid_size, block_size, sizeof(ValueType) * block_size>>>(
        policy.begin(),
        policy.end(),
        f,
        d_partials,
        reducer
    );
    LONGX_CUDA_CHECK(cudaGetLastError());

    ValueType* d_scratch = nullptr;
    ValueType* d_next = nullptr;
    int current_count = grid_size;
    ValueType* d_current = d_partials;
    if (current_count > 1) {
        int next_count = cuda_reduce_grid_size(static_cast<size_t>(current_count), block_size);
        LONGX_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&d_scratch), sizeof(ValueType) * next_count));
        d_next = d_scratch;

        while (current_count > 1) {
            next_count = cuda_reduce_grid_size(static_cast<size_t>(current_count), block_size);
            longx_cuda_reduce_partials_kernel<<<next_count, block_size, sizeof(ValueType) * block_size>>>(
                d_current,
                static_cast<size_t>(current_count),
                d_next,
                reducer
            );
            LONGX_CUDA_CHECK(cudaGetLastError());

            current_count = next_count;
            ValueType* previous = d_current;
            d_current = d_next;
            d_next = previous;
        }
    }

    LONGX_CUDA_CHECK(cudaMemcpy(&result, d_current, sizeof(ValueType), cudaMemcpyDeviceToHost));
    LONGX_CUDA_CHECK(cudaFree(d_partials));
    if (d_scratch != nullptr) {
        LONGX_CUDA_CHECK(cudaFree(d_scratch));
    }
}

} // namespace LongX
