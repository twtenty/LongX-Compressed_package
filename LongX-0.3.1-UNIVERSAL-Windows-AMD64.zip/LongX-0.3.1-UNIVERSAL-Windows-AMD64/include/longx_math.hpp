#pragma once

#include <cassert>
#include <cmath>
#include <complex>
#include <cstddef>
#include <cstdint>

namespace LongX {
namespace math {

inline const char* backend_name() {
    return "LongX portable math fallback";
}

namespace detail {

constexpr double pi() {
    return 3.141592653589793238462643383279502884;
}

inline double uniform01(uint64_t& state) {
    state = state * 6364136223846793005ULL + 1442695040888963407ULL;
    const uint64_t mantissa = state >> 11;
    return static_cast<double>(mantissa) * (1.0 / 9007199254740992.0);
}

} // namespace detail

template<typename ViewType>
void fill_uniform(ViewType& output,
                  typename ViewType::value_type lower,
                  typename ViewType::value_type upper,
                  uint64_t seed = 1) {
    using ValueType = typename ViewType::value_type;
    assert(lower <= upper);
    uint64_t state = seed == 0 ? 1 : seed;
    const double span = static_cast<double>(upper - lower);
    for (size_t i = 0; i < output.extent(); ++i) {
        output.data()[i] = static_cast<ValueType>(
            static_cast<double>(lower) + span * detail::uniform01(state)
        );
    }
}

template<typename RealView, typename ComplexView>
void dft_r2c(const RealView& input, ComplexView& output) {
    using Complex = typename ComplexView::value_type;
    using Real = typename RealView::value_type;
    assert(input.extent() == output.extent());
    const size_t n = input.extent();
    for (size_t k = 0; k < n; ++k) {
        Complex sum{};
        for (size_t t = 0; t < n; ++t) {
            const double angle = -2.0 * detail::pi() *
                                 static_cast<double>(k * t) /
                                 static_cast<double>(n);
            const Complex phase(static_cast<Real>(std::cos(angle)),
                                static_cast<Real>(std::sin(angle)));
            sum += static_cast<Real>(input.data()[t]) * phase;
        }
        output.data()[k] = sum;
    }
}

template<typename RowOffsetsView, typename ColIndicesView, typename ValuesView,
         typename XView, typename YView>
void csr_spmv(const RowOffsetsView& row_offsets,
              const ColIndicesView& col_indices,
              const ValuesView& values,
              const XView& x,
              YView& y) {
    using ValueType = typename YView::value_type;
    assert(row_offsets.extent() == y.extent() + 1);
    for (size_t row = 0; row < y.extent(); ++row) {
        ValueType sum{};
        const size_t begin = static_cast<size_t>(row_offsets.data()[row]);
        const size_t end = static_cast<size_t>(row_offsets.data()[row + 1]);
        assert(begin <= end);
        assert(end <= values.extent());
        assert(end <= col_indices.extent());
        for (size_t entry = begin; entry < end; ++entry) {
            const size_t col = static_cast<size_t>(col_indices.data()[entry]);
            assert(col < x.extent());
            sum += static_cast<ValueType>(values.data()[entry]) *
                   static_cast<ValueType>(x.data()[col]);
        }
        y.data()[row] = sum;
    }
}

} // namespace math
} // namespace LongX
