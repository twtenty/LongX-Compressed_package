#pragma once

#include <cstddef>
#include <cstdio>
#include <cstdlib>

#include <sycl/sycl.hpp>

namespace LongX {
namespace sycl_runtime {

inline sycl::queue& queue() {
    static sycl::queue q{sycl::default_selector_v};
    return q;
}

inline bool available() {
    try {
        (void)queue().get_device();
        return true;
    } catch (const sycl::exception&) {
        return false;
    }
}

inline int device_count() {
    try {
        int count = 0;
        for (const auto& platform : sycl::platform::get_platforms()) {
            count += static_cast<int>(platform.get_devices().size());
        }
        return count > 0 ? count : 1;
    } catch (const sycl::exception&) {
        return 1;
    }
}

inline size_t global_memory_bytes() {
    try {
        const auto device = queue().get_device();
        if (device.has(sycl::aspect::usm_shared_allocations)) {
            return device.get_info<sycl::info::device::global_mem_size>();
        }
    } catch (const sycl::exception&) {
    }
    return 0;
}

inline void abort_on_exception(const char* file, int line, const sycl::exception& error) {
    std::fprintf(stderr, "LongX SYCL error at %s:%d: %s\n", file, line, error.what());
    std::abort();
}

} // namespace sycl_runtime
} // namespace LongX

