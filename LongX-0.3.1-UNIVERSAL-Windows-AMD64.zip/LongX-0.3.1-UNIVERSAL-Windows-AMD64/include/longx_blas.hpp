#pragma once

#include "longx_blas_fallback.hpp"
#include "longx_blas_vendor.hpp"
#include "longx_exec_space.hpp"

namespace LongX {
namespace blas {

inline const char* backend_name() {
    if (vendor::available()) {
        return vendor::backend_name();
    }
    return fallback::backend_name();
}

inline const char* requested_vendor_backend_name() {
    return vendor::requested_backend_name();
}

inline bool vendor_backend_requested() {
    return vendor::requested();
}

inline bool vendor_backend_available() {
    return vendor::available();
}

template<typename ExecSpace = DefaultExecutionSpace, typename SrcView, typename DstView>
void copy(const SrcView& x, DstView& y) {
    if (vendor::copy<ExecSpace>(x, y)) {
        return;
    }
    fallback::copy<ExecSpace>(x, y);
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename ViewType>
void scal(Scalar alpha, ViewType& x) {
    if (vendor::scal<ExecSpace>(alpha, x)) {
        return;
    }
    fallback::scal<ExecSpace>(alpha, x);
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename XView, typename YView>
void axpy(Scalar alpha, const XView& x, YView& y) {
    if (vendor::axpy<ExecSpace>(alpha, x, y)) {
        return;
    }
    fallback::axpy<ExecSpace>(alpha, x, y);
}

template<typename ExecSpace = DefaultExecutionSpace, typename XView, typename YView>
typename XView::value_type dot(const XView& x, const YView& y) {
    typename XView::value_type result{};
    if (vendor::dot<ExecSpace>(x, y, result)) {
        return result;
    }
    return fallback::dot<ExecSpace>(x, y);
}

template<typename ExecSpace = DefaultExecutionSpace, typename ViewType>
typename ViewType::value_type nrm2(const ViewType& x) {
    typename ViewType::value_type result{};
    if (vendor::nrm2<ExecSpace>(x, result)) {
        return result;
    }
    return fallback::nrm2<ExecSpace>(x);
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename MatrixView,
         typename XView, typename YView>
void gemv(Scalar alpha, const MatrixView& a, const XView& x, Scalar beta, YView& y) {
    if (vendor::gemv<ExecSpace>(alpha, a, x, beta, y)) {
        return;
    }
    fallback::gemv<ExecSpace>(alpha, a, x, beta, y);
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename AView,
         typename BView, typename CView>
void gemm(Scalar alpha, const AView& a, const BView& b, Scalar beta, CView& c) {
    if (vendor::gemm<ExecSpace>(alpha, a, b, beta, c)) {
        return;
    }
    fallback::gemm<ExecSpace>(alpha, a, b, beta, c);
}

} // namespace blas
} // namespace LongX
