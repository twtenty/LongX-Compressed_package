#pragma once

#include <cassert>
#include <cstddef>

#include "longx_exec_space.hpp"
#include "longx_macros.hpp"
#include "longx_parallel_for.hpp"
#include "longx_range_policy.hpp"

namespace LongX {

template<typename ExecSpace = DefaultExecutionSpace, typename ViewType, typename ValueType>
void parallel_fill(ViewType& dst, const ValueType& value) {
    auto dst_d = dst.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, dst.extent()),
        [=] LONGX_DEVICE (size_t i) {
            dst_d.data[i] = value;
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename SrcView, typename DstView>
void parallel_copy(const SrcView& src, DstView& dst) {
    assert(src.extent() == dst.extent());
    auto src_d = src.device();
    auto dst_d = dst.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, src.extent()),
        [=] LONGX_DEVICE (size_t i) {
            dst_d.data[i] = src_d.data[i];
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename SrcView, typename DstView, typename UnaryOp>
void parallel_transform(const SrcView& src, DstView& dst, UnaryOp op) {
    assert(src.extent() == dst.extent());
    auto src_d = src.device();
    auto dst_d = dst.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, src.extent()),
        [=] LONGX_DEVICE (size_t i) {
            dst_d.data[i] = op(src_d.data[i]);
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename LeftView, typename RightView, typename DstView, typename BinaryOp>
void parallel_transform(const LeftView& left, const RightView& right, DstView& dst, BinaryOp op) {
    assert(left.extent() == right.extent());
    assert(left.extent() == dst.extent());
    auto left_d = left.device();
    auto right_d = right.device();
    auto dst_d = dst.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, left.extent()),
        [=] LONGX_DEVICE (size_t i) {
            dst_d.data[i] = op(left_d.data[i], right_d.data[i]);
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename SrcView, typename DstView>
void parallel_scan(const SrcView& src, DstView& dst) {
    assert(src.extent() == dst.extent());
    using ValueType = typename SrcView::value_type;
    auto src_d = src.device();
    auto dst_d = dst.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, src.extent()),
        [=] LONGX_DEVICE (size_t i) {
            ValueType total{};
            for (size_t j = 0; j <= i; ++j) {
                total += src_d.data[j];
            }
            dst_d.data[i] = total;
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename SrcView, typename DstView, typename BinaryOp>
void parallel_scan(const SrcView& src, DstView& dst, BinaryOp op) {
    assert(src.extent() == dst.extent());
    using ValueType = typename SrcView::value_type;
    auto src_d = src.device();
    auto dst_d = dst.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, src.extent()),
        [=] LONGX_DEVICE (size_t i) {
            ValueType total{};
            if (i < src_d.extent) {
                total = src_d.data[0];
                for (size_t j = 1; j <= i; ++j) {
                    total = op(total, src_d.data[j]);
                }
            }
            dst_d.data[i] = total;
        }
    );
}

} // namespace LongX
