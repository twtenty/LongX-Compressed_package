#pragma once

#include <cassert>
#include <cmath>
#include <cstddef>

#include "longx_exec_space.hpp"
#include "longx_macros.hpp"
#include "longx_parallel_for.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"

namespace LongX {
namespace blas {
namespace fallback {

inline const char* backend_name() {
    return "LongX portable BLAS fallback";
}

template<typename ExecSpace = DefaultExecutionSpace, typename SrcView, typename DstView>
void copy(const SrcView& x, DstView& y) {
    assert(x.extent() == y.extent());
    auto x_d = x.device();
    auto y_d = y.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, x.extent()),
        [=] LONGX_DEVICE (size_t i) {
            y_d.data[i] = x_d.data[i];
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename ViewType>
void scal(Scalar alpha, ViewType& x) {
    auto x_d = x.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, x.extent()),
        [=] LONGX_DEVICE (size_t i) {
            x_d.data[i] = static_cast<typename ViewType::value_type>(alpha) * x_d.data[i];
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename XView, typename YView>
void axpy(Scalar alpha, const XView& x, YView& y) {
    assert(x.extent() == y.extent());
    auto x_d = x.device();
    auto y_d = y.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, x.extent()),
        [=] LONGX_DEVICE (size_t i) {
            y_d.data[i] += static_cast<typename YView::value_type>(alpha) * x_d.data[i];
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename XView, typename YView>
typename XView::value_type dot(const XView& x, const YView& y) {
    assert(x.extent() == y.extent());
    using ValueType = typename XView::value_type;
    auto x_d = x.device();
    auto y_d = y.device();
    ValueType result{};
    parallel_reduce(
        RangePolicy<ExecSpace>(0, x.extent()),
        [=] LONGX_DEVICE (size_t i, ValueType& value) {
            value = x_d.data[i] * static_cast<ValueType>(y_d.data[i]);
        },
        result,
        Sum<ValueType>{}
    );
    return result;
}

template<typename ExecSpace = DefaultExecutionSpace, typename ViewType>
typename ViewType::value_type nrm2(const ViewType& x) {
    using ValueType = typename ViewType::value_type;
    ValueType squared = dot<ExecSpace>(x, x);
    return static_cast<ValueType>(std::sqrt(static_cast<double>(squared)));
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename MatrixView,
         typename XView, typename YView>
void gemv(Scalar alpha, const MatrixView& a, const XView& x, Scalar beta, YView& y) {
    assert(a.extent1() == x.extent());
    assert(a.extent0() == y.extent());
    auto a_d = a.device();
    auto x_d = x.device();
    auto y_d = y.device();
    parallel_for(
        RangePolicy<ExecSpace>(0, a.extent0()),
        [=] LONGX_DEVICE (size_t row) {
            using ValueType = typename YView::value_type;
            ValueType sum{};
            for (size_t col = 0; col < a_d.extent1; ++col) {
                sum += static_cast<ValueType>(a_d(row, col)) *
                       static_cast<ValueType>(x_d.data[col]);
            }
            y_d.data[row] = static_cast<ValueType>(alpha) * sum +
                            static_cast<ValueType>(beta) * y_d.data[row];
        }
    );
}

template<typename ExecSpace = DefaultExecutionSpace, typename Scalar, typename AView,
         typename BView, typename CView>
void gemm(Scalar alpha, const AView& a, const BView& b, Scalar beta, CView& c) {
    assert(a.extent1() == b.extent0());
    assert(a.extent0() == c.extent0());
    assert(b.extent1() == c.extent1());
    auto a_d = a.device();
    auto b_d = b.device();
    auto c_d = c.device();
    const size_t cols = c.extent1();
    parallel_for(
        RangePolicy<ExecSpace>(0, c.extent()),
        [=] LONGX_DEVICE (size_t index) {
            using ValueType = typename CView::value_type;
            const size_t row = index / cols;
            const size_t col = index % cols;
            ValueType sum{};
            for (size_t inner = 0; inner < a_d.extent1; ++inner) {
                sum += static_cast<ValueType>(a_d(row, inner)) *
                       static_cast<ValueType>(b_d(inner, col));
            }
            c_d(row, col) = static_cast<ValueType>(alpha) * sum +
                            static_cast<ValueType>(beta) * c_d(row, col);
        }
    );
}

} // namespace fallback
} // namespace blas
} // namespace LongX
