#pragma once

#include <cstdio>
#include <cstdlib>

#ifdef LONGX_ENABLE_CUDA
#include <cuda_runtime.h>
#define LONGX_CUDA_CHECK(call)                                                \
    do {                                                                      \
        cudaError_t longx_err = (call);                                       \
        if (longx_err != cudaSuccess) {                                       \
            std::fprintf(stderr, "LongX CUDA error at %s:%d: %s\n",           \
                         __FILE__, __LINE__, cudaGetErrorString(longx_err));  \
            std::abort();                                                     \
        }                                                                     \
    } while (false)
#endif

#ifdef LONGX_ENABLE_HIP
#include <hip/hip_runtime.h>
#define LONGX_HIP_CHECK(call)                                               \
    do {                                                                    \
        hipError_t longx_err = (call);                                      \
        if (longx_err != hipSuccess) {                                      \
            std::fprintf(stderr, "LongX HIP error at %s:%d: %s\n",          \
                         __FILE__, __LINE__, hipGetErrorString(longx_err)); \
            std::abort();                                                   \
        }                                                                   \
    } while (false)
#endif

#ifdef LONGX_ENABLE_MUSA
#include <musa_runtime.h>
#define LONGX_MUSA_CHECK(call)                                               \
    do {                                                                     \
        musaError_t longx_err = (call);                                      \
        if (longx_err != musaSuccess) {                                      \
            std::fprintf(stderr, "LongX MUSA error at %s:%d: %s\n",          \
                         __FILE__, __LINE__, musaGetErrorString(longx_err)); \
            std::abort();                                                    \
        }                                                                    \
    } while (false)
#endif
