#pragma once

#if defined(LONGX_ENABLE_CUDA)
#include "longx_parallel_for_cuda.hpp"
#elif defined(LONGX_ENABLE_MUSA)
#include "longx_parallel_for_musa.hpp"
#elif defined(LONGX_ENABLE_SYCL)
#include "longx_parallel_for_sycl.hpp"
#elif defined(LONGX_ENABLE_OPENCL)
#include "longx_parallel_for_opencl.hpp"
#elif defined(LONGX_ENABLE_OPENGL)
#include "longx_parallel_for_opengl.hpp"
#elif defined(LONGX_ENABLE_HIP)
#include "longx_parallel_for_hip.hpp"
#elif defined(LONGX_ENABLE_MPI)
#include "longx_parallel_for_mpi.hpp"
#elif defined(LONGX_ENABLE_TBB)
#include "longx_parallel_for_tbb.hpp"
#elif defined(LONGX_ENABLE_OPENMP)
#include "longx_parallel_for_openmp.hpp"
#else
#include "longx_parallel_for_serial.hpp"
#endif
