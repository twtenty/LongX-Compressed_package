
#pragma once
#include "longx_macros.hpp"
#include <cstddef>

namespace LongX {
	
	template<typename T>
	struct DeviceView {
		T* data;
		size_t extent;
		
		LONGX_HD
		T& operator()(size_t i) const {
			return data[i];
		}
	};

	template<typename T>
	struct DeviceView2D {
		T* data;
		size_t extent0;
		size_t extent1;
		size_t stride0;
		
		LONGX_HD
		T& operator()(size_t row, size_t col) const {
			return data[row * stride0 + col];
		}

		LONGX_HD
		size_t index(size_t row, size_t col) const {
			return row * stride0 + col;
		}
	};

	template<typename T>
	struct DeviceView3D {
		T* data;
		size_t extent0;
		size_t extent1;
		size_t extent2;
		size_t stride0;
		size_t stride1;

		LONGX_HD
		T& operator()(size_t i, size_t j, size_t k) const {
			return data[i * stride0 + j * stride1 + k];
		}

		LONGX_HD
		size_t index(size_t i, size_t j, size_t k) const {
			return i * stride0 + j * stride1 + k;
		}
	};
	
} // namespace LongX
