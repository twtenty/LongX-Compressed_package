#pragma once

#include <cstddef>
#include <utility>

#include "longx_device_view.hpp"
#include "longx_error.hpp"
#include "longx_memory_space.hpp"
#include "longx_view.hpp"
#include "longx_view2d.hpp"
#include "longx_view3d.hpp"

namespace LongX {

template<typename T>
class View<T, MusaSpace> {
public:
    using value_type = T;
    using memory_space = MusaSpace;

    View(const char* label, size_t n)
    : data_(nullptr), extent_(n), label_(label)
    {
        LONGX_MUSA_CHECK(musaMalloc(reinterpret_cast<void**>(&data_), sizeof(T) * n));
    }

    ~View() {
        release();
    }

    View(const View&) = delete;
    View& operator=(const View&) = delete;

    View(View&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent_(std::exchange(other.extent_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View& operator=(View&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent_ = std::exchange(other.extent_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent_; }
    T* data() const { return data_; }

    T& operator()(size_t) = delete;

    DeviceView<T> device() const {
        return DeviceView<T>{data_, extent_};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_MUSA_CHECK(musaFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent_;
    const char* label_;
};

template<typename T>
class View2D<T, MusaSpace> {
public:
    using value_type = T;
    using memory_space = MusaSpace;

    View2D(const char* label, size_t extent0, size_t extent1)
    : data_(nullptr), extent0_(extent0), extent1_(extent1), label_(label)
    {
        LONGX_MUSA_CHECK(musaMalloc(
            reinterpret_cast<void**>(&data_),
            sizeof(T) * extent0_ * extent1_
        ));
    }

    ~View2D() {
        release();
    }

    View2D(const View2D&) = delete;
    View2D& operator=(const View2D&) = delete;

    View2D(View2D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View2D& operator=(View2D&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t stride0() const { return extent1_; }
    T* data() const { return data_; }

    T& operator()(size_t, size_t) = delete;

    DeviceView2D<T> device() const {
        return DeviceView2D<T>{data_, extent0_, extent1_, stride0()};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_MUSA_CHECK(musaFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent0_;
    size_t extent1_;
    const char* label_;
};

template<typename T>
class View3D<T, MusaSpace> {
public:
    using value_type = T;
    using memory_space = MusaSpace;

    View3D(const char* label, size_t extent0, size_t extent1, size_t extent2)
    : data_(nullptr), extent0_(extent0), extent1_(extent1), extent2_(extent2), label_(label)
    {
        LONGX_MUSA_CHECK(musaMalloc(
            reinterpret_cast<void**>(&data_),
            sizeof(T) * extent0_ * extent1_ * extent2_
        ));
    }

    ~View3D() {
        release();
    }

    View3D(const View3D&) = delete;
    View3D& operator=(const View3D&) = delete;

    View3D(View3D&& other) noexcept
    : data_(std::exchange(other.data_, nullptr)),
      extent0_(std::exchange(other.extent0_, 0)),
      extent1_(std::exchange(other.extent1_, 0)),
      extent2_(std::exchange(other.extent2_, 0)),
      label_(std::exchange(other.label_, nullptr))
    {}

    View3D& operator=(View3D&& other) noexcept {
        if (this != &other) {
            release();
            data_ = std::exchange(other.data_, nullptr);
            extent0_ = std::exchange(other.extent0_, 0);
            extent1_ = std::exchange(other.extent1_, 0);
            extent2_ = std::exchange(other.extent2_, 0);
            label_ = std::exchange(other.label_, nullptr);
        }
        return *this;
    }

    size_t extent() const { return extent0_ * extent1_ * extent2_; }
    size_t extent0() const { return extent0_; }
    size_t extent1() const { return extent1_; }
    size_t extent2() const { return extent2_; }
    size_t stride0() const { return extent1_ * extent2_; }
    size_t stride1() const { return extent2_; }
    T* data() const { return data_; }

    T& operator()(size_t, size_t, size_t) = delete;

    DeviceView3D<T> device() const {
        return DeviceView3D<T>{data_, extent0_, extent1_, extent2_, stride0(), stride1()};
    }

private:
    void release() {
        if (data_ != nullptr) {
            LONGX_MUSA_CHECK(musaFree(data_));
            data_ = nullptr;
        }
    }

    T* data_;
    size_t extent0_;
    size_t extent1_;
    size_t extent2_;
    const char* label_;
};

} // namespace LongX
