#pragma once

#include <algorithm>
#include <cstddef>

#include "longx_exec_space.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"
#include "longx_sycl_runtime.hpp"

namespace LongX {

template<typename Functor>
void parallel_for(const RangePolicy<Sycl>& policy, Functor f) {
    if (policy.size() == 0) {
        return;
    }

    const size_t begin = policy.begin();
    const size_t n = policy.size();
    try {
        sycl_runtime::queue()
            .parallel_for(sycl::range<1>(n), [=](sycl::id<1> idx) {
                f(begin + idx[0]);
            })
            .wait_and_throw();
    } catch (const sycl::exception& error) {
        sycl_runtime::abort_on_exception(__FILE__, __LINE__, error);
    }
}

template<typename Functor>
void parallel_for(const MDRangePolicy<Sycl, 2>& policy, Functor f) {
    if (policy.size() == 0) {
        return;
    }

    const size_t begin0 = policy.begin0();
    const size_t begin1 = policy.begin1();
    const size_t extent0 = policy.extent0();
    const size_t extent1 = policy.extent1();
    try {
        sycl_runtime::queue()
            .parallel_for(sycl::range<2>(extent0, extent1), [=](sycl::id<2> idx) {
                f(begin0 + idx[0], begin1 + idx[1]);
            })
            .wait_and_throw();
    } catch (const sycl::exception& error) {
        sycl_runtime::abort_on_exception(__FILE__, __LINE__, error);
    }
}

template<typename Functor, typename ValueType>
void parallel_reduce(const RangePolicy<Sycl>& policy, Functor f, ValueType& result) {
    if (policy.size() == 0) {
        result = ValueType{};
        return;
    }

    ValueType* partials = nullptr;
    const size_t begin = policy.begin();
    const size_t n = policy.size();
    const size_t local_size = static_cast<size_t>(std::max(1, policy.block_size()));
    const size_t group_count = (n + local_size - 1) / local_size;
    const size_t global_size = group_count * local_size;

    try {
        auto& q = sycl_runtime::queue();
        partials = sycl::malloc_shared<ValueType>(group_count, q);
        q.submit([&](sycl::handler& h) {
            sycl::local_accessor<ValueType, 1> scratch(sycl::range<1>(local_size), h);
            h.parallel_for(
                sycl::nd_range<1>(sycl::range<1>(global_size), sycl::range<1>(local_size)),
                [=](sycl::nd_item<1> item) {
                    const size_t local_id = item.get_local_id(0);
                    const size_t global_id = item.get_global_id(0);
                    ValueType local{};
                    if (global_id < n) {
                        f(begin + global_id, local);
                    }
                    scratch[local_id] = local;
                    item.barrier(sycl::access::fence_space::local_space);

                    for (size_t active = local_size; active > 1; active = (active + 1) / 2) {
                        const size_t stride = (active + 1) / 2;
                        if (local_id < stride && local_id + stride < active) {
                            scratch[local_id] += scratch[local_id + stride];
                        }
                        item.barrier(sycl::access::fence_space::local_space);
                    }

                    if (local_id == 0) {
                        partials[item.get_group(0)] = scratch[0];
                    }
                });
        }).wait_and_throw();

        ValueType total{};
        for (size_t group = 0; group < group_count; ++group) {
            total += partials[group];
        }
        sycl::free(partials, q);
        result = total;
    } catch (const sycl::exception& error) {
        if (partials != nullptr) {
            sycl::free(partials, sycl_runtime::queue());
        }
        sycl_runtime::abort_on_exception(__FILE__, __LINE__, error);
    }
}

template<typename Functor, typename ValueType, typename Reducer>
void parallel_reduce(const RangePolicy<Sycl>& policy, Functor f, ValueType& result, Reducer reducer) {
    if (policy.size() == 0) {
        result = reducer.init();
        return;
    }

    ValueType* partials = nullptr;
    const size_t begin = policy.begin();
    const size_t n = policy.size();
    const size_t local_size = static_cast<size_t>(std::max(1, policy.block_size()));
    const size_t group_count = (n + local_size - 1) / local_size;
    const size_t global_size = group_count * local_size;

    try {
        auto& q = sycl_runtime::queue();
        partials = sycl::malloc_shared<ValueType>(group_count, q);
        q.submit([&](sycl::handler& h) {
            sycl::local_accessor<ValueType, 1> scratch(sycl::range<1>(local_size), h);
            h.parallel_for(
                sycl::nd_range<1>(sycl::range<1>(global_size), sycl::range<1>(local_size)),
                [=](sycl::nd_item<1> item) {
                    const size_t local_id = item.get_local_id(0);
                    const size_t global_id = item.get_global_id(0);
                    ValueType local = reducer.init();
                    if (global_id < n) {
                        ValueType value = reducer.init();
                        f(begin + global_id, value);
                        reducer.join(local, value);
                    }
                    scratch[local_id] = local;
                    item.barrier(sycl::access::fence_space::local_space);

                    for (size_t active = local_size; active > 1; active = (active + 1) / 2) {
                        const size_t stride = (active + 1) / 2;
                        if (local_id < stride && local_id + stride < active) {
                            reducer.join(scratch[local_id], scratch[local_id + stride]);
                        }
                        item.barrier(sycl::access::fence_space::local_space);
                    }

                    if (local_id == 0) {
                        partials[item.get_group(0)] = scratch[0];
                    }
                });
        }).wait_and_throw();

        ValueType total = reducer.init();
        for (size_t group = 0; group < group_count; ++group) {
            reducer.join(total, partials[group]);
        }
        sycl::free(partials, q);
        result = total;
    } catch (const sycl::exception& error) {
        if (partials != nullptr) {
            sycl::free(partials, sycl_runtime::queue());
        }
        sycl_runtime::abort_on_exception(__FILE__, __LINE__, error);
    }
}

} // namespace LongX
