#pragma once

#include <cassert>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <limits>
#include <type_traits>

#include "longx_exec_space.hpp"

#if defined(LONGX_ENABLE_CUBLAS)
#include <cublas_v2.h>
#include "longx_error.hpp"
#endif

#if defined(LONGX_ENABLE_ROCBLAS)
#include <rocblas/rocblas.h>
#include "longx_error.hpp"
#endif

#if defined(LONGX_ENABLE_HIPBLAS)
#include <hipblas/hipblas.h>
#include "longx_error.hpp"
#endif

#if defined(LONGX_ENABLE_OPENBLAS)
#include <cblas.h>
#endif

#if defined(LONGX_ENABLE_MKL)
#include <mkl.h>
#endif

namespace LongX {
namespace blas {
namespace vendor {

#if defined(LONGX_ENABLE_CUBLAS)
inline void check_cublas(cublasStatus_t status, const char* file, int line) {
    if (status != CUBLAS_STATUS_SUCCESS) {
        std::fprintf(stderr, "LongX cuBLAS error at %s:%d: status=%d\n",
                     file, line, static_cast<int>(status));
        std::abort();
    }
}

#define LONGX_CUBLAS_CHECK(call) \
    ::LongX::blas::vendor::check_cublas((call), __FILE__, __LINE__)

inline cublasHandle_t cublas_handle() {
    static cublasHandle_t handle = [] {
        cublasHandle_t created{};
        LONGX_CUBLAS_CHECK(cublasCreate(&created));
        LONGX_CUBLAS_CHECK(cublasSetPointerMode(created, CUBLAS_POINTER_MODE_HOST));
        return created;
    }();
    return handle;
}

template<typename T>
inline bool cublas_supported_type() {
    return std::is_same<T, float>::value || std::is_same<T, double>::value;
}

inline int checked_blas_size(size_t n) {
    if (n > static_cast<size_t>(std::numeric_limits<int>::max())) {
        std::fprintf(stderr, "LongX cuBLAS vector length exceeds int range: %zu\n", n);
        std::abort();
    }
    return static_cast<int>(n);
}
#endif

#if defined(LONGX_ENABLE_ROCBLAS)
inline void check_rocblas(rocblas_status status, const char* file, int line) {
    if (status != rocblas_status_success) {
        std::fprintf(stderr, "LongX rocBLAS error at %s:%d: status=%d\n",
                     file, line, static_cast<int>(status));
        std::abort();
    }
}

#define LONGX_ROCBLAS_CHECK(call) \
    ::LongX::blas::vendor::check_rocblas((call), __FILE__, __LINE__)

inline rocblas_handle rocblas_handle_instance() {
    static rocblas_handle handle = [] {
        rocblas_handle created{};
        LONGX_ROCBLAS_CHECK(rocblas_create_handle(&created));
        LONGX_ROCBLAS_CHECK(rocblas_set_pointer_mode(created, rocblas_pointer_mode_host));
        return created;
    }();
    return handle;
}

template<typename T>
inline bool rocblas_supported_type() {
    return std::is_same<T, float>::value || std::is_same<T, double>::value;
}

inline rocblas_int checked_rocblas_size(size_t n) {
    if (n > static_cast<size_t>(std::numeric_limits<rocblas_int>::max())) {
        std::fprintf(stderr, "LongX rocBLAS dimension exceeds rocblas_int range: %zu\n", n);
        std::abort();
    }
    return static_cast<rocblas_int>(n);
}
#endif

#if defined(LONGX_ENABLE_HIPBLAS)
inline void check_hipblas(hipblasStatus_t status, const char* file, int line) {
    if (status != HIPBLAS_STATUS_SUCCESS) {
        std::fprintf(stderr, "LongX hipBLAS error at %s:%d: status=%d\n",
                     file, line, static_cast<int>(status));
        std::abort();
    }
}

#define LONGX_HIPBLAS_CHECK(call) \
    ::LongX::blas::vendor::check_hipblas((call), __FILE__, __LINE__)

inline hipblasHandle_t hipblas_handle_instance() {
    static hipblasHandle_t handle = [] {
        hipblasHandle_t created{};
        LONGX_HIPBLAS_CHECK(hipblasCreate(&created));
        LONGX_HIPBLAS_CHECK(hipblasSetPointerMode(created, HIPBLAS_POINTER_MODE_HOST));
        return created;
    }();
    return handle;
}

template<typename T>
inline bool hipblas_supported_type() {
    return std::is_same<T, float>::value || std::is_same<T, double>::value;
}

inline int checked_hipblas_size(size_t n) {
    if (n > static_cast<size_t>(std::numeric_limits<int>::max())) {
        std::fprintf(stderr, "LongX hipBLAS dimension exceeds int range: %zu\n", n);
        std::abort();
    }
    return static_cast<int>(n);
}
#endif

#if defined(LONGX_ENABLE_OPENBLAS)
template<typename T>
inline bool openblas_supported_type() {
    return std::is_same<T, float>::value || std::is_same<T, double>::value;
}

inline int checked_openblas_size(size_t n) {
    if (n > static_cast<size_t>(std::numeric_limits<int>::max())) {
        std::fprintf(stderr, "LongX OpenBLAS vector length exceeds int range: %zu\n", n);
        std::abort();
    }
    return static_cast<int>(n);
}
#endif

#if defined(LONGX_ENABLE_MKL)
template<typename T>
inline bool mkl_supported_type() {
    return std::is_same<T, float>::value || std::is_same<T, double>::value;
}

inline MKL_INT checked_mkl_size(size_t n) {
    if (n > static_cast<size_t>(std::numeric_limits<MKL_INT>::max())) {
        std::fprintf(stderr, "LongX MKL vector length exceeds MKL_INT range: %zu\n", n);
        std::abort();
    }
    return static_cast<MKL_INT>(n);
}
#endif

inline bool requested() {
#if defined(LONGX_ENABLE_CUBLAS) || defined(LONGX_ENABLE_ROCBLAS) || \
    defined(LONGX_ENABLE_HIPBLAS) || defined(LONGX_ENABLE_MKL) || \
    defined(LONGX_ENABLE_OPENBLAS)
    return true;
#else
    return false;
#endif
}

inline const char* requested_backend_name() {
#if defined(LONGX_ENABLE_CUBLAS)
    return "cuBLAS";
#elif defined(LONGX_ENABLE_ROCBLAS)
    return "rocBLAS";
#elif defined(LONGX_ENABLE_HIPBLAS)
    return "hipBLAS";
#elif defined(LONGX_ENABLE_MKL)
    return "MKL";
#elif defined(LONGX_ENABLE_OPENBLAS)
    return "OpenBLAS";
#else
    return "none";
#endif
}

inline bool available() {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    return true;
#elif defined(LONGX_ENABLE_MKL) && \
      (defined(LONGX_ENABLE_OPENMP) || !defined(LONGX_ENABLE_CUDA))
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS) && \
      (defined(LONGX_ENABLE_OPENMP) || !defined(LONGX_ENABLE_CUDA))
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) || defined(LONGX_ENABLE_HIPBLAS)
    return false;
#else
    return false;
#endif
}

inline const char* backend_name() {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    return "cuBLAS";
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    return "rocBLAS";
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    return "hipBLAS";
#elif defined(LONGX_ENABLE_MKL) && \
      (defined(LONGX_ENABLE_OPENMP) || !defined(LONGX_ENABLE_CUDA))
    return "MKL";
#elif defined(LONGX_ENABLE_OPENBLAS) && \
      (defined(LONGX_ENABLE_OPENMP) || !defined(LONGX_ENABLE_CUDA))
    return "OpenBLAS";
#elif defined(LONGX_ENABLE_ROCBLAS)
    return "rocBLAS dispatch not implemented";
#elif defined(LONGX_ENABLE_HIPBLAS)
    return "hipBLAS dispatch not implemented";
#else
    return "no vendor BLAS";
#endif
}

inline const char* dispatch_status() {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    return "implemented";
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    return "implemented";
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    return "implemented";
#elif defined(LONGX_ENABLE_MKL) && \
      (defined(LONGX_ENABLE_OPENMP) || !defined(LONGX_ENABLE_CUDA))
    return "implemented";
#elif defined(LONGX_ENABLE_OPENBLAS) && \
      (defined(LONGX_ENABLE_OPENMP) || !defined(LONGX_ENABLE_CUDA))
    return "implemented";
#elif defined(LONGX_ENABLE_ROCBLAS) || defined(LONGX_ENABLE_HIPBLAS)
    return "planned";
#else
    return "fallback-only";
#endif
}

template<typename ExecSpace, typename ViewType>
inline bool can_use_cublas_view(const ViewType& x) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    using ValueType = typename ViewType::value_type;
    using MemorySpace = typename ViewType::memory_space;
    return std::is_same<ExecSpace, Cuda>::value &&
           std::is_same<MemorySpace, CudaSpace>::value &&
           cublas_supported_type<ValueType>() &&
           x.extent() <= static_cast<size_t>(std::numeric_limits<int>::max());
#else
    (void)x;
    return false;
#endif
}

template<typename ExecSpace, typename ViewType>
inline bool can_use_rocblas_view(const ViewType& x) {
#if defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    using ValueType = typename ViewType::value_type;
    using MemorySpace = typename ViewType::memory_space;
    return std::is_same<ExecSpace, Hip>::value &&
           std::is_same<MemorySpace, HipSpace>::value &&
           rocblas_supported_type<ValueType>() &&
           x.extent() <= static_cast<size_t>(std::numeric_limits<rocblas_int>::max());
#else
    (void)x;
    return false;
#endif
}

template<typename ExecSpace, typename ViewType>
inline bool can_use_hipblas_view(const ViewType& x) {
#if defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    using ValueType = typename ViewType::value_type;
    using MemorySpace = typename ViewType::memory_space;
    return std::is_same<ExecSpace, Hip>::value &&
           std::is_same<MemorySpace, HipSpace>::value &&
           hipblas_supported_type<ValueType>() &&
           x.extent() <= static_cast<size_t>(std::numeric_limits<int>::max());
#else
    (void)x;
    return false;
#endif
}

template<typename ExecSpace, typename SrcView, typename DstView>
inline bool can_use_cublas_views(const SrcView& x, const DstView& y) {
    return can_use_cublas_view<ExecSpace>(x) &&
           can_use_cublas_view<ExecSpace>(y) &&
           x.extent() == y.extent() &&
           std::is_same<typename SrcView::value_type, typename DstView::value_type>::value;
}

template<typename ExecSpace, typename ViewType>
inline bool can_use_mkl_view(const ViewType& x) {
#if defined(LONGX_ENABLE_MKL)
    using ValueType = typename ViewType::value_type;
    using MemorySpace = typename ViewType::memory_space;
    return (std::is_same<ExecSpace, Serial>::value || std::is_same<ExecSpace, OpenMP>::value) &&
           (std::is_same<MemorySpace, HostSpace>::value || std::is_same<MemorySpace, OpenMPSpace>::value) &&
           mkl_supported_type<ValueType>() &&
           x.extent() <= static_cast<size_t>(std::numeric_limits<MKL_INT>::max());
#else
    (void)x;
    return false;
#endif
}

template<typename ExecSpace, typename SrcView, typename DstView>
inline bool can_use_mkl_views(const SrcView& x, const DstView& y) {
    return can_use_mkl_view<ExecSpace>(x) &&
           can_use_mkl_view<ExecSpace>(y) &&
           x.extent() == y.extent() &&
           std::is_same<typename SrcView::value_type, typename DstView::value_type>::value;
}

template<typename ExecSpace, typename ViewType>
inline bool can_use_openblas_view(const ViewType& x) {
#if defined(LONGX_ENABLE_OPENBLAS)
    using ValueType = typename ViewType::value_type;
    using MemorySpace = typename ViewType::memory_space;
    return (std::is_same<ExecSpace, Serial>::value || std::is_same<ExecSpace, OpenMP>::value) &&
           (std::is_same<MemorySpace, HostSpace>::value || std::is_same<MemorySpace, OpenMPSpace>::value) &&
           openblas_supported_type<ValueType>() &&
           x.extent() <= static_cast<size_t>(std::numeric_limits<int>::max());
#else
    (void)x;
    return false;
#endif
}

template<typename ExecSpace, typename SrcView, typename DstView>
inline bool can_use_openblas_views(const SrcView& x, const DstView& y) {
    return can_use_openblas_view<ExecSpace>(x) &&
           can_use_openblas_view<ExecSpace>(y) &&
           x.extent() == y.extent() &&
           std::is_same<typename SrcView::value_type, typename DstView::value_type>::value;
}

template<typename ExecSpace, typename SrcView, typename DstView>
inline bool can_use_rocblas_views(const SrcView& x, const DstView& y) {
    return can_use_rocblas_view<ExecSpace>(x) &&
           can_use_rocblas_view<ExecSpace>(y) &&
           x.extent() == y.extent() &&
           std::is_same<typename SrcView::value_type, typename DstView::value_type>::value;
}

template<typename ExecSpace, typename SrcView, typename DstView>
inline bool can_use_hipblas_views(const SrcView& x, const DstView& y) {
    return can_use_hipblas_view<ExecSpace>(x) &&
           can_use_hipblas_view<ExecSpace>(y) &&
           x.extent() == y.extent() &&
           std::is_same<typename SrcView::value_type, typename DstView::value_type>::value;
}

template<typename AView, typename XView, typename YView>
inline bool same_value_type_gemv() {
    return std::is_same<typename AView::value_type, typename XView::value_type>::value &&
           std::is_same<typename AView::value_type, typename YView::value_type>::value;
}

template<typename AView, typename BView, typename CView>
inline bool same_value_type_gemm() {
    return std::is_same<typename AView::value_type, typename BView::value_type>::value &&
           std::is_same<typename AView::value_type, typename CView::value_type>::value;
}

template<typename ExecSpace, typename MatrixView, typename XView, typename YView>
inline bool can_use_cublas_gemv(const MatrixView& a, const XView& x, const YView& y) {
    return can_use_cublas_view<ExecSpace>(a) &&
           can_use_cublas_view<ExecSpace>(x) &&
           can_use_cublas_view<ExecSpace>(y) &&
           same_value_type_gemv<MatrixView, XView, YView>() &&
           a.extent1() == x.extent() &&
           a.extent0() == y.extent();
}

template<typename ExecSpace, typename MatrixView, typename XView, typename YView>
inline bool can_use_rocblas_gemv(const MatrixView& a, const XView& x, const YView& y) {
    return can_use_rocblas_view<ExecSpace>(a) &&
           can_use_rocblas_view<ExecSpace>(x) &&
           can_use_rocblas_view<ExecSpace>(y) &&
           same_value_type_gemv<MatrixView, XView, YView>() &&
           a.extent1() == x.extent() &&
           a.extent0() == y.extent();
}

template<typename ExecSpace, typename MatrixView, typename XView, typename YView>
inline bool can_use_hipblas_gemv(const MatrixView& a, const XView& x, const YView& y) {
    return can_use_hipblas_view<ExecSpace>(a) &&
           can_use_hipblas_view<ExecSpace>(x) &&
           can_use_hipblas_view<ExecSpace>(y) &&
           same_value_type_gemv<MatrixView, XView, YView>() &&
           a.extent1() == x.extent() &&
           a.extent0() == y.extent();
}

template<typename ExecSpace, typename MatrixView, typename XView, typename YView>
inline bool can_use_mkl_gemv(const MatrixView& a, const XView& x, const YView& y) {
    return can_use_mkl_view<ExecSpace>(a) &&
           can_use_mkl_view<ExecSpace>(x) &&
           can_use_mkl_view<ExecSpace>(y) &&
           same_value_type_gemv<MatrixView, XView, YView>() &&
           a.extent1() == x.extent() &&
           a.extent0() == y.extent();
}

template<typename ExecSpace, typename MatrixView, typename XView, typename YView>
inline bool can_use_openblas_gemv(const MatrixView& a, const XView& x, const YView& y) {
    return can_use_openblas_view<ExecSpace>(a) &&
           can_use_openblas_view<ExecSpace>(x) &&
           can_use_openblas_view<ExecSpace>(y) &&
           same_value_type_gemv<MatrixView, XView, YView>() &&
           a.extent1() == x.extent() &&
           a.extent0() == y.extent();
}

template<typename ExecSpace, typename AView, typename BView, typename CView>
inline bool can_use_cublas_gemm(const AView& a, const BView& b, const CView& c) {
    return can_use_cublas_view<ExecSpace>(a) &&
           can_use_cublas_view<ExecSpace>(b) &&
           can_use_cublas_view<ExecSpace>(c) &&
           same_value_type_gemm<AView, BView, CView>() &&
           a.extent1() == b.extent0() &&
           a.extent0() == c.extent0() &&
           b.extent1() == c.extent1();
}

template<typename ExecSpace, typename AView, typename BView, typename CView>
inline bool can_use_rocblas_gemm(const AView& a, const BView& b, const CView& c) {
    return can_use_rocblas_view<ExecSpace>(a) &&
           can_use_rocblas_view<ExecSpace>(b) &&
           can_use_rocblas_view<ExecSpace>(c) &&
           same_value_type_gemm<AView, BView, CView>() &&
           a.extent1() == b.extent0() &&
           a.extent0() == c.extent0() &&
           b.extent1() == c.extent1();
}

template<typename ExecSpace, typename AView, typename BView, typename CView>
inline bool can_use_hipblas_gemm(const AView& a, const BView& b, const CView& c) {
    return can_use_hipblas_view<ExecSpace>(a) &&
           can_use_hipblas_view<ExecSpace>(b) &&
           can_use_hipblas_view<ExecSpace>(c) &&
           same_value_type_gemm<AView, BView, CView>() &&
           a.extent1() == b.extent0() &&
           a.extent0() == c.extent0() &&
           b.extent1() == c.extent1();
}

template<typename ExecSpace, typename AView, typename BView, typename CView>
inline bool can_use_mkl_gemm(const AView& a, const BView& b, const CView& c) {
    return can_use_mkl_view<ExecSpace>(a) &&
           can_use_mkl_view<ExecSpace>(b) &&
           can_use_mkl_view<ExecSpace>(c) &&
           same_value_type_gemm<AView, BView, CView>() &&
           a.extent1() == b.extent0() &&
           a.extent0() == c.extent0() &&
           b.extent1() == c.extent1();
}

template<typename ExecSpace, typename AView, typename BView, typename CView>
inline bool can_use_openblas_gemm(const AView& a, const BView& b, const CView& c) {
    return can_use_openblas_view<ExecSpace>(a) &&
           can_use_openblas_view<ExecSpace>(b) &&
           can_use_openblas_view<ExecSpace>(c) &&
           same_value_type_gemm<AView, BView, CView>() &&
           a.extent1() == b.extent0() &&
           a.extent0() == c.extent0() &&
           b.extent1() == c.extent1();
}

template<typename ExecSpace, typename SrcView, typename DstView>
bool copy(const SrcView& x, DstView& y) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    if (!can_use_cublas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename SrcView::value_type;
    const int n = checked_blas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_CUBLAS_CHECK(cublasScopy(cublas_handle(), n, x.data(), 1, y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_CUBLAS_CHECK(cublasDcopy(cublas_handle(), n, x.data(), 1, y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_MKL)
    if (!can_use_mkl_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename SrcView::value_type;
    const MKL_INT n = checked_mkl_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_scopy(n, x.data(), 1, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dcopy(n, x.data(), 1, y.data(), 1);
    }
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_rocblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename SrcView::value_type;
    const rocblas_int n = checked_rocblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_scopy(rocblas_handle_instance(), n, x.data(), 1,
                                          y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_dcopy(rocblas_handle_instance(), n, x.data(), 1,
                                          y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_hipblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename SrcView::value_type;
    const int n = checked_hipblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_HIPBLAS_CHECK(hipblasScopy(hipblas_handle_instance(), n, x.data(), 1,
                                         y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_HIPBLAS_CHECK(hipblasDcopy(hipblas_handle_instance(), n, x.data(), 1,
                                         y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS)
    if (!can_use_openblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename SrcView::value_type;
    const int n = checked_openblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_scopy(n, x.data(), 1, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dcopy(n, x.data(), 1, y.data(), 1);
    }
    return true;
#else
    (void)x;
    (void)y;
    return false;
#endif
}

template<typename ExecSpace, typename Scalar, typename ViewType>
bool scal(Scalar alpha, ViewType& x) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    if (!can_use_cublas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const int n = checked_blas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_CUBLAS_CHECK(cublasSscal(cublas_handle(), n, &a, x.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_CUBLAS_CHECK(cublasDscal(cublas_handle(), n, &a, x.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_MKL)
    if (!can_use_mkl_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const MKL_INT n = checked_mkl_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_sscal(n, a, x.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dscal(n, a, x.data(), 1);
    }
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_rocblas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const rocblas_int n = checked_rocblas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_sscal(rocblas_handle_instance(), n, &a, x.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_dscal(rocblas_handle_instance(), n, &a, x.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_hipblas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const int n = checked_hipblas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_HIPBLAS_CHECK(hipblasSscal(hipblas_handle_instance(), n, &a, x.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_HIPBLAS_CHECK(hipblasDscal(hipblas_handle_instance(), n, &a, x.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS)
    if (!can_use_openblas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const int n = checked_openblas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_sscal(n, a, x.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dscal(n, a, x.data(), 1);
    }
    return true;
#else
    (void)alpha;
    (void)x;
    return false;
#endif
}

template<typename ExecSpace, typename Scalar, typename XView, typename YView>
bool axpy(Scalar alpha, const XView& x, YView& y) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    if (!can_use_cublas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const int n = checked_blas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_CUBLAS_CHECK(cublasSaxpy(cublas_handle(), n, &a, x.data(), 1, y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_CUBLAS_CHECK(cublasDaxpy(cublas_handle(), n, &a, x.data(), 1, y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_MKL)
    if (!can_use_mkl_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const MKL_INT n = checked_mkl_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_saxpy(n, a, x.data(), 1, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_daxpy(n, a, x.data(), 1, y.data(), 1);
    }
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_rocblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const rocblas_int n = checked_rocblas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_saxpy(rocblas_handle_instance(), n, &a, x.data(), 1,
                                          y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_daxpy(rocblas_handle_instance(), n, &a, x.data(), 1,
                                          y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_hipblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const int n = checked_hipblas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_HIPBLAS_CHECK(hipblasSaxpy(hipblas_handle_instance(), n, &a, x.data(), 1,
                                         y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_HIPBLAS_CHECK(hipblasDaxpy(hipblas_handle_instance(), n, &a, x.data(), 1,
                                         y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS)
    if (!can_use_openblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const int n = checked_openblas_size(x.extent());
    const ValueType a = static_cast<ValueType>(alpha);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_saxpy(n, a, x.data(), 1, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_daxpy(n, a, x.data(), 1, y.data(), 1);
    }
    return true;
#else
    (void)alpha;
    (void)x;
    (void)y;
    return false;
#endif
}

template<typename ExecSpace, typename XView, typename YView>
bool dot(const XView& x, const YView& y, typename XView::value_type& result) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    if (!can_use_cublas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const int n = checked_blas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_CUBLAS_CHECK(cublasSdot(cublas_handle(), n, x.data(), 1, y.data(), 1, &result));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_CUBLAS_CHECK(cublasDdot(cublas_handle(), n, x.data(), 1, y.data(), 1, &result));
    }
    return true;
#elif defined(LONGX_ENABLE_MKL)
    if (!can_use_mkl_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const MKL_INT n = checked_mkl_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        result = cblas_sdot(n, x.data(), 1, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        result = cblas_ddot(n, x.data(), 1, y.data(), 1);
    }
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_rocblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const rocblas_int n = checked_rocblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_sdot(rocblas_handle_instance(), n, x.data(), 1,
                                         y.data(), 1, &result));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_ddot(rocblas_handle_instance(), n, x.data(), 1,
                                         y.data(), 1, &result));
    }
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_hipblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const int n = checked_hipblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_HIPBLAS_CHECK(hipblasSdot(hipblas_handle_instance(), n, x.data(), 1,
                                        y.data(), 1, &result));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_HIPBLAS_CHECK(hipblasDdot(hipblas_handle_instance(), n, x.data(), 1,
                                        y.data(), 1, &result));
    }
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS)
    if (!can_use_openblas_views<ExecSpace>(x, y)) {
        return false;
    }
    using ValueType = typename XView::value_type;
    const int n = checked_openblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        result = cblas_sdot(n, x.data(), 1, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        result = cblas_ddot(n, x.data(), 1, y.data(), 1);
    }
    return true;
#else
    (void)x;
    (void)y;
    (void)result;
    return false;
#endif
}

template<typename ExecSpace, typename ViewType>
bool nrm2(const ViewType& x, typename ViewType::value_type& result) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    if (!can_use_cublas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const int n = checked_blas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_CUBLAS_CHECK(cublasSnrm2(cublas_handle(), n, x.data(), 1, &result));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_CUBLAS_CHECK(cublasDnrm2(cublas_handle(), n, x.data(), 1, &result));
    }
    return true;
#elif defined(LONGX_ENABLE_MKL)
    if (!can_use_mkl_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const MKL_INT n = checked_mkl_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        result = cblas_snrm2(n, x.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        result = cblas_dnrm2(n, x.data(), 1);
    }
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_rocblas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const rocblas_int n = checked_rocblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_snrm2(rocblas_handle_instance(), n, x.data(), 1, &result));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_dnrm2(rocblas_handle_instance(), n, x.data(), 1, &result));
    }
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_hipblas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const int n = checked_hipblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_HIPBLAS_CHECK(hipblasSnrm2(hipblas_handle_instance(), n, x.data(), 1, &result));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_HIPBLAS_CHECK(hipblasDnrm2(hipblas_handle_instance(), n, x.data(), 1, &result));
    }
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS)
    if (!can_use_openblas_view<ExecSpace>(x)) {
        return false;
    }
    using ValueType = typename ViewType::value_type;
    const int n = checked_openblas_size(x.extent());
    if constexpr (std::is_same<ValueType, float>::value) {
        result = cblas_snrm2(n, x.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        result = cblas_dnrm2(n, x.data(), 1);
    }
    return true;
#else
    (void)x;
    (void)result;
    return false;
#endif
}

template<typename ExecSpace, typename Scalar, typename MatrixView, typename XView, typename YView>
bool gemv(Scalar alpha, const MatrixView& a, const XView& x, Scalar beta, YView& y) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    if (!can_use_cublas_gemv<ExecSpace>(a, x, y)) {
        return false;
    }
    using ValueType = typename MatrixView::value_type;
    const int rows = checked_blas_size(a.extent0());
    const int cols = checked_blas_size(a.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_CUBLAS_CHECK(cublasSgemv(cublas_handle(), CUBLAS_OP_T, cols, rows,
                                       &alpha_value, a.data(), cols, x.data(), 1,
                                       &beta_value, y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_CUBLAS_CHECK(cublasDgemv(cublas_handle(), CUBLAS_OP_T, cols, rows,
                                       &alpha_value, a.data(), cols, x.data(), 1,
                                       &beta_value, y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_rocblas_gemv<ExecSpace>(a, x, y)) {
        return false;
    }
    using ValueType = typename MatrixView::value_type;
    const rocblas_int rows = checked_rocblas_size(a.extent0());
    const rocblas_int cols = checked_rocblas_size(a.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_sgemv(rocblas_handle_instance(), rocblas_operation_transpose,
                                          cols, rows, &alpha_value, a.data(), cols,
                                          x.data(), 1, &beta_value, y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_dgemv(rocblas_handle_instance(), rocblas_operation_transpose,
                                          cols, rows, &alpha_value, a.data(), cols,
                                          x.data(), 1, &beta_value, y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_hipblas_gemv<ExecSpace>(a, x, y)) {
        return false;
    }
    using ValueType = typename MatrixView::value_type;
    const int rows = checked_hipblas_size(a.extent0());
    const int cols = checked_hipblas_size(a.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_HIPBLAS_CHECK(hipblasSgemv(hipblas_handle_instance(), HIPBLAS_OP_T,
                                         cols, rows, &alpha_value, a.data(), cols,
                                         x.data(), 1, &beta_value, y.data(), 1));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_HIPBLAS_CHECK(hipblasDgemv(hipblas_handle_instance(), HIPBLAS_OP_T,
                                         cols, rows, &alpha_value, a.data(), cols,
                                         x.data(), 1, &beta_value, y.data(), 1));
    }
    return true;
#elif defined(LONGX_ENABLE_MKL)
    if (!can_use_mkl_gemv<ExecSpace>(a, x, y)) {
        return false;
    }
    using ValueType = typename MatrixView::value_type;
    const MKL_INT rows = checked_mkl_size(a.extent0());
    const MKL_INT cols = checked_mkl_size(a.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_sgemv(CblasRowMajor, CblasNoTrans, rows, cols, alpha_value,
                    a.data(), cols, x.data(), 1, beta_value, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dgemv(CblasRowMajor, CblasNoTrans, rows, cols, alpha_value,
                    a.data(), cols, x.data(), 1, beta_value, y.data(), 1);
    }
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS)
    if (!can_use_openblas_gemv<ExecSpace>(a, x, y)) {
        return false;
    }
    using ValueType = typename MatrixView::value_type;
    const int rows = checked_openblas_size(a.extent0());
    const int cols = checked_openblas_size(a.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_sgemv(CblasRowMajor, CblasNoTrans, rows, cols, alpha_value,
                    a.data(), cols, x.data(), 1, beta_value, y.data(), 1);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dgemv(CblasRowMajor, CblasNoTrans, rows, cols, alpha_value,
                    a.data(), cols, x.data(), 1, beta_value, y.data(), 1);
    }
    return true;
#else
    (void)alpha;
    (void)a;
    (void)x;
    (void)beta;
    (void)y;
    return false;
#endif
}

template<typename ExecSpace, typename Scalar, typename AView, typename BView, typename CView>
bool gemm(Scalar alpha, const AView& a, const BView& b, Scalar beta, CView& c) {
#if defined(LONGX_ENABLE_CUBLAS) && defined(LONGX_ENABLE_CUDA)
    if (!can_use_cublas_gemm<ExecSpace>(a, b, c)) {
        return false;
    }
    using ValueType = typename AView::value_type;
    const int rows = checked_blas_size(a.extent0());
    const int inner = checked_blas_size(a.extent1());
    const int cols = checked_blas_size(b.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_CUBLAS_CHECK(cublasSgemm(cublas_handle(), CUBLAS_OP_N, CUBLAS_OP_N,
                                       cols, rows, inner, &alpha_value,
                                       b.data(), cols, a.data(), inner,
                                       &beta_value, c.data(), cols));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_CUBLAS_CHECK(cublasDgemm(cublas_handle(), CUBLAS_OP_N, CUBLAS_OP_N,
                                       cols, rows, inner, &alpha_value,
                                       b.data(), cols, a.data(), inner,
                                       &beta_value, c.data(), cols));
    }
    return true;
#elif defined(LONGX_ENABLE_ROCBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_rocblas_gemm<ExecSpace>(a, b, c)) {
        return false;
    }
    using ValueType = typename AView::value_type;
    const rocblas_int rows = checked_rocblas_size(a.extent0());
    const rocblas_int inner = checked_rocblas_size(a.extent1());
    const rocblas_int cols = checked_rocblas_size(b.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_sgemm(rocblas_handle_instance(), rocblas_operation_none,
                                          rocblas_operation_none, cols, rows, inner,
                                          &alpha_value, b.data(), cols, a.data(), inner,
                                          &beta_value, c.data(), cols));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_ROCBLAS_CHECK(rocblas_dgemm(rocblas_handle_instance(), rocblas_operation_none,
                                          rocblas_operation_none, cols, rows, inner,
                                          &alpha_value, b.data(), cols, a.data(), inner,
                                          &beta_value, c.data(), cols));
    }
    return true;
#elif defined(LONGX_ENABLE_HIPBLAS) && defined(LONGX_ENABLE_HIP)
    if (!can_use_hipblas_gemm<ExecSpace>(a, b, c)) {
        return false;
    }
    using ValueType = typename AView::value_type;
    const int rows = checked_hipblas_size(a.extent0());
    const int inner = checked_hipblas_size(a.extent1());
    const int cols = checked_hipblas_size(b.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        LONGX_HIPBLAS_CHECK(hipblasSgemm(hipblas_handle_instance(), HIPBLAS_OP_N,
                                         HIPBLAS_OP_N, cols, rows, inner,
                                         &alpha_value, b.data(), cols, a.data(), inner,
                                         &beta_value, c.data(), cols));
    } else if constexpr (std::is_same<ValueType, double>::value) {
        LONGX_HIPBLAS_CHECK(hipblasDgemm(hipblas_handle_instance(), HIPBLAS_OP_N,
                                         HIPBLAS_OP_N, cols, rows, inner,
                                         &alpha_value, b.data(), cols, a.data(), inner,
                                         &beta_value, c.data(), cols));
    }
    return true;
#elif defined(LONGX_ENABLE_MKL)
    if (!can_use_mkl_gemm<ExecSpace>(a, b, c)) {
        return false;
    }
    using ValueType = typename AView::value_type;
    const MKL_INT rows = checked_mkl_size(a.extent0());
    const MKL_INT inner = checked_mkl_size(a.extent1());
    const MKL_INT cols = checked_mkl_size(b.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, rows, cols, inner,
                    alpha_value, a.data(), inner, b.data(), cols, beta_value, c.data(), cols);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, rows, cols, inner,
                    alpha_value, a.data(), inner, b.data(), cols, beta_value, c.data(), cols);
    }
    return true;
#elif defined(LONGX_ENABLE_OPENBLAS)
    if (!can_use_openblas_gemm<ExecSpace>(a, b, c)) {
        return false;
    }
    using ValueType = typename AView::value_type;
    const int rows = checked_openblas_size(a.extent0());
    const int inner = checked_openblas_size(a.extent1());
    const int cols = checked_openblas_size(b.extent1());
    const ValueType alpha_value = static_cast<ValueType>(alpha);
    const ValueType beta_value = static_cast<ValueType>(beta);
    if constexpr (std::is_same<ValueType, float>::value) {
        cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, rows, cols, inner,
                    alpha_value, a.data(), inner, b.data(), cols, beta_value, c.data(), cols);
    } else if constexpr (std::is_same<ValueType, double>::value) {
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, rows, cols, inner,
                    alpha_value, a.data(), inner, b.data(), cols, beta_value, c.data(), cols);
    }
    return true;
#else
    (void)alpha;
    (void)a;
    (void)b;
    (void)beta;
    (void)c;
    return false;
#endif
}

} // namespace vendor
} // namespace blas
} // namespace LongX
