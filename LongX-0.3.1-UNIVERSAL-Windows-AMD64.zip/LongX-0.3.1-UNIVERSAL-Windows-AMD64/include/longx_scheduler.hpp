#pragma once

#include <algorithm>
#include <chrono>
#include <cstddef>
#include <exception>
#include <functional>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include "longx_backend_selector.hpp"
#include "longx_dsl.hpp"

namespace LongX {

enum class TaskPriority {
    Low = 0,
    Normal = 1,
    High = 2,
    Critical = 3
};

struct Task {
    size_t id = 0;
    std::string name;
    TaskPriority priority = TaskPriority::Normal;
    std::string preferred_backend;
    size_t memory_estimate_bytes = 0;
    std::vector<size_t> dependencies;
    std::map<std::string, std::string> metadata;
    std::function<void()> action;

    bool executable() const {
        return static_cast<bool>(action);
    }
};

struct TaskBuilder {
    Task task;

    explicit TaskBuilder(std::string name) {
        task.name = std::move(name);
    }

    TaskBuilder& priority(TaskPriority value) {
        task.priority = value;
        return *this;
    }

    TaskBuilder& preferred_backend(std::string backend) {
        task.preferred_backend = std::move(backend);
        return *this;
    }

    TaskBuilder& memory_estimate(size_t bytes) {
        task.memory_estimate_bytes = bytes;
        return *this;
    }

    TaskBuilder& depends_on(size_t id) {
        task.dependencies.push_back(id);
        return *this;
    }

    TaskBuilder& attribute(std::string key, std::string value) {
        task.metadata[std::move(key)] = std::move(value);
        return *this;
    }

    TaskBuilder& action(std::function<void()> fn) {
        task.action = std::move(fn);
        return *this;
    }

    Task build() const {
        return task;
    }
};

inline TaskBuilder task(std::string name) {
    return TaskBuilder(std::move(name));
}

struct TaskDiagnostic {
    size_t task_id = 0;
    std::string message;
};

struct ScheduleDecision {
    size_t task_id = 0;
    std::string task_name;
    TaskPriority priority = TaskPriority::Normal;
    std::string selected_backend;
    std::string preferred_backend;
    size_t memory_estimate_bytes = 0;
    std::string reason;
};

struct TaskProfile {
    std::string task_name;
    std::string backend;
    double elapsed_seconds = 0.0;
    size_t samples = 1;
};

struct TaskExecutionRecord {
    ScheduleDecision decision;
    bool action_present = false;
    bool succeeded = true;
    double elapsed_seconds = 0.0;
    std::string error;
};

struct SchedulePlan {
    std::vector<ScheduleDecision> decisions;
    std::vector<TaskDiagnostic> diagnostics;

    bool ok() const {
        return diagnostics.empty();
    }

    std::string to_text() const {
        std::ostringstream out;
        out << "LongX resource schedule plan\n";
        out << "tasks=" << decisions.size() << "\n";
        if (!diagnostics.empty()) {
            out << "diagnostics:\n";
            for (const auto& diagnostic : diagnostics) {
                out << "- task=" << diagnostic.task_id << " " << diagnostic.message << "\n";
            }
        }
        out << "decisions:\n";
        for (const auto& decision : decisions) {
            out << "- [" << decision.task_id << "] " << decision.task_name
                << " backend=" << decision.selected_backend
                << " priority=" << static_cast<int>(decision.priority)
                << " memory=" << decision.memory_estimate_bytes;
            if (!decision.preferred_backend.empty()) {
                out << " preferred=" << decision.preferred_backend;
            }
            out << " reason=" << decision.reason << "\n";
        }
        return out.str();
    }
};

struct ExecutionReport {
    SchedulePlan plan;
    std::vector<TaskExecutionRecord> records;

    bool ok() const {
        if (!plan.ok()) {
            return false;
        }
        for (const auto& record : records) {
            if (!record.succeeded) {
                return false;
            }
        }
        return true;
    }

    size_t executed_count() const {
        size_t count = 0;
        for (const auto& record : records) {
            if (record.action_present && record.succeeded) {
                ++count;
            }
        }
        return count;
    }

    std::vector<TaskProfile> profiles() const {
        std::vector<TaskProfile> result;
        for (const auto& record : records) {
            if (record.action_present && record.succeeded) {
                result.push_back(TaskProfile{
                    record.decision.task_name,
                    record.decision.selected_backend,
                    record.elapsed_seconds,
                    1});
            }
        }
        return result;
    }

    std::string to_text() const {
        std::ostringstream out;
        out << plan.to_text();
        out << "execution profile\n";
        out << "executed=" << executed_count() << "\n";
        for (const auto& record : records) {
            out << "- [" << record.decision.task_id << "] " << record.decision.task_name
                << " backend=" << record.decision.selected_backend
                << " action=" << (record.action_present ? "yes" : "no")
                << " ok=" << (record.succeeded ? "yes" : "no")
                << " seconds=" << record.elapsed_seconds;
            if (!record.error.empty()) {
                out << " error=" << record.error;
            }
            out << "\n";
        }
        return out.str();
    }
};

class TaskGraph {
public:
    size_t add(Task task) {
        task.id = tasks_.size();
        tasks_.push_back(std::move(task));
        return tasks_.back().id;
    }

    size_t add(const TaskBuilder& builder) {
        return add(builder.build());
    }

    void add_dependency(size_t before, size_t after) {
        if (before >= tasks_.size() || after >= tasks_.size()) {
            throw std::out_of_range("LongX::TaskGraph dependency id is out of range");
        }
        if (before == after) {
            throw std::invalid_argument("LongX::TaskGraph dependency cannot target itself");
        }
        auto& deps = tasks_[after].dependencies;
        if (std::find(deps.begin(), deps.end(), before) == deps.end()) {
            deps.push_back(before);
        }
    }

    const Task& node(size_t id) const {
        if (id >= tasks_.size()) {
            throw std::out_of_range("LongX::TaskGraph task id is out of range");
        }
        return tasks_[id];
    }

    size_t size() const {
        return tasks_.size();
    }

    bool empty() const {
        return tasks_.empty();
    }

    const std::vector<Task>& tasks() const {
        return tasks_;
    }

    std::vector<TaskDiagnostic> validate() const {
        std::vector<TaskDiagnostic> diagnostics;
        for (size_t i = 0; i < tasks_.size(); ++i) {
            const auto& current = tasks_[i];
            if (current.id != i) {
                diagnostics.push_back(TaskDiagnostic{i, "task id does not match graph position"});
            }
            if (current.name.empty()) {
                diagnostics.push_back(TaskDiagnostic{i, "task name is empty"});
            }
            for (const size_t dependency : current.dependencies) {
                if (dependency >= tasks_.size()) {
                    diagnostics.push_back(TaskDiagnostic{i, "dependency id is out of range"});
                } else if (dependency == i) {
                    diagnostics.push_back(TaskDiagnostic{i, "task depends on itself"});
                }
            }
        }
        if (contains_cycle()) {
            diagnostics.push_back(TaskDiagnostic{tasks_.size(), "dependency graph contains a cycle"});
        }
        return diagnostics;
    }

    std::vector<size_t> topological_order() const {
        const auto diagnostics = validate();
        if (!diagnostics.empty()) {
            throw std::runtime_error("LongX::TaskGraph is not valid");
        }
        return topological_order_unchecked();
    }

    size_t execute() const {
        size_t executed = 0;
        for (const size_t id : topological_order()) {
            if (tasks_[id].action) {
                tasks_[id].action();
                ++executed;
            }
        }
        return executed;
    }

private:
    bool contains_cycle() const {
        std::vector<int> state(tasks_.size(), 0);
        for (size_t i = 0; i < tasks_.size(); ++i) {
            if (visit_cycle(i, state)) {
                return true;
            }
        }
        return false;
    }

    bool visit_cycle(size_t id, std::vector<int>& state) const {
        if (state[id] == 1) {
            return true;
        }
        if (state[id] == 2) {
            return false;
        }
        state[id] = 1;
        for (const size_t dependency : tasks_[id].dependencies) {
            if (dependency < tasks_.size() && visit_cycle(dependency, state)) {
                return true;
            }
        }
        state[id] = 2;
        return false;
    }

    std::vector<size_t> topological_order_unchecked() const {
        std::vector<size_t> order;
        std::vector<bool> emitted(tasks_.size(), false);
        while (order.size() < tasks_.size()) {
            bool progressed = false;
            size_t best = tasks_.size();
            for (size_t i = 0; i < tasks_.size(); ++i) {
                if (emitted[i]) {
                    continue;
                }
                bool ready = true;
                for (const size_t dependency : tasks_[i].dependencies) {
                    if (!emitted[dependency]) {
                        ready = false;
                        break;
                    }
                }
                if (ready && (best == tasks_.size() || compare_ready(tasks_[i], tasks_[best]))) {
                    best = i;
                }
            }
            if (best != tasks_.size()) {
                emitted[best] = true;
                order.push_back(best);
                progressed = true;
            }
            if (!progressed) {
                throw std::runtime_error("LongX::TaskGraph topological ordering stalled");
            }
        }
        return order;
    }

    static bool compare_ready(const Task& lhs, const Task& rhs) {
        if (lhs.priority != rhs.priority) {
            return static_cast<int>(lhs.priority) > static_cast<int>(rhs.priority);
        }
        return lhs.id < rhs.id;
    }

    std::vector<Task> tasks_;
};

struct SchedulerOptions {
    std::vector<std::string> candidate_backends = {"CUDA", "SYCL", "OPENCL", "OPENGL", "OPENMP", "SERIAL"};
    double memory_reserve_ratio = 0.10;
    std::vector<TaskProfile> profiles;
};

class Scheduler {
public:
    explicit Scheduler(SchedulerOptions options = SchedulerOptions{})
    : options_(std::move(options)) {}

    SchedulePlan schedule(const TaskGraph& graph) const {
        SchedulePlan plan;
        plan.diagnostics = graph.validate();
        if (!plan.diagnostics.empty()) {
            return plan;
        }
        for (const size_t id : graph.topological_order()) {
            plan.decisions.push_back(decide(graph.node(id)));
        }
        return plan;
    }

    size_t execute(const TaskGraph& graph) const {
        const ExecutionReport report = execute_with_profile(graph);
        if (!report.ok()) {
            throw std::runtime_error("LongX::Scheduler task action failed");
        }
        return report.executed_count();
    }

    ExecutionReport execute_with_profile(const TaskGraph& graph) const {
        const SchedulePlan plan = schedule(graph);
        if (!plan.ok()) {
            throw std::runtime_error("LongX::Scheduler cannot execute an invalid TaskGraph");
        }
        ExecutionReport report;
        report.plan = plan;
        for (const auto& decision : plan.decisions) {
            const Task& current = graph.node(decision.task_id);
            TaskExecutionRecord record;
            record.decision = decision;
            record.action_present = static_cast<bool>(current.action);
            if (current.action) {
                const auto start = std::chrono::steady_clock::now();
                try {
                    current.action();
                } catch (const std::exception& error) {
                    record.succeeded = false;
                    record.error = error.what();
                } catch (...) {
                    record.succeeded = false;
                    record.error = "unknown exception";
                }
                const auto stop = std::chrono::steady_clock::now();
                record.elapsed_seconds = std::chrono::duration<double>(stop - start).count();
                if (!record.succeeded) {
                    report.records.push_back(std::move(record));
                    return report;
                }
            }
            report.records.push_back(std::move(record));
        }
        return report;
    }

private:
    ScheduleDecision decide(const Task& task) const {
        ScheduleDecision decision;
        decision.task_id = task.id;
        decision.task_name = task.name;
        decision.priority = task.priority;
        decision.preferred_backend = task.preferred_backend;
        decision.memory_estimate_bytes = task.memory_estimate_bytes;

        if (!task.preferred_backend.empty()) {
            if (backend_available(task.preferred_backend.c_str()) &&
                memory_fits(task.preferred_backend, task.memory_estimate_bytes)) {
                decision.selected_backend = task.preferred_backend;
                decision.reason = "preferred backend is available and memory estimate fits";
                return decision;
            }
            decision.reason = "preferred backend unavailable or memory estimate exceeds device budget";
        }

        const std::string profiled = fastest_profiled_backend(task);
        if (!profiled.empty()) {
            decision.selected_backend = profiled;
            if (decision.reason.empty()) {
                decision.reason = "profiling feedback selected fastest historical backend";
            } else {
                decision.reason += "; profiling feedback selected fastest historical backend";
            }
            return decision;
        }

        const std::string recommended = recommended_backend();
        if (backend_allowed(recommended) && backend_available(recommended.c_str()) &&
            memory_fits(recommended, task.memory_estimate_bytes)) {
            decision.selected_backend = recommended;
            if (decision.reason.empty()) {
                decision.reason = "runtime recommended backend selected";
            } else {
                decision.reason += "; runtime recommended backend selected";
            }
            return decision;
        }

        for (const auto& backend : options_.candidate_backends) {
            if (backend_available(backend.c_str()) && memory_fits(backend, task.memory_estimate_bytes)) {
                decision.selected_backend = backend;
                if (decision.reason.empty()) {
                    decision.reason = "first available candidate backend selected";
                } else {
                    decision.reason += "; first available candidate backend selected";
                }
                return decision;
            }
        }

        decision.selected_backend = "SERIAL";
        if (decision.reason.empty()) {
            decision.reason = "fallback backend selected";
        } else {
            decision.reason += "; fallback backend selected";
        }
        return decision;
    }

    std::string fastest_profiled_backend(const Task& task) const {
        double best_seconds = 0.0;
        size_t best_samples = 0;
        std::string best_backend;
        for (const auto& profile : options_.profiles) {
            if (profile.task_name != task.name || profile.backend.empty() ||
                profile.elapsed_seconds <= 0.0 || profile.samples == 0) {
                continue;
            }
            if (!backend_allowed(profile.backend) ||
                !backend_available(profile.backend.c_str()) ||
                !memory_fits(profile.backend, task.memory_estimate_bytes)) {
                continue;
            }
            const double average_seconds = profile.elapsed_seconds / static_cast<double>(profile.samples);
            if (best_backend.empty() ||
                average_seconds < best_seconds ||
                (average_seconds == best_seconds && profile.samples > best_samples)) {
                best_backend = profile.backend;
                best_seconds = average_seconds;
                best_samples = profile.samples;
            }
        }
        return best_backend;
    }

    bool backend_allowed(const std::string& backend) const {
        return std::find(options_.candidate_backends.begin(), options_.candidate_backends.end(), backend) !=
            options_.candidate_backends.end();
    }

    bool memory_fits(const std::string& backend, size_t bytes) const {
        if (bytes == 0 || backend == "SERIAL" || backend == "OPENMP" ||
            backend == "OPENCL" || backend == "OPENGL") {
            return true;
        }
        const MemoryInfo memory = memory_info();
        if (memory.host_accessible || memory.free_bytes == 0) {
            return true;
        }
        const double usable = static_cast<double>(memory.free_bytes) * (1.0 - options_.memory_reserve_ratio);
        return static_cast<double>(bytes) <= usable;
    }

    SchedulerOptions options_;
};

inline TaskPriority parse_task_priority(const std::string& value, TaskPriority fallback = TaskPriority::Normal) {
    if (value == "critical" || value == "CRITICAL" || value == "3") {
        return TaskPriority::Critical;
    }
    if (value == "high" || value == "HIGH" || value == "2") {
        return TaskPriority::High;
    }
    if (value == "normal" || value == "NORMAL" || value == "1") {
        return TaskPriority::Normal;
    }
    if (value == "low" || value == "LOW" || value == "0") {
        return TaskPriority::Low;
    }
    return fallback;
}

inline size_t parse_size_or_zero(const std::string& value) {
    if (value.empty()) {
        return 0;
    }
    size_t parsed = 0;
    for (const char ch : value) {
        if (ch < '0' || ch > '9') {
            return 0;
        }
        parsed = parsed * 10 + static_cast<size_t>(ch - '0');
    }
    return parsed;
}

inline TaskGraph make_task_graph(const dsl::OperationGraph& graph) {
    TaskGraph tasks;
    for (const auto& node : graph.nodes()) {
        Task converted;
        converted.name = node.kernel.name;
        converted.preferred_backend = node.kernel.backend_hint;
        converted.dependencies = node.dependencies;
        converted.action = node.action;
        for (const auto& attribute : node.attributes) {
            converted.metadata[attribute.key] = attribute.value;
            if (attribute.key == "priority") {
                converted.priority = parse_task_priority(attribute.value);
            } else if (attribute.key == "memory_estimate" || attribute.key == "memory_bytes") {
                converted.memory_estimate_bytes = parse_size_or_zero(attribute.value);
            } else if (attribute.key == "preferred_backend" && converted.preferred_backend.empty()) {
                converted.preferred_backend = attribute.value;
            }
        }
        tasks.add(std::move(converted));
    }
    return tasks;
}

inline SchedulePlan schedule(const TaskGraph& graph, SchedulerOptions options = SchedulerOptions{}) {
    return Scheduler(std::move(options)).schedule(graph);
}

inline SchedulePlan schedule(const dsl::OperationGraph& graph, SchedulerOptions options = SchedulerOptions{}) {
    return Scheduler(std::move(options)).schedule(make_task_graph(graph));
}

inline ExecutionReport execute_with_profile(const TaskGraph& graph, SchedulerOptions options = SchedulerOptions{}) {
    return Scheduler(std::move(options)).execute_with_profile(graph);
}

inline ExecutionReport execute_with_profile(const dsl::OperationGraph& graph, SchedulerOptions options = SchedulerOptions{}) {
    return Scheduler(std::move(options)).execute_with_profile(make_task_graph(graph));
}

} // namespace LongX
