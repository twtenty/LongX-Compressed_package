
#pragma once

namespace LongX {
	
	struct HostSpace {};
	struct CudaSpace {};
	struct HipSpace {};
	struct MusaSpace {};
	struct SyclSpace {};
	struct OpenCLSpace {};
	struct OpenGLSpace {};
	struct OpenMPSpace {};

	using OPENMPSpace = OpenMPSpace;
} // namespace LongX

