#pragma once

#include <cstddef>
#include <cstring>
#include <string>

#include "longx_error.hpp"
#include "longx_runtime.hpp"

namespace LongX {

struct BackendInfo {
    std::string active_backend;
    std::string recommended_backend;
    int device_count;
    MemoryInfo memory;
    bool accelerator_available;
};

inline bool backend_name_equals(const char* lhs, const char* rhs) {
    return std::strcmp(lhs, rhs) == 0;
}

inline bool backend_available(const char* name) {
    if (name == nullptr || name[0] == '\0') {
        return false;
    }

    if (backend_name_equals(name, "SERIAL")) {
        return true;
    }

#if defined(LONGX_ENABLE_OPENMP)
    if (backend_name_equals(name, "OPENMP")) {
        return true;
    }
#endif

#if defined(LONGX_ENABLE_CUDA)
    if (backend_name_equals(name, "CUDA")) {
        int count = 0;
        cudaError_t status = cudaGetDeviceCount(&count);
        return status == cudaSuccess && count > 0;
    }
#endif

#if defined(LONGX_ENABLE_HIP)
    if (backend_name_equals(name, "HIP") || backend_name_equals(name, "HYGON_DCU")) {
        int count = 0;
        hipError_t status = hipGetDeviceCount(&count);
        return status == hipSuccess && count > 0;
    }
#endif

#if defined(LONGX_ENABLE_MUSA)
    if (backend_name_equals(name, "MUSA")) {
        int count = 0;
        musaError_t status = musaGetDeviceCount(&count);
        return status == musaSuccess && count > 0;
    }
#endif

#if defined(LONGX_ENABLE_SYCL)
    if (backend_name_equals(name, "SYCL")) {
        return sycl_runtime::available();
    }
#endif

#if defined(LONGX_ENABLE_OPENCL)
    if (backend_name_equals(name, "OPENCL")) {
        return true;
    }
#endif

#if defined(LONGX_ENABLE_OPENGL)
    if (backend_name_equals(name, "OPENGL")) {
        return true;
    }
#endif

#if defined(LONGX_ENABLE_MPI)
    if (backend_name_equals(name, "MPI")) {
        return mpi::available();
    }
#endif

#if defined(LONGX_ENABLE_TBB)
    if (backend_name_equals(name, "TBB")) {
        return true;
    }
#endif

    return false;
}

inline const char* recommended_backend() {
#if defined(LONGX_ENABLE_CUDA)
    if (backend_available("CUDA")) {
        return "CUDA";
    }
#elif defined(LONGX_ENABLE_MUSA)
    if (backend_available("MUSA")) {
        return "MUSA";
    }
#elif defined(LONGX_ENABLE_SYCL)
    if (backend_available("SYCL")) {
        return "SYCL";
    }
#elif defined(LONGX_ENABLE_OPENCL)
    if (backend_available("OPENCL")) {
        return "OPENCL";
    }
#elif defined(LONGX_ENABLE_OPENGL)
    if (backend_available("OPENGL")) {
        return "OPENGL";
    }
#elif defined(LONGX_ENABLE_HYGON_DCU)
    if (backend_available("HYGON_DCU")) {
        return "HYGON_DCU";
    }
#elif defined(LONGX_ENABLE_HIP)
    if (backend_available("HIP")) {
        return "HIP";
    }
#elif defined(LONGX_ENABLE_MPI)
    if (backend_available("MPI")) {
        return "MPI";
    }
#elif defined(LONGX_ENABLE_TBB)
    if (backend_available("TBB")) {
        return "TBB";
    }
#elif defined(LONGX_ENABLE_OPENMP)
    if (backend_available("OPENMP")) {
        return "OPENMP";
    }
#endif
    return "SERIAL";
}

inline BackendInfo device_info() {
    const char* active = backend_name();
    const char* recommended = recommended_backend();
    MemoryInfo memory = memory_info();
    int count = device_count();
    bool accelerator =
        backend_available("CUDA") ||
        backend_available("HIP") ||
        backend_available("HYGON_DCU") ||
        backend_available("MUSA") ||
        backend_available("SYCL") ||
        backend_available("OPENCL") ||
        backend_available("OPENGL");

    return BackendInfo{
        std::string(active),
        std::string(recommended),
        count,
        memory,
        accelerator
    };
}

} // namespace LongX
