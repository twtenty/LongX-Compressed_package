#pragma once

#include <cstddef>
#include <vector>
#include <type_traits>

#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
#include <mpi.h>
#endif

namespace LongX {
namespace mpi {

inline bool& initialized_by_longx() {
    static bool value = false;
    return value;
}

inline void initialize() {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    int initialized = 0;
    MPI_Initialized(&initialized);
    if (!initialized) {
        int argc = 0;
        char** argv = nullptr;
        MPI_Init(&argc, &argv);
        initialized_by_longx() = true;
    }
#endif
}

inline void finalize() {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    int finalized = 0;
    MPI_Finalized(&finalized);
    if (initialized_by_longx() && !finalized) {
        MPI_Finalize();
        initialized_by_longx() = false;
    }
#endif
}

inline int world_rank() {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    int initialized = 0;
    MPI_Initialized(&initialized);
    if (initialized) {
        int rank = 0;
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        return rank;
    }
#endif
    return 0;
}

inline int world_size() {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    int initialized = 0;
    MPI_Initialized(&initialized);
    if (initialized) {
        int size = 1;
        MPI_Comm_size(MPI_COMM_WORLD, &size);
        return size;
    }
#endif
    return 1;
}

inline bool available() {
    return world_size() >= 1;
}

struct RangePartition {
    std::size_t begin;
    std::size_t end;
};

inline RangePartition partition_range(std::size_t begin, std::size_t end, int rank, int size) {
    if (size <= 1) {
        return RangePartition{begin, end};
    }

    const std::size_t count = end - begin;
    const std::size_t base = count / static_cast<std::size_t>(size);
    const std::size_t extra = count % static_cast<std::size_t>(size);
    const std::size_t rank_index = static_cast<std::size_t>(rank);
    const std::size_t offset = rank_index * base + (rank_index < extra ? rank_index : extra);
    const std::size_t local_count = base + (rank_index < extra ? 1u : 0u);
    return RangePartition{begin + offset, begin + offset + local_count};
}

#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
template<typename T>
MPI_Datatype mpi_datatype() {
    if constexpr (std::is_same_v<T, int>) {
        return MPI_INT;
    } else if constexpr (std::is_same_v<T, unsigned int>) {
        return MPI_UNSIGNED;
    } else if constexpr (std::is_same_v<T, long>) {
        return MPI_LONG;
    } else if constexpr (std::is_same_v<T, unsigned long>) {
        return MPI_UNSIGNED_LONG;
    } else if constexpr (std::is_same_v<T, long long>) {
        return MPI_LONG_LONG;
    } else if constexpr (std::is_same_v<T, unsigned long long>) {
        return MPI_UNSIGNED_LONG_LONG;
    } else if constexpr (std::is_same_v<T, float>) {
        return MPI_FLOAT;
    } else if constexpr (std::is_same_v<T, double>) {
        return MPI_DOUBLE;
    } else {
        return MPI_DATATYPE_NULL;
    }
}

template<typename T>
T allreduce_value(T local, MPI_Op op) {
    MPI_Datatype datatype = mpi_datatype<T>();
    if (datatype == MPI_DATATYPE_NULL || world_size() <= 1) {
        return local;
    }

    T global{};
    MPI_Allreduce(&local, &global, 1, datatype, op, MPI_COMM_WORLD);
    return global;
}
#endif

template<typename T>
T allreduce_sum(T local) {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    return allreduce_value(local, MPI_SUM);
#else
    return local;
#endif
}

template<typename T>
T allreduce_min(T local) {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    return allreduce_value(local, MPI_MIN);
#else
    return local;
#endif
}

template<typename T>
T allreduce_max(T local) {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    return allreduce_value(local, MPI_MAX);
#else
    return local;
#endif
}

template<typename T>
T broadcast_value(T value, int root = 0) {
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    MPI_Datatype datatype = mpi_datatype<T>();
    if (datatype == MPI_DATATYPE_NULL || world_size() <= 1) {
        return value;
    }
    MPI_Bcast(&value, 1, datatype, root, MPI_COMM_WORLD);
#endif
    return value;
}

template<typename T>
std::vector<T> allgather_value(T local) {
    std::vector<T> values(static_cast<std::size_t>(world_size()));
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    MPI_Datatype datatype = mpi_datatype<T>();
    if (datatype == MPI_DATATYPE_NULL || world_size() <= 1) {
        values[0] = local;
        return values;
    }
    MPI_Allgather(&local, 1, datatype, values.data(), 1, datatype, MPI_COMM_WORLD);
#else
    values[0] = local;
#endif
    return values;
}

template<typename T>
struct NeighborHalo {
    bool has_left;
    bool has_right;
    T left;
    T right;
};

template<typename T>
NeighborHalo<T> exchange_neighbor_halo(T left_boundary, T right_boundary) {
    NeighborHalo<T> halo{false, false, T{}, T{}};
#if defined(LONGX_ENABLE_MPI) && defined(LONGX_HAVE_MPI)
    const int rank = world_rank();
    const int size = world_size();
    if (size <= 1) {
        return halo;
    }

    MPI_Datatype datatype = mpi_datatype<T>();
    if (datatype == MPI_DATATYPE_NULL) {
        return halo;
    }

    const int left_rank = rank > 0 ? rank - 1 : MPI_PROC_NULL;
    const int right_rank = rank + 1 < size ? rank + 1 : MPI_PROC_NULL;

    T incoming_right{};
    MPI_Sendrecv(
        &left_boundary,
        1,
        datatype,
        left_rank,
        101,
        &incoming_right,
        1,
        datatype,
        right_rank,
        101,
        MPI_COMM_WORLD,
        MPI_STATUS_IGNORE
    );

    T incoming_left{};
    MPI_Sendrecv(
        &right_boundary,
        1,
        datatype,
        right_rank,
        102,
        &incoming_left,
        1,
        datatype,
        left_rank,
        102,
        MPI_COMM_WORLD,
        MPI_STATUS_IGNORE
    );

    halo.has_left = left_rank != MPI_PROC_NULL;
    halo.has_right = right_rank != MPI_PROC_NULL;
    halo.left = incoming_left;
    halo.right = incoming_right;
#else
    (void)left_boundary;
    (void)right_boundary;
#endif
    return halo;
}

} // namespace mpi
} // namespace LongX
