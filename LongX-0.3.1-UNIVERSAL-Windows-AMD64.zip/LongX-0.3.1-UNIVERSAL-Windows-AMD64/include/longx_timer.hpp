#pragma once

#include <chrono>

namespace LongX {

class Timer {
public:
    Timer() {
        reset();
    }

    void reset() {
        start_ = clock::now();
    }

    double seconds() const {
        auto now = clock::now();
        return std::chrono::duration<double>(now - start_).count();
    }

private:
    using clock = std::chrono::high_resolution_clock;
    clock::time_point start_;
};

} // namespace LongX
