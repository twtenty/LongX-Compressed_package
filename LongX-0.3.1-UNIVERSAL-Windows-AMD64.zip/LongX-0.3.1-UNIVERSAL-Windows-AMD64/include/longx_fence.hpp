#pragma once

#include "longx_error.hpp"
#ifdef LONGX_ENABLE_SYCL
#include "longx_sycl_runtime.hpp"
#endif

namespace LongX {

inline void fence() {
#ifdef LONGX_ENABLE_CUDA
    LONGX_CUDA_CHECK(cudaDeviceSynchronize());
#elif defined(LONGX_ENABLE_MUSA)
    LONGX_MUSA_CHECK(musaDeviceSynchronize());
#elif defined(LONGX_ENABLE_HIP)
    LONGX_HIP_CHECK(hipDeviceSynchronize());
#elif defined(LONGX_ENABLE_SYCL)
    sycl_runtime::queue().wait_and_throw();
#endif
}

} // namespace LongX
