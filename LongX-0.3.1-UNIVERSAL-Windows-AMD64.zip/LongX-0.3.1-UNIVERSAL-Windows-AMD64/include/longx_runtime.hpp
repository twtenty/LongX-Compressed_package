#pragma once

#include <cstddef>

#include "longx_error.hpp"
#include "longx_mpi_runtime.hpp"
#ifdef LONGX_ENABLE_SYCL
#include "longx_sycl_runtime.hpp"
#endif

namespace LongX {

struct MemoryInfo {
    size_t free_bytes;
    size_t total_bytes;
    bool host_accessible;
};

inline void initialize() {
#ifdef LONGX_ENABLE_CUDA
    LONGX_CUDA_CHECK(cudaFree(nullptr));
#elif defined(LONGX_ENABLE_HIP)
    LONGX_HIP_CHECK(hipFree(nullptr));
#elif defined(LONGX_ENABLE_MUSA)
    LONGX_MUSA_CHECK(musaFree(nullptr));
#elif defined(LONGX_ENABLE_SYCL)
    sycl_runtime::queue();
#elif defined(LONGX_ENABLE_MPI)
    mpi::initialize();
#endif
}

inline void finalize() {
#ifdef LONGX_ENABLE_CUDA
    LONGX_CUDA_CHECK(cudaDeviceSynchronize());
#elif defined(LONGX_ENABLE_HIP)
    LONGX_HIP_CHECK(hipDeviceSynchronize());
#elif defined(LONGX_ENABLE_MUSA)
    LONGX_MUSA_CHECK(musaDeviceSynchronize());
#elif defined(LONGX_ENABLE_SYCL)
    sycl_runtime::queue().wait_and_throw();
#elif defined(LONGX_ENABLE_MPI)
    mpi::finalize();
#endif
}

inline const char* backend_name() {
#if defined(LONGX_ENABLE_CUDA)
    return "CUDA";
#elif defined(LONGX_ENABLE_MUSA)
    return "MUSA";
#elif defined(LONGX_ENABLE_SYCL)
    return "SYCL";
#elif defined(LONGX_ENABLE_OPENCL)
    return "OPENCL";
#elif defined(LONGX_ENABLE_OPENGL)
    return "OPENGL";
#elif defined(LONGX_ENABLE_HYGON_DCU)
    return "HYGON_DCU";
#elif defined(LONGX_ENABLE_HIP)
    return "HIP";
#elif defined(LONGX_ENABLE_MPI)
    return "MPI";
#elif defined(LONGX_ENABLE_TBB)
    return "TBB";
#elif defined(LONGX_ENABLE_OPENMP)
    return "OPENMP";
#else
    return "SERIAL";
#endif
}

inline int device_count() {
#ifdef LONGX_ENABLE_CUDA
    int count = 0;
    LONGX_CUDA_CHECK(cudaGetDeviceCount(&count));
    return count;
#elif defined(LONGX_ENABLE_HIP)
    int count = 0;
    LONGX_HIP_CHECK(hipGetDeviceCount(&count));
    return count;
#elif defined(LONGX_ENABLE_MUSA)
    int count = 0;
    LONGX_MUSA_CHECK(musaGetDeviceCount(&count));
    return count;
#elif defined(LONGX_ENABLE_SYCL)
    return sycl_runtime::device_count();
#elif defined(LONGX_ENABLE_MPI)
    return mpi::world_size();
#else
    return 1;
#endif
}

inline MemoryInfo memory_info() {
#ifdef LONGX_ENABLE_CUDA
    size_t free_bytes = 0;
    size_t total_bytes = 0;
    LONGX_CUDA_CHECK(cudaMemGetInfo(&free_bytes, &total_bytes));
    return MemoryInfo{free_bytes, total_bytes, false};
#elif defined(LONGX_ENABLE_HIP)
    size_t free_bytes = 0;
    size_t total_bytes = 0;
    LONGX_HIP_CHECK(hipMemGetInfo(&free_bytes, &total_bytes));
    return MemoryInfo{free_bytes, total_bytes, false};
#elif defined(LONGX_ENABLE_MUSA)
    size_t free_bytes = 0;
    size_t total_bytes = 0;
    LONGX_MUSA_CHECK(musaMemGetInfo(&free_bytes, &total_bytes));
    return MemoryInfo{free_bytes, total_bytes, false};
#elif defined(LONGX_ENABLE_SYCL)
    const size_t total_bytes = sycl_runtime::global_memory_bytes();
    return MemoryInfo{total_bytes, total_bytes, true};
#else
    return MemoryInfo{0, 0, true};
#endif
}

} // namespace LongX
