#pragma once

#include <cstddef>

#include "longx_exec_space.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"

namespace LongX {

template<typename Functor>
void parallel_for(const RangePolicy<Serial>& policy, Functor f) {
    for (size_t i = policy.begin(); i < policy.end(); ++i) {
        f(i);
    }
}

template<typename Functor>
void parallel_for(const MDRangePolicy<Serial, 2>& policy, Functor f) {
    for (size_t i = policy.begin0(); i < policy.end0(); ++i) {
        for (size_t j = policy.begin1(); j < policy.end1(); ++j) {
            f(i, j);
        }
    }
}

template<typename Functor, typename ValueType>
void parallel_reduce(const RangePolicy<Serial>& policy, Functor f, ValueType& result) {
    ValueType local{};
    for (size_t i = policy.begin(); i < policy.end(); ++i) {
        f(i, local);
    }
    result = local;
}

template<typename Functor, typename ValueType, typename Reducer>
void parallel_reduce(const RangePolicy<Serial>& policy, Functor f, ValueType& result, Reducer reducer) {
    ValueType local = reducer.init();
    for (size_t i = policy.begin(); i < policy.end(); ++i) {
        ValueType value = reducer.init();
        f(i, value);
        reducer.join(local, value);
    }
    result = local;
}

} // namespace LongX
