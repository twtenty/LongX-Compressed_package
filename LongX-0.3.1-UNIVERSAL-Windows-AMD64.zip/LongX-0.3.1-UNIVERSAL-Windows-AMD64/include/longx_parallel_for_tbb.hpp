#pragma once

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <thread>
#include <vector>

#ifdef LONGX_HAVE_TBB
#include <tbb/blocked_range.h>
#include <tbb/parallel_for.h>
#include <tbb/parallel_reduce.h>
#endif

#include "longx_exec_space.hpp"
#include "longx_range_policy.hpp"
#include "longx_reducer.hpp"

namespace LongX {

namespace detail {

inline size_t tbb_fallback_workers(size_t work_items) {
    if (work_items == 0) {
        return 0;
    }
    unsigned int hardware = std::thread::hardware_concurrency();
    size_t workers = hardware == 0 ? 2 : static_cast<size_t>(hardware);
    return std::max<size_t>(1, std::min(workers, work_items));
}

template<typename Body>
void tbb_fallback_parallel_for(size_t begin, size_t end, Body body) {
    size_t count = end - begin;
    size_t workers = tbb_fallback_workers(count);
    if (workers <= 1) {
        for (size_t i = begin; i < end; ++i) {
            body(i);
        }
        return;
    }

    std::vector<std::thread> threads;
    threads.reserve(workers);
    size_t chunk = (count + workers - 1) / workers;
    for (size_t worker = 0; worker < workers; ++worker) {
        size_t chunk_begin = begin + worker * chunk;
        size_t chunk_end = std::min(end, chunk_begin + chunk);
        if (chunk_begin >= chunk_end) {
            break;
        }
        threads.emplace_back([=]() {
            for (size_t i = chunk_begin; i < chunk_end; ++i) {
                body(i);
            }
        });
    }
    for (auto& thread : threads) {
        thread.join();
    }
}

} // namespace detail

template<typename Functor>
void parallel_for(const RangePolicy<Tbb>& policy, Functor f) {
#ifdef LONGX_HAVE_TBB
    tbb::parallel_for(
        tbb::blocked_range<size_t>(policy.begin(), policy.end()),
        [&](const tbb::blocked_range<size_t>& range) {
            for (size_t i = range.begin(); i != range.end(); ++i) {
                f(i);
            }
        }
    );
#else
    detail::tbb_fallback_parallel_for(policy.begin(), policy.end(), f);
#endif
}

template<typename Functor>
void parallel_for(const MDRangePolicy<Tbb, 2>& policy, Functor f) {
    size_t begin0 = policy.begin0();
    size_t begin1 = policy.begin1();
    size_t end0 = policy.end0();
    size_t end1 = policy.end1();
    size_t width = end1 - begin1;

    if (policy.collapse()) {
        size_t total = (end0 - begin0) * width;
        parallel_for(
            RangePolicy<Tbb>(0, total),
            [=](size_t linear) {
                size_t row = begin0 + linear / width;
                size_t col = begin1 + linear % width;
                f(row, col);
            }
        );
        return;
    }

    parallel_for(
        RangePolicy<Tbb>(begin0, end0),
        [=](size_t row) {
            for (size_t col = begin1; col < end1; ++col) {
                f(row, col);
            }
        }
    );
}

template<typename Functor, typename ValueType>
void parallel_reduce(const RangePolicy<Tbb>& policy, Functor f, ValueType& result) {
#ifdef LONGX_HAVE_TBB
    result = tbb::parallel_reduce(
        tbb::blocked_range<size_t>(policy.begin(), policy.end()),
        ValueType{},
        [&](const tbb::blocked_range<size_t>& range, ValueType local) {
            for (size_t i = range.begin(); i != range.end(); ++i) {
                f(i, local);
            }
            return local;
        },
        [](const ValueType& lhs, const ValueType& rhs) {
            return lhs + rhs;
        }
    );
#else
    size_t count = policy.size();
    size_t workers = detail::tbb_fallback_workers(count);
    if (workers <= 1) {
        ValueType local{};
        for (size_t i = policy.begin(); i < policy.end(); ++i) {
            f(i, local);
        }
        result = local;
        return;
    }

    std::vector<ValueType> partials(workers, ValueType{});
    std::vector<std::thread> threads;
    threads.reserve(workers);
    size_t chunk = (count + workers - 1) / workers;
    for (size_t worker = 0; worker < workers; ++worker) {
        size_t chunk_begin = policy.begin() + worker * chunk;
        size_t chunk_end = std::min(policy.end(), chunk_begin + chunk);
        threads.emplace_back([=, &partials]() {
            ValueType local{};
            for (size_t i = chunk_begin; i < chunk_end; ++i) {
                f(i, local);
            }
            partials[worker] = local;
        });
    }
    for (auto& thread : threads) {
        thread.join();
    }
    ValueType total{};
    for (const auto& partial : partials) {
        total += partial;
    }
    result = total;
#endif
}

template<typename Functor, typename ValueType, typename Reducer>
void parallel_reduce(const RangePolicy<Tbb>& policy, Functor f, ValueType& result, Reducer reducer) {
#ifdef LONGX_HAVE_TBB
    result = tbb::parallel_reduce(
        tbb::blocked_range<size_t>(policy.begin(), policy.end()),
        reducer.init(),
        [&](const tbb::blocked_range<size_t>& range, ValueType local) {
            for (size_t i = range.begin(); i != range.end(); ++i) {
                ValueType value = reducer.init();
                f(i, value);
                reducer.join(local, value);
            }
            return local;
        },
        [&](ValueType lhs, const ValueType& rhs) {
            reducer.join(lhs, rhs);
            return lhs;
        }
    );
#else
    size_t count = policy.size();
    size_t workers = detail::tbb_fallback_workers(count);
    if (workers <= 1) {
        ValueType local = reducer.init();
        for (size_t i = policy.begin(); i < policy.end(); ++i) {
            ValueType value = reducer.init();
            f(i, value);
            reducer.join(local, value);
        }
        result = local;
        return;
    }

    std::vector<ValueType> partials(workers, reducer.init());
    std::vector<std::thread> threads;
    threads.reserve(workers);
    size_t chunk = (count + workers - 1) / workers;
    for (size_t worker = 0; worker < workers; ++worker) {
        size_t chunk_begin = policy.begin() + worker * chunk;
        size_t chunk_end = std::min(policy.end(), chunk_begin + chunk);
        threads.emplace_back([=, &partials]() {
            ValueType local = reducer.init();
            for (size_t i = chunk_begin; i < chunk_end; ++i) {
                ValueType value = reducer.init();
                f(i, value);
                reducer.join(local, value);
            }
            partials[worker] = local;
        });
    }
    for (auto& thread : threads) {
        thread.join();
    }
    ValueType total = reducer.init();
    for (const auto& partial : partials) {
        reducer.join(total, partial);
    }
    result = total;
#endif
}

} // namespace LongX
