#include <cmath>
#include <iostream>

#include "longx.hpp"

int main() {
    constexpr size_t rows = 64;
    constexpr size_t cols = 96;

    using ExecSpace = LongX::DefaultExecutionSpace;
    using MemorySpace = LongX::DefaultMemorySpace;

    LongX::View2D<float, MemorySpace> input("input", rows, cols);
    LongX::View2D<float, MemorySpace> output("output", rows, cols);

    auto h_input = LongX::create_mirror_view(input);
    auto h_output = LongX::create_mirror_view(output);

    for (size_t row = 0; row < rows; ++row) {
        for (size_t col = 0; col < cols; ++col) {
            h_input(row, col) = static_cast<float>(row + col);
        }
    }

    LongX::deep_copy(input, h_input);
    LongX::deep_copy(output, 0.0f);

    auto input_d = input.device();
    auto output_d = output.device();

    LongX::parallel_for(
        LongX::MDRangePolicy<ExecSpace, 2>(1, 1, rows - 1, cols - 1),
        [=] LONGX_DEVICE (size_t row, size_t col) {
            output_d(row, col) = 0.25f * (
                input_d(row - 1, col) +
                input_d(row + 1, col) +
                input_d(row, col - 1) +
                input_d(row, col + 1)
            );
        }
    );

    LongX::deep_copy(h_output, output);

    std::cout << "Stencil2D sample results:\n";
    for (size_t row = 1; row <= 3; ++row) {
        for (size_t col = 1; col <= 3; ++col) {
            float expected = static_cast<float>(row + col);
            std::cout << "(" << row << "," << col << ")="
                      << h_output(row, col)
                      << " expected=" << expected << '\n';
        }
    }

    size_t errors = 0;
    for (size_t row = 1; row < rows - 1; ++row) {
        for (size_t col = 1; col < cols - 1; ++col) {
            float expected = static_cast<float>(row + col);
            if (std::abs(h_output(row, col) - expected) > 1.0e-5f) {
                ++errors;
            }
        }
    }

    if (errors != 0) {
        std::cerr << "stencil2d failed with " << errors << " errors\n";
        return 1;
    }

    std::cout << "stencil2d passed for " << rows << "x" << cols << " grid\n";
    return 0;
}
