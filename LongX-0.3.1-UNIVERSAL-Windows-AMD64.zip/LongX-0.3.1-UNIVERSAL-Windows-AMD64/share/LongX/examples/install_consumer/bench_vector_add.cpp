#include <iostream>

#include "longx.hpp"

int main() {
    constexpr size_t N = 16 * 1024 * 1024;
    constexpr int iterations = 100;

    using ExecSpace = LongX::DefaultExecutionSpace;
    using MemorySpace = LongX::DefaultMemorySpace;

    LongX::View<float, MemorySpace> a("a", N);
    LongX::View<float, MemorySpace> b("b", N);
    LongX::View<float, MemorySpace> c("c", N);

    LongX::deep_copy(a, 1.0f);
    LongX::deep_copy(b, 2.0f);
    LongX::deep_copy(c, 0.0f);

    auto a_d = a.device();
    auto b_d = b.device();
    auto c_d = c.device();

    LongX::fence();
    LongX::Timer timer;

    for (int iter = 0; iter < iterations; ++iter) {
        LongX::parallel_for(
            LongX::RangePolicy<ExecSpace>(0, N),
            [=] LONGX_DEVICE (size_t i) {
                c_d(i) = a_d(i) + b_d(i);
            }
        );
    }

    LongX::fence();
    double seconds = timer.seconds();

    auto h_c = LongX::create_mirror_view(c);
    LongX::deep_copy(h_c, c);

    double bytes = static_cast<double>(N) * iterations * 3.0 * sizeof(float);

    std::cout << "Vector add benchmark\n";
    std::cout << "elements=" << N
              << " iterations=" << iterations << '\n';
    std::cout << "time_seconds=" << seconds << '\n';
    std::cout << "effective_bandwidth_gb_s=" << bytes / seconds / 1.0e9 << '\n';
    std::cout << "sample=" << h_c(N / 2) << " expected=3\n";

    return h_c(N / 2) == 3.0f ? 0 : 1;
}
