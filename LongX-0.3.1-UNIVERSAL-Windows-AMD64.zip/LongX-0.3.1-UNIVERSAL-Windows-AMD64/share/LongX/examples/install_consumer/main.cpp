#include <iostream>

#include "longx.hpp"

int main() {
    LongX::initialize();

    LongX::View<int, LongX::DefaultMemorySpace> values("values", 4);
    LongX::deep_copy(values, 2);

    auto values_d = values.device();
    LongX::parallel_for(
        LongX::RangePolicy<LongX::DefaultExecutionSpace>(0, values.extent()),
        [=] LONGX_DEVICE (size_t i) {
            values_d(i) += static_cast<int>(i);
        }
    );

    int sum = 0;
    LongX::parallel_reduce(
        LongX::RangePolicy<LongX::DefaultExecutionSpace>(0, values.extent()),
        [=] LONGX_DEVICE (size_t i, int& local) {
            local += values_d(i);
        },
        sum
    );

    LongX::finalize();

    if (sum != 14) {
        std::cerr << "unexpected sum: " << sum << '\n';
        return 1;
    }

    std::cout << "LongX install consumer passed\n";
    return 0;
}
