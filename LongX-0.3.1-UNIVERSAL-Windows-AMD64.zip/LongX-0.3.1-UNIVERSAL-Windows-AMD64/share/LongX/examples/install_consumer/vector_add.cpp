#include <cmath>
#include <iostream>

#include "longx.hpp"

int main() {
    constexpr size_t N = 1024;

    using ExecSpace = LongX::DefaultExecutionSpace;
    using MemorySpace = LongX::DefaultMemorySpace;

    LongX::View<double, MemorySpace> A("A", N);
    LongX::View<double, MemorySpace> B("B", N);
    LongX::View<double, MemorySpace> C("C", N);

    auto h_A = LongX::create_mirror_view(A);
    auto h_B = LongX::create_mirror_view(B);
    auto h_C = LongX::create_mirror_view(C);

    for (size_t i = 0; i < N; ++i) {
        h_A(i) = static_cast<double>(i);
        h_B(i) = static_cast<double>(2 * i);
    }

    LongX::deep_copy(A, h_A);
    LongX::deep_copy(B, h_B);
    LongX::deep_copy(C, 0.0);

    auto A_d = A.device();
    auto B_d = B.device();
    auto C_d = C.device();

    LongX::parallel_for(
        LongX::RangePolicy<ExecSpace>(0, N),
        [=] LONGX_DEVICE (size_t i) {
            C_d(i) = A_d(i) + B_d(i);
        }
    );

    LongX::deep_copy(h_C, C);

    std::cout << "First 10 results:\n";
    for (size_t i = 0; i < 10; ++i) {
        std::cout << "i=" << i
                  << " A=" << h_A(i)
                  << " B=" << h_B(i)
                  << " C=" << h_C(i)
                  << " expected=" << static_cast<double>(3 * i)
                  << '\n';
    }

    double sum = 0.0;
    LongX::parallel_reduce(
        LongX::RangePolicy<ExecSpace>(0, N),
        [=] LONGX_DEVICE (size_t i, double& local) {
            local = C_d(i);
        },
        sum,
        LongX::Sum<double>{}
    );

    double expected_sum = static_cast<double>(3 * (N - 1) * N / 2);
    std::cout << "sum=" << sum << " expected_sum=" << expected_sum << '\n';

    size_t errors = 0;
    for (size_t i = 0; i < N; ++i) {
        double expected = static_cast<double>(3 * i);
        if (std::abs(h_C(i) - expected) > 1.0e-12) {
            ++errors;
        }
    }
    if (std::abs(sum - expected_sum) > 1.0e-9) {
        ++errors;
    }

    if (errors != 0) {
        std::cerr << "vector_add failed with " << errors << " errors\n";
        return 1;
    }

    std::cout << "vector_add passed for " << N << " elements\n";
    return 0;
}
